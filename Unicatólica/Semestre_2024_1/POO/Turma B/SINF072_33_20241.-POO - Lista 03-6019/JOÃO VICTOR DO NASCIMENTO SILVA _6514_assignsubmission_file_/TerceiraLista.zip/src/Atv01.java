import java.util.Scanner;

public class Atv01 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int hora, minuto;
        char ampm;

        do {
            System.out.print("Digite a hora no formato 24h (0 para sair): ");
            hora = scanner.nextInt();

            if (hora != 0) {
                System.out.print("Digite o minuto: ");
                minuto = scanner.nextInt();

                // Chama a função converterHora e armazena o resultado
                ampm = converterHora(hora);

                // Chama a função exibirHora para mostrar o resultado
                exibirHora(hora, minuto, ampm);
            }
        } while (hora != 0);

        System.out.println("Programa encerrado.");
    }

    public static char converterHora(int h) {
        char ampm;

        if (h < 12) {
            // Se a hora for menor que 12, é A.M.
            ampm = 'A';
        } else {
            // Se a hora for maior ou igual a 12, é P.M.
            ampm = 'P';

            // Se a hora for maior que 12, subtrai 12 para obter a hora no formato 12h
            if (h > 12) {
                h -= 12;
            }
        }

        return ampm;
    }

    public static void exibirHora(int h, int m, char ampm) {
        System.out.println("A hora no formato 12h é: " + h + ":" + m + " " + ampm + ".M.");
    }
}
