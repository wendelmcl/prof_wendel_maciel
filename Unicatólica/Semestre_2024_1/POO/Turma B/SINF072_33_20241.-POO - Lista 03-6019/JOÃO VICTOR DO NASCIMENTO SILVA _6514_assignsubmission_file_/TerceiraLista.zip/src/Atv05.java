import java.util.Random;
import java.util.Scanner;

public class Atv05 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int dado1, dado2, soma, ponto;
        char resposta;

        do {
            System.out.println("Jogo de Craps");
            System.out.println("Pressione ENTER para lançar os dados");
            scanner.nextLine();

            dado1 = random.nextInt(6) + 1;
            dado2 = random.nextInt(6) + 1;

            soma = dado1 + dado2;

            System.out.println("Você tirou " + dado1 + " e " + dado2 + ", totalizando " + soma);

            if (soma == 7 || soma == 11) {
                System.out.println("Você tirou um natural e ganhou!");
            } else if (soma == 2 || soma == 3 || soma == 12) {
                System.out.println("Você tirou um craps e perdeu!");
            } else {
                ponto = soma;
                System.out.println("Seu ponto é " + ponto);
                System.out.println("Você deve continuar jogando até tirar seu ponto novamente ou um 7");

                do {
                    System.out.println("Pressione ENTER para lançar os dados");
                    scanner.nextLine();

                    dado1 = random.nextInt(6) + 1;
                    dado2 = random.nextInt(6) + 1;

                    soma = dado1 + dado2;

                    System.out.println("Você tirou " + dado1 + " e " + dado2 + ", totalizando " + soma);

                    if (soma == ponto) {
                        System.out.println("Você tirou seu ponto novamente e ganhou!");
                    } else if (soma == 7) {
                        System.out.println("Você tirou um 7 e perdeu!");
                    }
                } while (soma != ponto && soma != 7);
            }

            System.out.print("Quer jogar novamente? (S/N): ");
            resposta = scanner.next().charAt(0);
        } while (resposta == 'S' || resposta == 's');

        System.out.println("Fim do jogo.");
    }
}
