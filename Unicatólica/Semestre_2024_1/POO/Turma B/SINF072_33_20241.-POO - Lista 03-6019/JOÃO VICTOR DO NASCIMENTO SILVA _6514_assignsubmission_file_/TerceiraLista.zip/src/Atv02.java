import java.util.Scanner;

public class Atv02 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double valorPrestacao;
        int diasAtraso;
        double valorPago;
        int quantidade = 0;
        double total = 0;

        do {
            System.out.print("Digite o valor da prestação (0 para sair): ");
            valorPrestacao = scanner.nextDouble();

            if (valorPrestacao != 0) {
                System.out.print("Digite o número de dias em atraso: ");
                diasAtraso = scanner.nextInt();


                valorPago = valorPagamento(valorPrestacao, diasAtraso);

                System.out.println("Valor a ser pago: R$ " + String.format("%.2f", valorPago));


                quantidade++;
                total += valorPago;
            }
        } while (valorPrestacao != 0);

        System.out.println("Relatório do dia:");
        System.out.println("Quantidade de prestações pagas: " + quantidade);
        System.out.println("Valor total de prestações pagas: R$ " + String.format("%.2f", total));
    }

    public static double valorPagamento(double valor, int dias) {
        double multa = 0;
        double juros = 0;

        if (dias > 0) {

            multa = valor * 0.03;
            juros = valor * 0.001 * dias;
        }

        return valor + multa + juros;
    }
}
