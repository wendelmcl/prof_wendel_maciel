public class Atv04 {

    public static void main(String[] args) {
        int numero = 127;
        int reverso = inverterNumero(numero);
        System.out.println("O reverso de " + numero + " é " + reverso + ".");
    }

    public static int inverterNumero(int n) {
        int inverso = 0;


        while (n != 0) {
            inverso = inverso * 10;
            inverso = inverso + (n % 10);
            n /= 10;
        }

        return inverso;
    }
}
