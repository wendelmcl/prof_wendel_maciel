import java.util.Scanner;
public class Atv03 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Insira o numero: ");
        int numero = scanner.nextInt();
        int digitos = contarDigitos(numero);
        System.out.println("O número " + numero + " tem " + digitos + " dígitos.");
    }

    public static int contarDigitos(int n) {
        int contador = 0;


        while (n != 0) {
            n /= 10;
            contador++;
        }

        return contador;
    }
}
