package questao5;

import java.util.Random;
import java.util.Scanner;

	public class JogoCraps {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Random random = new Random();

	        System.out.println("Bem-vindo ao Jogo de Craps!");

	        boolean jogarNovamente;

	        do {
	            System.out.println("\nPressione Enter para jogar os dados...");
	            scanner.nextLine();

	            int dado1 = rolarDado(random);
	            int dado2 = rolarDado(random);
	            int somaDados = dado1 + dado2;

	            System.out.println("\nVocê rolou os dados. Resultado: " + dado1 + " + " + dado2 + " = " + somaDados);

	            if (somaDados == 7 || somaDados == 11) {
	                System.out.println("Você tirou um natural! Você ganhou!");
	                jogarNovamente = false;
	            } else if (somaDados == 2 || somaDados == 3 || somaDados == 12) {
	                System.out.println("Você tirou craps! Você perdeu!");
	                jogarNovamente = false;
	            } else {
	                int ponto = somaDados;
	                System.out.println("Você estabeleceu o ponto: " + ponto);
	                System.out.println("Agora, continue jogando até tirar o ponto novamente ou um 7...");

	                boolean continuarJogando = true;

	                while (continuarJogando) {
	                    System.out.println("\nPressione Enter para jogar os dados...");
	                    scanner.nextLine();

	                    dado1 = rolarDado(random);
	                    dado2 = rolarDado(random);
	                    somaDados = dado1 + dado2;

	                    System.out.println("\nVocê rolou os dados. Resultado: " + dado1 + " + " + dado2 + " = " + somaDados);

	                    if (somaDados == ponto) {
	                        System.out.println("Você tirou o ponto novamente! Você ganhou!");
	                        continuarJogando = false;
	                    } else if (somaDados == 7) {
	                        System.out.println("Você tirou um 7! Você perdeu!");
	                        continuarJogando = false;
	                    }
	                }

	                jogarNovamente = false;
	            }

	            System.out.print("\nDeseja jogar novamente? (Digite 's' para Sim, ou qualquer tecla para Não): ");
	            String resposta = scanner.nextLine();
	            jogarNovamente = resposta.equalsIgnoreCase("s");
	        } while (jogarNovamente);

	        System.out.println("\nObrigado por jogar o Jogo de Craps!");
	        scanner.close();
	    }

	    public static int rolarDado(Random random) {
	        return random.nextInt(6) + 1;
	    }
	}
