package questao3;

import java.util.Scanner;

public class QuantidadeDigitosEReverso {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt();

        int quantidade = contarDigitos(numero);
        System.out.println("Quantidade de dígitos: " + quantidade);

        int reverso = obterReverso(numero);
        System.out.println("Reverso do número: " + reverso);

        scanner.close();
    }

    public static int contarDigitos(int numero) {
        if (numero == 0) {
            return 1;
        }

        int quantidade = 0;
        while (numero != 0) {
            numero = numero / 10;
            quantidade++;
        }

        return quantidade;
    }

    public static int obterReverso(int numero) {
        int reverso = 0;
        while (numero != 0) {
            reverso = reverso * 10 + numero % 10;
            numero = numero / 10;
        }
        return reverso;
    }
}

