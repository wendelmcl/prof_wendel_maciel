package questao1;

import java.util.Scanner;

public class ConversaoHorario {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        char opcao;

        do {
            System.out.print("Digite o horário (formato 24 horas): ");
            int horas = scanner.nextInt();
            int minutos = scanner.nextInt();

            String horario12h = converterPara12Horas(horas, minutos);
            System.out.println("Horário convertido: " + horario12h);

            System.out.print("Deseja converter outro horário? (S/N): ");
            opcao = scanner.next().charAt(0);
        } while (opcao == 'S' || opcao == 's');

        scanner.close();
    }

    public static String converterPara12Horas(int horas24, int minutos) {
        String periodo;

        if (horas24 >= 0 && horas24 <= 11) {
            periodo = "A.M.";
        } else {
            periodo = "P.M.";
        }

        int horas12;
        if (horas24 == 0) {
            horas12 = 12;
        } else if (horas24 > 12) {
            horas12 = horas24 - 12;
        } else {
            horas12 = horas24;
        }

        String minutosFormatados = String.format("%02d", minutos);

        return horas12 + ":" + minutosFormatados + " " + periodo;
    }

}


