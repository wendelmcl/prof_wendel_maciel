package questao2;

import java.util.Scanner;

public class CalculadoraPagamento {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double totalPrestacoes = 0;
        int quantidadePrestacoes = 0;

        System.out.println("Calculadora de Pagamento");

        while (true) {
            System.out.print("Digite o valor da prestação (ou 0 para sair): ");
            double valorPrestacao = scanner.nextDouble();

            if (valorPrestacao == 0) {
                break;
            }

            System.out.print("Digite o número de dias em atraso: ");
            int diasAtraso = scanner.nextInt();

            double valorTotal = valorPagamento(valorPrestacao, diasAtraso);

            System.out.println("Valor a ser pago: R$" + valorTotal);

            totalPrestacoes += valorTotal;
            quantidadePrestacoes++;
        }

        System.out.println("\nRelatório do Dia");
        System.out.println("Quantidade de prestações pagas: " + quantidadePrestacoes);
        System.out.println("Valor total recebido: R$" + totalPrestacoes);

        scanner.close();
    }

    public static double valorPagamento(double valorPrestacao, int diasAtraso) {
        if (diasAtraso == 0) {
            return valorPrestacao; // Pagamento sem atraso
        }

        double multa = valorPrestacao * 0.03; // 3% de multa
        double juros = valorPrestacao * (0.001 * diasAtraso); // 0,1% de juros por dia de atraso

        return valorPrestacao + multa + juros;
    }
}