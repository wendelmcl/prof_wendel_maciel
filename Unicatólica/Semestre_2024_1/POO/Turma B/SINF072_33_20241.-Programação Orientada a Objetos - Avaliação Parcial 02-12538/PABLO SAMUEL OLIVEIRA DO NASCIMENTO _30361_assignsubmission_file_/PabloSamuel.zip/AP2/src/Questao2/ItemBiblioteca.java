package Questao2;

public interface ItemBiblioteca {
	    void emprestarItem();
	    void devolverItem();

}
