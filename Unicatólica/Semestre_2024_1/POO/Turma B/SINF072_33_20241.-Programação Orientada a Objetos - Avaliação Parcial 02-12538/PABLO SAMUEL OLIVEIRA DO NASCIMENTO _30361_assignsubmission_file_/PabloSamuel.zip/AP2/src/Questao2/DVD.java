package Questao2;

public interface DVD extends ItemBiblioteca{
	void gravarDVD();
	void emprestarItem();

}
