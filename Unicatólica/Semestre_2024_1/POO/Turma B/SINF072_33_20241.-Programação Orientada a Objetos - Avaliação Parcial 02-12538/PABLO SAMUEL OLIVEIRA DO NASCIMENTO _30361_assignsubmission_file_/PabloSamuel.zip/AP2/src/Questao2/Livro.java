package Questao2;

public interface Livro extends ItemBiblioteca {
	void consultarDisponibilidade();
}
