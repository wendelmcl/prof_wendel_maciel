package q2;

public interface Livro extends ItemBiblioteca {
    boolean consultarDisponibilidade();
}