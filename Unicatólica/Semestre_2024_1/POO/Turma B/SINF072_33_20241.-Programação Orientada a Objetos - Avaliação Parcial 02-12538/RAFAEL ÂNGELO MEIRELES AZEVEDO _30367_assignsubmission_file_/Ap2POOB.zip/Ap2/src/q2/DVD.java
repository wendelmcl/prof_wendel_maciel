package q2;

public interface DVD extends ItemBiblioteca {
    void gravarDVD();
}