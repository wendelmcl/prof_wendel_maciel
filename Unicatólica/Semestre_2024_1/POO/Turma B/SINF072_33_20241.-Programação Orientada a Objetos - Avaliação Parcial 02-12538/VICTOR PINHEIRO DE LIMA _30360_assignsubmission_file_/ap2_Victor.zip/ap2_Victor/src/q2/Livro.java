package q2;

public abstract class Livro extends ItemBiblioteca {
	 public abstract boolean consultarDisponibilidade();
	}
