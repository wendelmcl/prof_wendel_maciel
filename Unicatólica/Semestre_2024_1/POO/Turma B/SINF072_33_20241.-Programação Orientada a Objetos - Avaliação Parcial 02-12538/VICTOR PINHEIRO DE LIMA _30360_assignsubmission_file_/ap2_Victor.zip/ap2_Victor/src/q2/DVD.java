package q2;

public abstract class DVD extends ItemBiblioteca {
    public abstract void gravarDVD();
}
