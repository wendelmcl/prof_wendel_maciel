package questao2;

public interface Livro extends ItemBiblioteca {
    void emprestaritem();

    void devolveritem();

    void ConsultarDisponibilidade();

}
