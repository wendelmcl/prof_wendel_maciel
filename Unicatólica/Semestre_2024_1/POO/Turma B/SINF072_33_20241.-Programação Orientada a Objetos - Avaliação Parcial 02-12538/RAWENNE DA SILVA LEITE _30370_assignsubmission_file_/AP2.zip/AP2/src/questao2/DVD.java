package questao2;

public interface DVD extends ItemBiblioteca {
    void emprestaritem();

    void devolveritem();

    void gravarDVD();

}
