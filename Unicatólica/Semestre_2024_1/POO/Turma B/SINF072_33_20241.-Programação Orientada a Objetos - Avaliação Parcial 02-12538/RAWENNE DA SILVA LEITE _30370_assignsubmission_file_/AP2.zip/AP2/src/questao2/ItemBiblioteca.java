package questao2;

public interface ItemBiblioteca {
    void emprestaritem();

    void devolveritem();

}
