public abstract eletrodomestico {

    public static void main(String[] args) {
        marca = string;
        modelo = string;
        preco = float;
    
        public static ( calcularGarantiaEstendida());
        
        public abstract metodo 
       
    

     
    }
}
