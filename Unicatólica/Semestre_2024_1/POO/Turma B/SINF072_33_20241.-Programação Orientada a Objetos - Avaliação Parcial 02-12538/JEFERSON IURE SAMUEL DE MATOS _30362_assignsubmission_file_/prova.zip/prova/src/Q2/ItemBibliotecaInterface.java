package Q2;

public interface ItemBibliotecaInterface {
    void emprestarItem();
    void devolverItem();
}