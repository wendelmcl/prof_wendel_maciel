package Q2;

public interface DVDInterface extends ItemBibliotecaInterface {
    void gravarDVD();
}