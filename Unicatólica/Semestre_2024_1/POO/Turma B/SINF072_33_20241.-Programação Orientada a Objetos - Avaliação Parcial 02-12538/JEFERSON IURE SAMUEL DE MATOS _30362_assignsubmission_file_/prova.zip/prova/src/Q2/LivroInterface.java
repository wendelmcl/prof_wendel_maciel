package Q2;

public interface LivroInterface extends ItemBibliotecaInterface {
    boolean consultarDisponibilidade();
}