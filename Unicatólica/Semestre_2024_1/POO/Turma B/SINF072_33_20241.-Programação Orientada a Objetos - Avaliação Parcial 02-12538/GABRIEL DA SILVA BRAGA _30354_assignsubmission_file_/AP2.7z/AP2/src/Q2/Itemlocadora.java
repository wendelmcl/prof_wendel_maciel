package Q2;

public interface Itemlocadora extends Itembiblioteca{
    void consultarDispositivo();
    void gravarDvd();
    
    
}
