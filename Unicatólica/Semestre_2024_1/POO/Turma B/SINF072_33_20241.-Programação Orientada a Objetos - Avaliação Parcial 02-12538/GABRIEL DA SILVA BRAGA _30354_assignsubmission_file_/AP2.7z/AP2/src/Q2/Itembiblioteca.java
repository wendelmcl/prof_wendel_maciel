package Q2;

public interface Itembiblioteca {
    void EmprestarLivro();
    void DevolverLivro();
}
