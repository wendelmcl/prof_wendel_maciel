package Q2;

public interface ItemBiblioteca {
    void emprestarItem();
    void devolverItem();
}
