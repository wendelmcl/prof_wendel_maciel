package Q2;

public interface DVD extends ItemBiblioteca {
    void gravarDVD();
}
