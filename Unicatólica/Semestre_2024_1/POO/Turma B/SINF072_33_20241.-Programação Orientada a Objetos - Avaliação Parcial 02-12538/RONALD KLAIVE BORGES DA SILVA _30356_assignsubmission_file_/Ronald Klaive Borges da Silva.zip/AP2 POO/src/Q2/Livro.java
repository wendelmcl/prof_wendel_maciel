package Q2;

public interface Livro extends ItemBiblioteca {
    boolean consultarDisponibilidade();
}
