package q2;

public interface ItemBiblioteca {
    void empresterItem();
    void devolverItem();
}