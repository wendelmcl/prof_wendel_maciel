package q2;

public class DVDD {
	public interface DVD extends ItemBiblioteca {
	    void gravarDVD();
	}
}
