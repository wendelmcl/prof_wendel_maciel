package q2;

public interface DVD extends itemBiblioteca {
    void gravarDVD();
}
