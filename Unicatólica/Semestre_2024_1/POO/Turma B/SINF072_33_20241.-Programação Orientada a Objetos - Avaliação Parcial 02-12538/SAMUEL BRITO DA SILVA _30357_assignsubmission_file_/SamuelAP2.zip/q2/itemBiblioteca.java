package q2;

public interface itemBiblioteca {
    void emprestarItem();
    void devolverItem();    
}
