package q2;

public interface Livro extends itemBiblioteca {
    void consultarDisponibilidade();
}
