package questao2;
public interface Livro extends ItemBiblioteca{
    void consultarDisponibilidade ();
    
}
