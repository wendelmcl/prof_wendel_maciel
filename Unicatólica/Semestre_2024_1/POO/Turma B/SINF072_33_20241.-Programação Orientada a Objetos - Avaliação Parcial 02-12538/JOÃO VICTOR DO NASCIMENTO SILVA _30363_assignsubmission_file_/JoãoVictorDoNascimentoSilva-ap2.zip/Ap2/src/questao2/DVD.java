package questao2;
public interface DVD extends ItemBiblioteca{
    void gravarDVD ();
}
