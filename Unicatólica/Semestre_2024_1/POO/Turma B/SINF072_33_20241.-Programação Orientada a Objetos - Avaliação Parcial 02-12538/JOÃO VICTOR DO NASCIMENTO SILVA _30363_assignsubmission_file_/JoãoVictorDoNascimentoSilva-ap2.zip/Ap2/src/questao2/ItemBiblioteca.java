package questao2;
public interface ItemBiblioteca {
    void emprestarItem ();
    void devolverItem();
}
