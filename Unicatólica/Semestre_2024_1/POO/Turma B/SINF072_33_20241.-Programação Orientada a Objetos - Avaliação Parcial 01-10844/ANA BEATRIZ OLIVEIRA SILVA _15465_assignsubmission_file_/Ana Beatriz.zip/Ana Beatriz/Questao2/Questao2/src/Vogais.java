import java.util.Scanner;

public class Vogais {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String a = ("a");
        String e = ("e");
        String i = ("i");
        String o = ("o");
        String u = ("u");

        String letras = new String (string);
        
        String (letras = (a) + (e) + (i) + (o) + (u) );
            System.out.println("Digite a palavra");
                sc.nextLine();

        }

    private static void String(String string) {
        
        throw new UnsupportedOperationException("Unimplemented method 'String'");
    }
        }


    
