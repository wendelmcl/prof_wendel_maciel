import java.util.Scanner;

public class Algoritmo {
   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int a = ("0");
        int b = ("0");
        int c = ("0");
        intSoma(i+i == i);

        System.out.println("A soma dos numeros é: " + ("a") + ("b") == ("c"));
        sc.nextInt(intSoma);

    }

}
        
    
    

