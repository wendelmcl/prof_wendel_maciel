import java.util.Scanner;

public class Vetor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //desculpa. eu realmente n consigo lembrar


     vector[0] = 1
     vector[1] = 2
     vector[2] = 3
     vector[3] = 4
     vector[4] = 5
        
       
       System.out.println("Digite 5 numeros");
       sc.nextInt();

        
    }

 }
 


