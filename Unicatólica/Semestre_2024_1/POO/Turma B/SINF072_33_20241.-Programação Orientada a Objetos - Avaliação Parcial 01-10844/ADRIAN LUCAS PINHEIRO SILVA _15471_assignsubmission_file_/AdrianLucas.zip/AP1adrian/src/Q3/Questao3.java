package Q3;

import java.util.Scanner;

public class Questao3 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int n1=0;
	int n2=0;
	int n3=0;
	int n4=0;
	int n5=0;
	System.out.println("digite 5 numeros para o vetor:");
	n1 = sc.nextInt();
	n2 = sc.nextInt();
	n3 = sc.nextInt();
	n4 = sc.nextInt();
	n5 = sc.nextInt();
int vetor[] = new int [n1,n2,n3,n4,n5];
System.out.println("estes sao os numeros do vetor"+vetor);

	


	}

}
