package Q2;

import java.util.Scanner;

public class Questao2 {

	public static void main(String[] args) {
		String vogal1 = "a";
		String vogal2 = "e";
		String vogal3 = "i";
		String vogal4 = "o";
		String vogal5 = "u";	
		Scanner sc = new Scanner (System.in);
		System.out.println("digite uma palavra:");
		String palavra = sc.next();
		System.out.println("a palavra digitada e:"+palavra);
		if (palavra == vogal1 || vogal2 || vogal3|| vogal4 || vogal5);
		System.out.println("estas sao as vogais:"+vogal1+vogal2+vogal3+vogal4+vogal5);
	
			
		}

		

	}

}
