package q3;
import java.util.Scanner;
public class Q3 {


	    }


