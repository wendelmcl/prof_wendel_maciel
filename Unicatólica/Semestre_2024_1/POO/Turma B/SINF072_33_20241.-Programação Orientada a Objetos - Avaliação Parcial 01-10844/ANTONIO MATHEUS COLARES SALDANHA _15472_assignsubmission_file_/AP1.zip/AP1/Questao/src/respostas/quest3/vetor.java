package respostas.quest3;

public class vetor {
    Foi mal, não sei nada de vetor xd :D
}
