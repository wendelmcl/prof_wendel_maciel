package Q2;

import java.util.Scanner;

public class Vetorvogais {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String[] vogais = new String[]{a.e.i.o.u};
        String p1;

        System.out.println("Digite uma Palavra: ");
        p1 = sc.next();


    }
}
