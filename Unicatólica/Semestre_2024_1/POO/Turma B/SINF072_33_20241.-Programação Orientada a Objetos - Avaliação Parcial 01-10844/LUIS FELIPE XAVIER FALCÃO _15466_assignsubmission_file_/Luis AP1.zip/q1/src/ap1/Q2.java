package ap1;

import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		System.out.print("Digite seu nome: ");
		String n = tec.next();
		
		System.out.print("as vogais do seu �: "+n.length());
		
	}

}
