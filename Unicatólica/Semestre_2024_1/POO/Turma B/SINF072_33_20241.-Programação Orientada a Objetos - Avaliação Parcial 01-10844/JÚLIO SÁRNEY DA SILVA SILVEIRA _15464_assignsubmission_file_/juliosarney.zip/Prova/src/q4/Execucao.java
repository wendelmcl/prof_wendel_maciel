package q4;

public class Execucao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
