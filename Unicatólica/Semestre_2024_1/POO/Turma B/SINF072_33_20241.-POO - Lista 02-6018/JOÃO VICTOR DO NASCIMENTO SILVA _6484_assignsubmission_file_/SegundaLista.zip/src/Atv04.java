public class Atv04 {
    public static void main(String[] args) {
        for (int i = 1; i < 51; i+=2) {
            System.out.println(i);
        }
    }
}
