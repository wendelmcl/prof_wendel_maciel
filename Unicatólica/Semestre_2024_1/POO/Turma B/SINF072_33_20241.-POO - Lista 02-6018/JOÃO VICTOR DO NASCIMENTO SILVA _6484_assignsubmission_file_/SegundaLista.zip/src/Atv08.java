import java.util.Scanner;

public class Atv08 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] idade = new int[5];
        double[] altura = new double[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("Qual sua idade?");
            idade[i] = input.nextInt();
            System.out.println("Qual sua altura?");
            altura[i] = input.nextDouble();
        }

        for (int i = 4; i >= 0; i--) {
            System.out.println("Idade: "+idade[i]);
            System.out.println("altura: "+altura[i]);
        }
    }
}
