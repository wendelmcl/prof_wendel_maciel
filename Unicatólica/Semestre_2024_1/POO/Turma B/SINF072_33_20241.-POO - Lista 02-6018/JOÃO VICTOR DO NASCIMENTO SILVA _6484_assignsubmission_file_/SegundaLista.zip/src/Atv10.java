import java.util.Scanner;

public class Atv10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] vetorA = new int[5];
        int[] vetorB = new int[5];
        int[] vetorC = new int[10];

        System.out.println("Digite os valores para o primeiro vetor: ");
        for (int i = 0; i < 5; i++) {
            vetorA[i] = input.nextInt();
        }
        System.out.println("Digite os valores para o segundo vetor: ");
        for (int i = 0; i < 5; i++) {
            vetorB[i] = input.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            vetorC[i * 2] = vetorA[i];
            vetorC[i * 2 + 1] = vetorB[i];
        }
        System.out.println("Valores intercalados do terceiro vetor: ");
        for (int i = 0; i < 10; i++) {
            System.out.print(vetorC[i]+" ");
        }
    }
}
