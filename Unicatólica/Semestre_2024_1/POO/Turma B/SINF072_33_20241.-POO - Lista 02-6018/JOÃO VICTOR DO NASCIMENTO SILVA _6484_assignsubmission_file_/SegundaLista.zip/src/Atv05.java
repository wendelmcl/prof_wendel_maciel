import java.util.Scanner;

public class Atv05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int b = 0;

        System.out.println("Quais os numeros que você deseja verificar?");
        int a = input.nextInt()+1;
        b = input.nextInt();

        for (int i = a; i <b; i++) {
            System.out.print(i+" ");
        }

    }
}
