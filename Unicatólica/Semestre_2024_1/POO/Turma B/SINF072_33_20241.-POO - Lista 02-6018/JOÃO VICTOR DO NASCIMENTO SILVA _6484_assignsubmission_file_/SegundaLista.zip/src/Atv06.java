import java.util.Scanner;

public class Atv06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numAlunos = 10;

        double[] medias = new double[numAlunos];
        double nota1,nota2,nota3,nota4;

        for (int i = 0; i < numAlunos; i++) {
            System.out.println("Digite as quatro notas do aluno " + (i + 1) + ":");
            nota1 = scanner.nextDouble();
            nota2 = scanner.nextDouble();
            nota3 = scanner.nextDouble();
            nota4 = scanner.nextDouble();


            double media = (nota1 + nota2 + nota3 + nota4) / 4;
            medias[i] = media;
        }


        int contador = 0;
        for (double media : medias) {
            if (media >= 7.0) {
                contador++;
            }
        }

        System.out.println("Número de alunos com média maior ou igual a 7.0: " + contador);
    }
}