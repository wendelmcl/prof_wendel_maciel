import java.util.Scanner;

public class Atv09 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite 10 numeros inteiros:");
        int[] A = new int[10];

        for (int i = 0; i < 10; i++) {
            A[i] = input.nextInt();
        }
        int somaQuadrados = 0;
        for (int i = 0; i < 10; i++) {
            somaQuadrados += A[i] * A[i];
        }
        System.out.println("A soma dos quadrados é: "+somaQuadrados);
    }

}
