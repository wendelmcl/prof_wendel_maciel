import java.util.Scanner;

public class Atv02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double maior = 0;
        double numero = 0;
        System.out.println("Digite 5 numeros");

        for (int i = 0; i < 5; i++) {
            numero = input.nextDouble();
            maior = Math.max(maior,numero);
        }
        System.out.println("O maior numero é o "+maior);
    }
}
