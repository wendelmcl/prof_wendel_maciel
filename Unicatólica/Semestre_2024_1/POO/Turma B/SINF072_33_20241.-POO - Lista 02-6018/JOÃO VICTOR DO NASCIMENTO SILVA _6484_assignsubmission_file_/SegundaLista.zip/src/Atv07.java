import java.util.Scanner;

public class Atv07 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int soma = 0;
        int multiplicacao = 1;
        int[] numero = new int[5];
        System.out.println("Digite os 5 numeros");

        for (int i = 0; i < 5; i++) {
            numero[i] = input.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            soma = soma + numero[i];
            multiplicacao = multiplicacao * numero[i];
        }
        System.out.println("Os numeros digitados foram: ");
        for (int i = 0; i < 5; i++) {
            System.out.println(numero[i]);
        }
        System.out.println("A soma dos numeros é: "+soma);
        System.out.println("A multiplicação dos numeros é: "+multiplicacao);
        }
    }
