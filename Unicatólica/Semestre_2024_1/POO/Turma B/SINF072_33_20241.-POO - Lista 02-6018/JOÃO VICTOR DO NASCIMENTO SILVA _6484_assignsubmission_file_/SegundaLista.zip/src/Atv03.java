import java.util.Scanner;

public class Atv03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double acumulador = 0;
        double media = 0;
        double valor = 0;
        System.out.println("Digite 5 numeros");

        for (int i = 0; i < 5; i++) {
            valor = input.nextDouble();
            acumulador += valor;
        }
        media = acumulador /5;

        System.out.println("A soma total é "+acumulador);
        System.out.println("A media é "+media);
    }
}
