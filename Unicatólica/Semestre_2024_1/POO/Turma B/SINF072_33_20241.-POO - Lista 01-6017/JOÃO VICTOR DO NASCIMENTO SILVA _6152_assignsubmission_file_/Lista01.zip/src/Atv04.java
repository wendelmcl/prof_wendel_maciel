import java.util.Scanner;

public class Atv04 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        double f, c;
        System.out.println("Qual a temperatura em Fahrenheit?");
        f = scan.nextDouble();
        c = 5 * (f-32) / 9;
        System.out.printf("O valor em Celsius é: %.2f",c);


    }
}