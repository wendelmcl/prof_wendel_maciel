import java.util.Scanner;

public class Atv09 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double a,b,c;
        System.out.println("Digite três números:");
        a = scan.nextDouble();
        b = scan.nextDouble();
        c = scan.nextDouble();

        if (a >= b && a >= c) {
            if (b >= c) {
                System.out.println("Os números digitados em ordem decrescente são: " + a + ", " + b + ", " + c);
            } else {
                System.out.println("Os números digitados em ordem decrescente são: " + a + ", " + c + ", " + b);
            }
        } else if (b >= a && b >= c) {
            if (a >= c) {
                System.out.println("Os números digitados em ordem decrescente são: " + b + ", " + a + ", " + c);
            } else {
                System.out.println("Os números digitados em ordem decrescente são: " + b + ", " + c + ", " + a);
            }
        } else {
            if (a >= b) {
                System.out.println("Os números digitados em ordem decrescente são: " + c + ", " + a + ", " + b);
            } else {
                System.out.println("Os números digitados em ordem decrescente são: " + c + ", " + b + ", " + a);
            }
        }
    }
}