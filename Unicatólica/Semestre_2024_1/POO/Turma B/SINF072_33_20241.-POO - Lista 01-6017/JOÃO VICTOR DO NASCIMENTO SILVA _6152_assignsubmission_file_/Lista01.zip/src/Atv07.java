import java.util.Scanner;

public class Atv07 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a,b,c,maior,menor;
        System.out.println("Digite o primeiro valor:");
        a = scan.nextInt();
        System.out.println("Digite o segundo valor:");
        b = scan.nextInt();
        System.out.println("Digite o terceiro valor:");
        c = scan.nextInt();

        maior = Math.max(a, Math.max(b, c));
        menor = Math.min(a,Math.min(b,c));
        System.out.println("O maior numero é o "+maior);
        System.out.println("O menor numero é o "+menor);


    }
}