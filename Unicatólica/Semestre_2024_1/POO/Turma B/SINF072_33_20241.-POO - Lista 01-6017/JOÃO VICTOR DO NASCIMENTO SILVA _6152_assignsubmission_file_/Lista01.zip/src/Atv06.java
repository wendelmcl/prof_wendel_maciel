import java.util.Scanner;

public class Atv06 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a,b,c,maior;
        System.out.println("Digite o primeiro valor:");
        a = scan.nextInt();
        System.out.println("Digite o segundo valor:");
        b = scan.nextInt();
        System.out.println("Digite o terceiro valor:");
        c = scan.nextInt();

        maior = Math.max(a, Math.max(b, c));
        System.out.println("O maior numero é o "+maior);


    }
}