import java.util.Scanner;

public class Atv01 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double raio,total;
        System.out.println("Digite o raio do círculo: ");
        raio = scan.nextDouble();
        total = (raio * raio) * 3.1415;

        System.out.println("A área do circulo é "+total);
    }
}
