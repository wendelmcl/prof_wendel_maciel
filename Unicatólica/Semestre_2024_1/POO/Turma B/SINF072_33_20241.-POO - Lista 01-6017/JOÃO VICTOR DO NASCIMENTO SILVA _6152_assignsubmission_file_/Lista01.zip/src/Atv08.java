import java.util.Scanner;

public class Atv08 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite o nome e preço dos 3 produtos");
        System.out.println("Digite o primeiro produto:");
        String na = scan.next();
        double pa = scan.nextDouble();
        System.out.println("Digite o segundo produto:");
        String nb = scan.next();
        double pb = scan.nextDouble();
        System.out.println("Digite o terceiro produto:");
        String nc = scan.next();
        double pc = scan.nextDouble();

        if (pa < pb && pa < pc) {
            System.out.println("O produto mais barato é "+na+" custando "+pa);
        } else if (pb < pa && pb < pc) {
            System.out.println("O produto mais barato é "+nb+" custando "+pb);
        } else {
            System.out.println("O produto mais barato é "+nc+" custando "+pc);
        }
    }
}
