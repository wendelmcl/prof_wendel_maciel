import java.util.Scanner;

public class Atv10 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String horario;
        System.out.println("Em que turno você estuda?");
        System.out.println("Digite M-Manhã V-Tarde N-Noite");
        horario = scan.next();
        
        if (horario.equals("M")) {
            System.out.println("Bom Dia!");
        }else if (horario.equals("V")) {
            System.out.println("Boa Tarde!");
        }else if (horario.equals("N")) {
            System.out.println("Boa noite!");
        }else{
            System.out.println("Valor Invalido!");
        }

    }
}
