import java.util.Scanner;

public class Atv02 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double base, resultado, dobro;
        System.out.println("Qual o comprimento da base do quadrado em metros?");
        base = scan.nextDouble();

        resultado = base * base;
        dobro = resultado * 2;
        System.out.println("A area do quadrado é "+resultado+" Metros");
        System.out.println("E seu dobro é "+dobro+ "Metros");
    }
}