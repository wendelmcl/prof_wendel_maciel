import java.util.Scanner;

public class Atv05 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        double f, c;
        System.out.println("Qual a temperatura em Celsius?");
        c = scan.nextDouble();
        f = (c * 1.8) + 32;
        System.out.printf("O valor em Fahrenheit é: %.2f",f);


    }
}