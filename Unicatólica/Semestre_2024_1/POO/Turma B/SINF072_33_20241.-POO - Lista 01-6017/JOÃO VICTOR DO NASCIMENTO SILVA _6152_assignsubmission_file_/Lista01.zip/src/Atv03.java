import java.util.Scanner;

public class Atv03 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double hora, mes, total;
        System.out.println("Quanto você recebe por hora?");
        hora = scan.nextDouble();
        System.out.println("Quantas horas você trabalhou esse mes?");
        mes = scan.nextDouble();

        total = (int) hora * mes;
        System.out.println("Você recebera "+total+" reais esse mês.");


    }
}