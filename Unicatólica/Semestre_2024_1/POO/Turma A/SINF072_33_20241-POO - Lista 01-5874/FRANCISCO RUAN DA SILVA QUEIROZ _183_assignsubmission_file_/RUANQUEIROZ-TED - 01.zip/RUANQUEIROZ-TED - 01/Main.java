import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // QUESTAO 1
        System.out.print("Digite o raio do círculo: ");
        double raio = scanner.nextDouble();
        double areaCirculo = Math.PI * Math.pow(raio, 2);
        System.out.println("A área do círculo é: " + areaCirculo);
        
        // QUESTAO 2
        System.out.print("Digite o lado do quadrado: ");
        double lado = scanner.nextDouble();
        double areaQuadrado = Math.pow(lado, 2);
        System.out.println("O dobro da área do quadrado é: " + (2 * areaQuadrado));
        
        // QUESTAO 3
        System.out.print("Digite quanto você ganha por hora: ");
        double salarioPorHora = scanner.nextDouble();
        System.out.print("Digite o número de horas trabalhadas no mês: ");
        int horasTrabalhadas = scanner.nextInt();
        double salarioTotal = salarioPorHora * horasTrabalhadas;
        System.out.println("Seu salário total neste mês é: " + salarioTotal);
        
        // QUESTAO 4
        System.out.print("Digite a temperatura em Fahrenheit: ");
        double tempFahrenheit = scanner.nextDouble();
        double tempCelsius = 5 * ((tempFahrenheit - 32) / 9);
        System.out.println("A temperatura em Celsius é: " + tempCelsius);
        
        // QUESTAO 5
        System.out.print("Digite a temperatura em Celsius: ");
        double tempCelsius2 = scanner.nextDouble();
        double tempFahrenheit2 = (tempCelsius2 * 9/5) + 32;
        System.out.println("A temperatura em Fahrenheit é: " + tempFahrenheit2);
        
        // QUESTAO 6
        System.out.print("Digite três números separados por espaços: ");
        double num1 = scanner.nextDouble();
        double num2 = scanner.nextDouble();
        double num3 = scanner.nextDouble();
        double maior = Math.max(num1, Math.max(num2, num3));
        System.out.println("O maior número é: " + maior);
        
        // QUESTAO 7
        System.out.print("Digite três números separados por espaços: ");
        double num4 = scanner.nextDouble();
        double num5 = scanner.nextDouble();
        double num6 = scanner.nextDouble();
        double maior2 = Math.max(num4, Math.max(num5, num6));
        double menor = Math.min(num4, Math.min(num5, num6));
        System.out.println("O maior número é: " + maior2);
        System.out.println("O menor número é: " + menor);
        
        // QUESTAO 8
        System.out.print("Digite o preço do primeiro produto: ");
        double preco1 = scanner.nextDouble();
        System.out.print("Digite o preço do segundo produto: ");
        double preco2 = scanner.nextDouble();
        System.out.print("Digite o preço do terceiro produto: ");
        double preco3 = scanner.nextDouble();
        double menorPreco = Math.min(preco1, Math.min(preco2, preco3));
        System.out.println("Você deve comprar o produto de preço: " + menorPreco);
        
        // QUESTAO 9
        System.out.print("Digite três números separados por espaços: ");
        double num7 = scanner.nextDouble();
        double num8 = scanner.nextDouble();
        double num9 = scanner.nextDouble();
        double[] numeros = {num7, num8, num9};
        java.util.Arrays.sort(numeros);
        System.out.println("Os números em ordem decrescente são: " + numeros[2] + ", " + numeros[1] + ", " + numeros[0]);
        
        // QUESTAO 10
        System.out.print("Em que turno você estuda (M-matutino, V-Vespertino, N-Noturno): ");
        String turno = scanner.next();
        switch (turno.toUpperCase()) {
            case "M":
                System.out.println("Bom Dia!");
                break;
            case "V":
                System.out.println("Boa Tarde!");
                break;
            case "N":
                System.out.println("Boa Noite!");
                break;
            default:
                System.out.println("Valor Inválido!");
        }
        
        scanner.close();
    }
}