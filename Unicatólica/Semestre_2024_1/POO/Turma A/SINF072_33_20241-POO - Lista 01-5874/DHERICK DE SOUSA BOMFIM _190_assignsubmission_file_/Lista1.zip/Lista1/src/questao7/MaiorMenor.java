package questao7;

import java.util.Scanner;

public class MaiorMenor {

	public static void main(String[] args) {
		int n1, n2, n3;
		Scanner sc = new Scanner(System.in);
		System.out.print("Primeiro número : ");
		n1 = sc.nextInt();
		
		System.out.print("Segundo número : ");
		n2 = sc.nextInt();
		
		System.out.print("Terceiro número : ");
		n3 = sc.nextInt();
		
		System.out.print("\nMaior número : ");
		
		if (n1 > n2 && n1 > n3) {
			System.out.println(n1);
		}else if(n2 > n1 && n2 > n3) {
			System.out.println(n2);
		}else {
			System.out.println(n3);
		}
		
		System.out.print("Menor número : ");
		
		if (n1 < n2 && n1 < n3) {
			System.out.print(n1);
		}else if(n2 < n1 && n2 < n3) {
			System.out.print(n2);
		}else {
			System.out.print(n3);
		}
		sc.close();
	}
}
