package questao5;

import java.util.Scanner;

public class CelsiusToFahrenheit {

	public static void main(String[] args) {
		float celsius;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Temperatura em Cº : ");
		celsius = sc.nextFloat();
		
		float fahr =(float)((celsius * 1.8) + 32);
		
		System.out.printf("Temperatura em Graus Fahrenheit é de %4.1f ºc", fahr);
		
		sc.close();

	}

}
