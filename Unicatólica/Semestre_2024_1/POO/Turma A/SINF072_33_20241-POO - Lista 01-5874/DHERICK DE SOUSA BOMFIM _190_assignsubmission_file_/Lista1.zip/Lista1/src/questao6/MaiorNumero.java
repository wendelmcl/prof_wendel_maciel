package questao6;

import java.util.Scanner;

public class MaiorNumero {

	public static void main(String[] args) {
		int n1, n2, n3;
		Scanner sc = new Scanner(System.in);
		System.out.println("Primeiro número : ");
		n1 = sc.nextInt();
		
		System.out.println("Segundo número : ");
		n2 = sc.nextInt();
		
		System.out.println("Terceiro número : ");
		n3 = sc.nextInt();
		
		System.out.println("Maior número : ");
		
		if (n1 > n2 && n1 > n3) {
			System.out.println(n1);
		}else if(n2 > n1 && n2 > n3) {
			System.out.println(n2);
		}else {
			System.out.println(n3);
		}
		sc.close();
	}

}
