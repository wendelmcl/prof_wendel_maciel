package questao9;

import java.util.Scanner;

public class ExecucaoDecres {

	public static void main(String[] args) {
		int n1, n2, n3;
		Scanner sc = new Scanner(System.in);
		System.out.println("Ordem Decrescente");
		
		System.out.println("1º número : ");
		n1 = sc.nextInt();
		System.out.println("2º número : ");
		n2 = sc.nextInt();
		System.out.println("3º número : ");
		n3 = sc.nextInt();
		
		OrdenarNumeros ordenador = new OrdenarNumeros(n1, n2, n3);
		
		ordenador.ordenarDecrescente();
		
		sc.close();
	}
}
