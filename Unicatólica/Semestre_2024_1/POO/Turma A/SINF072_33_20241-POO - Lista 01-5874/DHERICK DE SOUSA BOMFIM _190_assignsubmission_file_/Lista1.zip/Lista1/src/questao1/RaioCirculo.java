package questao1;

import java.util.Scanner;
import java.lang.Math;

public class RaioCirculo {

	public static void main(String[] args) {
		double raio;
		Scanner  sc = new Scanner(System.in);
		
		System.out.println("Qual será o raio do círculo?");
		raio = sc.nextDouble();
		
		double diametro = raio * 2;
		double area = 3.14 * (Math.pow(raio, 2));
		
		System.out.println("Diâmetro : " + diametro + "\nÁrea : " + area);
		sc.close();
	}

}
