package questao2;

import java.util.Scanner;

public class AreaQuadrado {

	public static void main(String[] args) {
		double lado;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Qual tamanho do lado do quadrado?");
		lado = sc.nextDouble();
		
		double area = lado * lado;
		double areaDobro = area * 2;
		
		System.out.println("Área : " + area + "\nDobro da Área : " + areaDobro);
		
		sc.close();
	}

}
