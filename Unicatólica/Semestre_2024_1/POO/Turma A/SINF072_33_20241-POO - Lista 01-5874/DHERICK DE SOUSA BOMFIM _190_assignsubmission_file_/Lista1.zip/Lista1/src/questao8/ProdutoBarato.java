package questao8;

import java.util.Scanner;

public class ProdutoBarato {

	public static void main(String[] args) {
		float prod1, prod2, prod3;
		Scanner sc = new Scanner(System.in);
		System.out.println("Qual o preço do primeiro produto?");
		prod1 = sc.nextFloat();
		
		System.out.println("Qual o preço do segundo produto?");
		prod2 = sc.nextFloat();
		
		System.out.println("Qual o preço do terceiro produto?");
		prod3 = sc.nextFloat();

		System.out.println("\nO produto mais barato é :");
		if (prod1 < prod2 && prod1 < prod3) {
			System.out.println("O primeiro produto. Leve-o!");
		}else if(prod2 < prod1 && prod2 < prod3) {
			System.out.println("O segundo produto. Leve-o!");
		}else {
			System.out.println("O terceiro produto. Leve-o!");
		}
		sc.close();
	}

}
