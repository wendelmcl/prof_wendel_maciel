package questao9;

	class OrdenarNumeros{
		private int n1, n2, n3;
		
		public OrdenarNumeros(int num1, int num2, int num3) {
			n1 = num1;
			n2 = num2;
			n3 = num3;
		}
		public void ordenarDecrescente() {
			int maior, medio, menor;
			if (n1 >= n2 && n1 >= n3) {
				maior = n1;
				if (n2 >= n3) {
					medio = n2;
					menor = n3;
				}else {
					medio = n3;
					menor = n2;
				}
			}else if (n2 >= n1 && n2 >= n3) {
				maior = n2;
				if (n1 >= n3) {
					medio = n1;
					menor = n3;
				}else {
					medio = n3;
					menor = n1;
				}
			}else {
				maior = n3;
				if (n2 >= n1) {
					medio = n2;
					menor = n1;
				}else {
					medio = n1;
					menor = n2;
				}
			}
			System.out.println("Ordem Decrescente : " + maior +", " + medio +", " + menor);
		}
		
	}
	
	
	

