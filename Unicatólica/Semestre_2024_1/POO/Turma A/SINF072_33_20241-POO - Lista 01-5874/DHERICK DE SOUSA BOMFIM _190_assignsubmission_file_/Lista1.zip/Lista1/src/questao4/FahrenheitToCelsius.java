package questao4;

import java.util.Scanner;

public class FahrenheitToCelsius {

	public static void main(String[] args) {
		float Fahr;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Temperatura em Fº : ");
		Fahr = sc.nextFloat();
		
		float celsius = 5 * ((Fahr - 32)/9);
		
		System.out.printf("Temperatura em Graus Celsius é de %4.1f ºc", celsius);
		
		sc.close();
	}
}
