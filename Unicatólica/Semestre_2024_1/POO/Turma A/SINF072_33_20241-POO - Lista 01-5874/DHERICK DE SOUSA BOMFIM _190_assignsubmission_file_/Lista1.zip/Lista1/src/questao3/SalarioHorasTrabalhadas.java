package questao3;

import java.util.Scanner;

public class SalarioHorasTrabalhadas {

	public static void main(String[] args) {
		float valorHora;
		int horasMes;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Quanto você ganha por hora trabalhada?");
		valorHora = sc.nextFloat();
		
		System.out.println("Quantas horas você trabalha por mês?");
		horasMes = sc.nextInt();
		
		float salarioTot = valorHora * horasMes; 
		
		System.out.println("Salário: R$ "+ salarioTot);
		
		sc.close();
	}

}
