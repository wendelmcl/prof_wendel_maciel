package questaoo10;

import java.util.Scanner;

public class Periodo {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		String turno = "";
		
		System.out.println("Em qual turno você estuda? \n\n\"M\" para \"Matutino\" \n\"V\" para \"Vespertino\" \n\"N\" para \"Noturno\"\"");
		turno = sc.next();
		
		if (turno.equals("M")) {
			System.out.println("Bom dia!");
		}else if (turno.equals("V")) {
			System.out.println("Boa tarde!");
		}else if (turno.equals("N")) {
			System.out.println("Boa noite!");
		}else {
			System.out.println("Valor Inválido!");
		}
		sc.close();
	}

}
