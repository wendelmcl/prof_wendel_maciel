package Lista_01;



	import java.util.Scanner;
	import java.util.Arrays;

	public class Q9 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Digite três números:");

	        double[] numeros = new double[3];
	        for (int i = 0; i < 3; i++) {
	            System.out.print("Número " + (i+1) + ": ");
	            numeros[i] = scanner.nextDouble();
	        }

	        Arrays.sort(numeros);
	        double temp;
	        for (int i = 0; i < 3 / 2; i++) {
	            temp = numeros[i];
	            numeros[i] = numeros[3 - i - 1];
	            numeros[3 - i - 1] = temp;
	        }

	        System.out.println("Números em ordem decrescente:");
	        for (int i = 0; i < 3; i++) {
	            System.out.println(numeros[i]);
	        }
	    }
	}
