package Lista_01;

import java.util.Scanner;

public class Q10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Em que turno você estuda? (M - Matutino, V - Vespertino, N - Noturno): ");
        char turno = scanner.next().charAt(0);

        if (turno == 'M' || turno == 'm') {
            System.out.println("Bom Dia!");
        } else if (turno == 'V' || turno == 'v') {
            System.out.println("Boa Tarde!");
        } else if (turno == 'N' || turno == 'n') {
            System.out.println("Boa Noite!");
        } else {
            System.out.println("Valor Inválido!");
        }
    }
}
