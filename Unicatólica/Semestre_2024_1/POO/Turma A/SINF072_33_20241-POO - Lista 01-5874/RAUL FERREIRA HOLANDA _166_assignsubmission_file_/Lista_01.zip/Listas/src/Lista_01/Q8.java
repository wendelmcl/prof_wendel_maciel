package Lista_01;

import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        Scanner Leitor = new Scanner(System.in);

        System.out.println("Insira o valor de produto 1: ");
        int produto1 = Leitor.nextInt();
        System.out.println("Insira o valor de produto 2: ");
        int produto2 = Leitor.nextInt();
        System.out.println("Insira o valor de produto 3: ");
        int produto3 = Leitor.nextInt();
        int baratisse = Math.min(Math.min(produto1, produto2), produto3);
        if (baratisse == produto1){
            System.out.println("Produto 1 é o mais barato");
        } else if (baratisse == produto2){
            System.out.println("Produto 2 é mais barato");
        } else if(baratisse==produto3){
            System.out.println("Produto 3 é o mais barato");
        }
    }
}
         
