package poo;
import java.util.Scanner;

public class Decrescente {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite três numeros: ");
		double numero1 = sc.nextDouble();
		double numero2 = sc.nextDouble();
		double numero3 = sc.nextDouble();
		
		double maior = Math.max(numero1, Math.max(numero2, numero3));
		double menor = Math.min(numero1, Math.min(numero2, numero3));
		double meio = numero1 + numero2 + numero3 - maior - menor;
		
		System.out.println("Os numeros em ordem decrescente é: " + maior + "," + meio + "," + menor);
		sc.close();
	}
}
