package poo;
import java.util.Scanner;

public class Numeros {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite três numeros: ");
		int nu1 = sc.nextInt();
		int nu2 = sc.nextInt();
		int nu3 = sc.nextInt();
		
		if (nu1 > nu2 && nu1 > nu3) {
			System.out.println("O primeiro numero é maior! " + nu1);
		}else if (nu2 > nu1 && nu2 > nu3) {
			System.out.println("O segundo numero é maior! " + nu2);
		}else {
			System.out.println("O terceiro numero é maior! " + nu3);
		}
		sc.close();
	}
}
