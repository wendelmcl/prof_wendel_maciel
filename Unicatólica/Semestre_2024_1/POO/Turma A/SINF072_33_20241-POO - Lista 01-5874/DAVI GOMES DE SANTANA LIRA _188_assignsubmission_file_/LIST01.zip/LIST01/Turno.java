package poo;
import java.util.Scanner;

public class Turno {

	public static void main(String[] args) {
		Scanner myObj = new Scanner(System.in);
		
		System.out.println("M-matutino, V-Vespertino, N-Noturno");
		System.out.println("Qual turno você estuda? ");
		String userTurno = myObj.nextLine();
			if (userTurno == "M") 
				System.out.println("Bom dia!");
			else if (userTurno == "V") 
				System.out.println("Boa tarde!");
			else 
				System.out.println("Boa noite!");

	}

}