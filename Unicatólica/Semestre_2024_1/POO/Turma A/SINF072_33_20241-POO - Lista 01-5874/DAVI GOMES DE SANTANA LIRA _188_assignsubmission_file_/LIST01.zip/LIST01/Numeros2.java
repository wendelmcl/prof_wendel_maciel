package poo;
import java.util.Scanner;

public class Numeros2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite três numeros: ");
		double n1 = sc.nextDouble();
		double n2 = sc.nextDouble();
		double n3 = sc.nextDouble();
		
		double maior = Math.max(n1, Math.max(n2, n3));
		double menor = Math.min(n1, Math.min(n2, n3));
		
		System.out.println("Maior: " + maior + " menor: " + menor);
		sc.close();
	}
}
