package poo;
import java.util.Scanner;

public class AreaQuadrado {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o comprimento do quadrado: ");
		int comp = sc.nextInt();
		
		System.out.println("Digite a altura do quadrado: ");
		int alt = sc.nextInt();
		
		int total = (comp * alt);
				
		System.out.println("A área do quadrado é: " + total + " e o dobro é: " + total*2);
				
		sc.close();
	}
}
