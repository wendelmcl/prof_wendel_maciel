package poo;
import java.util.Scanner;

public class Graus {
	public static void main(System[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a temp. em Fahrenheit: ");
		double gFah = sc.nextDouble();
		
		double celsius = 5 * ((gFah-32)/9);
		
		System.out.println("Temperatura em Celsius: " + celsius);
		sc.close();
	}
}
