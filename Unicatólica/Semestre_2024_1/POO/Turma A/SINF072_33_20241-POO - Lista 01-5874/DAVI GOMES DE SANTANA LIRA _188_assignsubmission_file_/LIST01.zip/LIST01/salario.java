package poo;
import java.util.Scanner;

public class salario {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Quanto você ganha por hora? ");
		double sHora = sc.nextDouble();
		
		System.out.println("Quantas horas você trabalhou no mês? ");
		double mHora = sc.nextDouble();
		
		double total = (mHora * sHora);
		
		System.out.println("Salario final: " + total);
		sc.close();
	}

}
