package poo;
import java.util.Scanner;

public class Produto {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o preço de três produtos: ");
		double prod1 = sc.nextDouble();
		double prod2 = sc.nextDouble();
		double prod3 = sc.nextDouble();
		
		double barato = Math.min(prod1, Math.min(prod2, prod3));
		
		System.out.println("Você deve comprar o produto mais barato de: R$ " + barato);
		sc.close();
	}
}
