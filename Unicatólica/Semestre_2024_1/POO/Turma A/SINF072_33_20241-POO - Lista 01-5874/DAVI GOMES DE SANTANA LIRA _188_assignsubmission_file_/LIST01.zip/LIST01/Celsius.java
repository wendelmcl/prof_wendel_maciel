package poo;
import java.util.Scanner;

public class Celsius {
	public static void main(System[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a temp. em Celsius: ");
		double celsius = sc.nextDouble();
		
		double tFah = celsius * 1.8 + 32;
		
		System.out.println("Temperatura em Fahrenheit: " + tFah);
		sc.close();
	}
}