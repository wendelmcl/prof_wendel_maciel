package pt04;

import java.text.DecimalFormat;
import java.util.Scanner;
public class Pt04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a temperatura em Fahrenheit: \n");
        double fahrenheit = sc.nextDouble();

        double celsius = 5*((fahrenheit-32)/9);
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(3);
        sc.close();
        System.out.println("Temperatura em Celsius: " + df.format(celsius));

    }
}
