package pt08;

import java.util.Scanner;

public class Pt08 {
    public static void main(String[] args) {
        System.out.println("Digite três números");
        Scanner sc = new Scanner(System.in);

        System.out.println("Primeiro número: ");
        int n1 = sc.nextInt();

        System.out.println("Segundo número: ");
        int n2 = sc.nextInt();

        System.out.println("Terceiro número: ");
        int n3 = sc.nextInt();
        sc.close();

        int menor = Math.min(Math.min(n1, n2),n3);
        int maior = Math.max(Math.max(n1, n2),n3);

        int meio = 0;
        boolean Gemeos = false;
        if( maior != n1 && menor != n1 ){
            meio = n1;
           
        } else if( maior != n2 && menor != n2 ){
            meio = n2;
        } else if( maior != n3 && menor != n3 ){
            meio = n3;
        } else{
            System.out.println("Números semelhantes");
            Gemeos = true;
        }

        if( Gemeos == false ){
            System.out.println("1º " + maior + "\n" + "2º " + meio + "\n" + "3º " + menor);
        } 
    }
}
