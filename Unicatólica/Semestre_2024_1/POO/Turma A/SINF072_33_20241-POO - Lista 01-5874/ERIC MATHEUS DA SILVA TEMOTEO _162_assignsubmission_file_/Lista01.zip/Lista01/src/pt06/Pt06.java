package pt06;

import java.util.Scanner;

public class  Pt06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o primeiro número: ");
        int num1 = sc.nextInt();
        System.out.println("Digite o segundo número: ");
        int num2 = sc.nextInt();
        System.out.println("Digite o terceiro número: ");
        int num3 = sc.nextInt();
        sc.close();
        if(num1 == num2 && num2 == num3){
            System.out.println("Os três números são iguais!");
        } else {
            int maior = Math.max(Math.max(num1, num2), num3);
            System.out.println("O maior é: " + maior);
            int menor = Math.min(Math.min(num1, num2), num3);
            System.out.println("O menor é: " + menor);
        }  
    }
}
