package pt07;

import java.util.Scanner;

public class Pt07 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o valor de produto 1: ");
        int produto1 = sc.nextInt();
        System.out.println("Digite o valor de produto 2: ");
        int produto2 = sc.nextInt();
        System.out.println("Digite o valor de produto 3: ");
        int produto3 = sc.nextInt();
        int baratisse = Math.min(Math.min(produto1, produto2), produto3);
        if (baratisse == produto1){
            System.out.println("Produto 1 é o mais barato");
        } else if (baratisse == produto2){
            System.out.println("Produto 2 é mais barato");
        } else if(baratisse==produto3){
            System.out.println("Produto 3 é o mais barato");
        }
        
    
    sc.close();
    }
}
