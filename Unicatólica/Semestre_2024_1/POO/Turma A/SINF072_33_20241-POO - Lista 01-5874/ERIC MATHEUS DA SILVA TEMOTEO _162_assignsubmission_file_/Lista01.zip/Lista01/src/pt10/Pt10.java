package pt10;

import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;


public class Pt10 {
    public static void main(String[] args) {
        Map<String, String> saudacao = new HashMap<>();
        saudacao.put("M", "Bom Dia!");
        saudacao.put("T", "Boa Tarde!");
        saudacao.put("N", "Boa Noite!");

        Scanner sc = new Scanner(System.in);
        System.out.println("Em que turno você estuda? (M para manha , T para tarde, N para noite)");
        String turno = sc.next().toUpperCase();
        sc.close();
        String saudacaoAgora = saudacao.containsKey(turno) ? saudacao.get(turno) : "Valor Inválido!";

        System.out.println(saudacaoAgora);
        
    }
}
