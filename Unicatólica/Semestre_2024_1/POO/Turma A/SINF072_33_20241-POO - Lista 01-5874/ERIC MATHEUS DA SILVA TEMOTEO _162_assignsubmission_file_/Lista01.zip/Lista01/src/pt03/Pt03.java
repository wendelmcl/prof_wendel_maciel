package pt03;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Pt03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a temperatura em Celsius");
        double celsius = sc.nextDouble();
        sc.close();
        double fahrenheit = (celsius * 1.8) + 32;
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(3);
        System.out.println("Temperatura em Fahrenheit: " + df.format(fahrenheit));
    }
}
