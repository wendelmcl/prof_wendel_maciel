package pt02;

import java.util.Scanner;

public class Pt02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int lado = sc.nextInt();
        sc.close();
        int area = lado * lado;
        System.out.println("A área é igual a " + area);
        area = area * 2;
        System.out.println("O dobro da área é igual a " + area);
    }
}