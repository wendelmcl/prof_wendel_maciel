package pt09;

import java.util.Scanner;
import java.text.DecimalFormat;


public class Pt09{

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Quanto você recebe por hora?");
        double PorHora = sc.nextDouble();
        System.out.println("Quanto você trabalhou nesse mês em horas?");
        int Horas = sc.nextInt();
        sc.close();

        double ValorDoMes = Horas * PorHora;
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(3);

        System.out.println("Total" + df.format(ValorDoMes));
    }
}