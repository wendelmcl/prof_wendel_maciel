package pt01;
import java.util.Scanner;
public class Pt01 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o raio: ");
        double raio = sc.nextDouble();
        double area = (3.14*(raio*raio));
        sc.close();
        System.out.println("Área igual a = " + area);

    }
}
