/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ted01;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double salario, hora, total;
        
        System.out.println("Digite o valor do slário por hora: ");
        salario = sc.nextDouble();
        System.out.println("Digite a quantidades de horas trabalhadas no mês: ");
        hora = sc.nextDouble();
        
        total = salario * hora;
        
        System.out.println("Seu salário no mes é" + total);
    }
    
}
