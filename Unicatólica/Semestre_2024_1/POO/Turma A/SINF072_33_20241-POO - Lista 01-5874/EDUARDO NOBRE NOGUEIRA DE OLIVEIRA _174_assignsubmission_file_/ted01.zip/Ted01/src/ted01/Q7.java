/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ted01;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Q7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int a, b, c;
        
        System.out.println("Digite um numero inteiro: ");
        a = sc.nextInt();
        System.out.println("Digite outro inteiro: ");
        b = sc.nextInt();
        System.out.println("Digite outro inteiro: ");
        c = sc.nextInt();
        
        if(a >= b && a >= c && b <= c){
            System.out.println("Maior: " + a);
            System.out.println("Menor: " + b);
        }if(a >= b && a >= c && c <= b){
            System.out.println("Maior: " + a);
            System.out.println("Menor: " + c);
        }else if(b >= c && b >= a && c <= a){
            System.out.println("Maior: " + b);
            System.out.println("Menor: " + c);
        }else if(b >= c && b >= a && a<=c){
            System.out.println("Maior: " + b);
            System.out.println("Menor: " + a);
        }else if(c >= b && c >= a && a<=b){
            System.out.println("Maior: " + c);
            System.out.println("Menor: " + a);
        }else if(c >= b && c >= a && b<=a){
            System.out.println("Maior: " + c);
            System.out.println("Menor: " + b);
        }else{
            System.out.println("Todos iguais");
        }
    }
    
}
