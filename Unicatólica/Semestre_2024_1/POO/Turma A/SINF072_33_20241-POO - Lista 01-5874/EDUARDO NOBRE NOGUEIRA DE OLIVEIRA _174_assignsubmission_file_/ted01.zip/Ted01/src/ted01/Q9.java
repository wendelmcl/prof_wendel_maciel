/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ted01;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Q9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int a, b, c;
        
        System.out.println("Digite um numero inteiro: ");
        a = sc.nextInt();
        System.out.println("Digite outro inteiro: ");
        b = sc.nextInt();
        System.out.println("Digite outro inteiro: ");
        c = sc.nextInt();
        
        if(a >= b && b >= c){
            System.out.println(a + "-" + b + "-" + c);
        }else if(b >= c && c >= a){
            System.out.println(b + "-" + c + "-" + a);
        }else if(b >= c && a >= c){
            System.out.println(b + "-" + a + "-" + c);
        }else if(a >= c && c >= b){
            System.out.println(a + "-" + c + "-" + b);
        }else if(c >= a && a >= b){
            System.out.println(b + "-" + a + "-" + c);
        }else{
            System.out.println(c + "-" + b + "-" + a);
        }
    }
    
}
