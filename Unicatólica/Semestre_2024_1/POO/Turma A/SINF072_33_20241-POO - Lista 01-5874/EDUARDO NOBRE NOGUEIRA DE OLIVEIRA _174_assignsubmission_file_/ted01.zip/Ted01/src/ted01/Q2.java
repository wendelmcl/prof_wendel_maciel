/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ted01;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Q2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        double b, dobroA;
        
        System.out.println("Digite a base do quadrado: ");
        b = sc.nextDouble();
        
        dobroA = 2*(b*b);
        
        System.out.println("O dobro da área do quadrado é: " + dobroA);
    }
    
}
