/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ted01;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Q8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        double p1, p2, p3;
        
        System.out.println("Valor do produto 1: ");
        p1 = sc.nextDouble();
        System.out.println("Valor do produto 2: ");
        p2 = sc.nextDouble();
        System.out.println("Valor do produto 3: ");
        p3= sc.nextDouble();
        
        if(p1 < p2 && p1 < p3){
            System.out.println("Produto 1 é o escolhido!");
        }
        if(p2 < p1 && p2 < p3){
            System.out.println("Produto 2 é o escolhido!");
        }
        if(p3 < p2 && p3 < p1){
            System.out.println("Produto 3 é o escolhido!");
        }
    }
    
}
