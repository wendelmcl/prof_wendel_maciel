/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ted01;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Q6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int a, b, c;
        
        System.out.println("Digite um numero inteiro: ");
        a = sc.nextInt();
        System.out.println("Digite outro inteiro: ");
        b = sc.nextInt();
        System.out.println("Digite outro inteiro: ");
        c = sc.nextInt();
        
        if(a >= b && a >= c){
            System.out.println("Maior: " + a);
        }else if(b >= c && b >= a){
            System.out.println("Maior: " + b);
        }else{
            System.out.println("Maior: " + c);
        }
        
    }
    
}
