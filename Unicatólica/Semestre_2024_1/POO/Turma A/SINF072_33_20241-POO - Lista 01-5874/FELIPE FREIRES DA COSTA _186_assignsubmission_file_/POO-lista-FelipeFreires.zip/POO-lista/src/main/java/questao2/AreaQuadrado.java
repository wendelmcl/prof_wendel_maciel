
package questao2;

import java.util.Scanner;

public class AreaQuadrado {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        double lado;
        double area;
        double areaDobro;
        
        System.out.println("Digite o lado do Quadrado: ");
        lado = sc.nextDouble();
        
        area = lado * lado;
        
        areaDobro = 2 * area;
        
        System.out.println("A area do quadrado é: "+ area);
        System.out.println("O dobro da are do quadrado é: " + areaDobro);
        
    }
}
