
package questao4;

import java.util.Scanner;

public class Graus {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        double graus;
        double Fgraus;
        
        System.out.println("Quantos graus Fahrenheit voce quer converter para celsius: ");
        graus = sc.nextDouble();
        
        Fgraus = (9.0 / 5.0) * graus + 32;
        
        System.out.println("A temperatura em Fahrenheit é: " + Fgraus);
    }
}
