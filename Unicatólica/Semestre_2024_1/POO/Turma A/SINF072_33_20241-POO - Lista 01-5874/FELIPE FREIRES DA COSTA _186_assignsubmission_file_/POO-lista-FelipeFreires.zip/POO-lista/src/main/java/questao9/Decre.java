
package questao9;

import java.util.Arrays;
import java.util.Scanner;


public class Decre {
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

            System.out.println("Digite três números separados por espaço:");
            double[] numeros = new double[3];


            for (int i = 0; i < 3; i++) {
                numeros[i] = scanner.nextDouble();
            }

            Arrays.sort(numeros);
            double temp;
            for (int i = 0; i < numeros.length / 2; i++) {
                temp = numeros[i];
                numeros[i] = numeros[numeros.length - 1 - i];
                numeros[numeros.length - 1 - i] = temp;
            }

            System.out.println("Os números em ordem decrescente são:");
            for (double numero : numeros) {
                System.out.println(numero);
            }

        scanner.close();
        }
    } 

