
package questao1;

import java.util.Scanner;


public class CirculoRaio {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        double raio;
        double area;
        System.out.println("Digite o raio do circulo"); 
        raio = sc.nextDouble();
        
        area = 3.14159 * (raio * raio);
        
        System.out.println("A area do circulo é: " + area);
        
    }
    
    
}
