
package questao6;

import java.util.Scanner;

public class NumeroMaior {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int num1;
        int num2;
        int num3;
        
        System.out.println("Digite um numero: ");
        num1 = sc.nextInt();
        System.out.println("Digite outro numero: ");
        num2 = sc.nextInt();
        System.out.println("Digite mais um numero:  ");
        num3 = sc.nextInt();
        
        if(num1 > num2){
            System.out.println("O maior numero é: "+ num1);
        }else if(num2 > num3){
            System.out.println("O maior numero é :" + num2);
        }else if(num3 > num2 ){
            System.out.println("O maior numero é: " + num3);
        }else{
            
        }

    }
}
