
package questao5;

import java.util.Scanner;


public class Fgraus {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double celsius;
        double fgraus;
        
        System.out.println("Quantos graus Celsius você quer converter para Fahrenheit: ");
        fgraus = sc.nextDouble();
        
        celsius = (5.0/9.0) * fgraus - 32;
        
        System.out.println("A temperatura em graus celsius é " + celsius);
    }
}
