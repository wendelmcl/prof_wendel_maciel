
package questao8;

import java.util.Scanner;


public class ProdutoBarato {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int prod1;
        int prod2;
        int prod3;
        
        
        
        System.out.println("Me informe o preço de 3 produtos: ");
        prod1 = sc.nextInt();
        prod2 = sc.nextInt();
        prod3 = sc.nextInt();
        
        if(prod1 < prod2 && prod1 < prod3){
            System.out.println("Compre o primeiro produto");
        }else if(prod2 < prod1 && prod2 < prod3){
            System.out.println("compre o segundo produto");
        }else{
            System.out.println("compre o terceiro produto");
        }
    }
   
}
