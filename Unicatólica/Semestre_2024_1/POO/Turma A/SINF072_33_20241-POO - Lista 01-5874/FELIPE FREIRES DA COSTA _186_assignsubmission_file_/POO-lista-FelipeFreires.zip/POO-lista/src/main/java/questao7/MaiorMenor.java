
package questao7;

import java.util.Scanner;


public class MaiorMenor {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int num1;
        int num2;
        int num3;
        
        System.out.println("Digite um numero: ");
        num1 = sc.nextInt();
        System.out.println("Digite mais um numero: ");
        num2 = sc.nextInt();
        System.out.println("DIgite mais um numero: ");
        num3 = sc.nextInt();
        
        int maiorNum = num1;
        int menorNum = num1;
        
        if(num2 > maiorNum){
            maiorNum = num2;
        }else if(num2 < menorNum){
            menorNum = num2;
        }
        
        if(num3 > maiorNum){
            maiorNum = num3;
        }else if(num3 < menorNum){
            menorNum = num3;
        }
        
        System.out.println("O maior numero é: " + maiorNum);
        System.out.println("O menor numero é: " + menorNum);
    }
}
