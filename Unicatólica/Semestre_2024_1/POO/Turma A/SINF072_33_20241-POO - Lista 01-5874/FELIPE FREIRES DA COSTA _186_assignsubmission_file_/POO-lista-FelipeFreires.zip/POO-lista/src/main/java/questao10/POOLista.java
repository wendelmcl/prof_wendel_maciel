
package questao10;

import java.util.Scanner;

public class POOLista {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("Em que turno voce estuda? M-matutino ou V-Vespertino ou N- Noturno: ");
        String hora = sc.next();
        
        if("M".equals(hora)){          
            System.out.println("Bom dia!!!! " );         
        }else if("V".equals(hora)){
            System.out.println("Boa tarde!!!" );
        }else{
            System.out.println("Boa noite!!!");
        }
        
    }
}
