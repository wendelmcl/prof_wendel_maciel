
package questao3;

import java.util.Scanner;


public class Salario {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int horas;
        int Ghora;
        int total;
        
        System.out.println("Quanto voce ganha por hora: ");
        Ghora = sc.nextInt();
        System.out.println("Quantas horas voce trabalha em um mês: ");
        horas = sc.nextInt();
        
        total = horas * Ghora; 
        
        System.out.println("Voce ganhar: "+ total + "R$ por mês");
    }
}
