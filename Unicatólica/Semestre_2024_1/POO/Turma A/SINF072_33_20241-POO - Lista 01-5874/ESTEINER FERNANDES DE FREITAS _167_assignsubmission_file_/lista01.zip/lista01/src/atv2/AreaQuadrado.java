package atv2;

import java.util.Scanner;

public class AreaQuadrado {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o lado do quadrado: ");
        double lado = scanner.nextDouble();

        double area = calcularAreaQuadrado(lado);
        double dobroArea = area * 2;

        System.out.println("A área do quadrado é: " + area);
        System.out.println("O dobro da área do quadrado é: " + dobroArea);

        scanner.close();
    }

    public static double calcularAreaQuadrado(double lado) {
        return lado * lado;
    }
}
