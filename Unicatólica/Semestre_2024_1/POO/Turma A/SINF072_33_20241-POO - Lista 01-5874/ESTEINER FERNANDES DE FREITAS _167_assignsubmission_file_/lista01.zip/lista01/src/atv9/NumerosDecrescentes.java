package atv9;

import java.util.Scanner;

public class NumerosDecrescentes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite três números separados por espaço:");
        double numero1 = scanner.nextDouble();
        double numero2 = scanner.nextDouble();
        double numero3 = scanner.nextDouble();

        exibirEmOrdemDecrescente(numero1, numero2, numero3);

        scanner.close();
    }

    public static void exibirEmOrdemDecrescente(double numero1, double numero2, double numero3) {
        if (numero1 >= numero2 && numero1 >= numero3) {
            if (numero2 >= numero3) {
                System.out.println(numero1 + " " + numero2 + " " + numero3);
            } else {
                System.out.println(numero1 + " " + numero3 + " " + numero2);
            }
        } else if (numero2 >= numero1 && numero2 >= numero3) {
            if (numero1 >= numero3) {
                System.out.println(numero2 + " " + numero1 + " " + numero3);
            } else {
                System.out.println(numero2 + " " + numero3 + " " + numero1);
            }
        } else {
            if (numero1 >= numero2) {
                System.out.println(numero3 + " " + numero1 + " " + numero2);
            } else {
                System.out.println(numero3 + " " + numero2 + " " + numero1);
            }
        }
    }
}
