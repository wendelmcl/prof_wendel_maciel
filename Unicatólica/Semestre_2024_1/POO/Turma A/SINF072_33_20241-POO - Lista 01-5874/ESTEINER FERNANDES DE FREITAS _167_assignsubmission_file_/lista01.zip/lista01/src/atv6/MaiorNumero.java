package atv6;

import java.util.Scanner;

public class MaiorNumero {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite três números separados por espaço:");
        double numero1 = scanner.nextDouble();
        double numero2 = scanner.nextDouble();
        double numero3 = scanner.nextDouble();

        double maior = encontrarMaior(numero1, numero2, numero3);

        System.out.println("O maior número é: " + maior);

        scanner.close();
    }

    public static double encontrarMaior(double numero1, double numero2, double numero3) {
        double maior = numero1;

        if (numero2 > maior) {
            maior = numero2;
        }

        if (numero3 > maior) {
            maior = numero3;
        }

        return maior;
    }
}
