package atv1;

import java.util.Scanner;

public class AreaCirculo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o raio do círculo: ");
        double raio = scanner.nextDouble();

        double area = calcularAreaCirculo(raio);

        System.out.println("A área do círculo é: " + area);

        scanner.close();
    }

    public static double calcularAreaCirculo(double raio) {
        return Math.PI * raio * raio;
    }
}
