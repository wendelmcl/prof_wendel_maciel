package atv3;

import java.util.Scanner;

public class CalculadoraSalario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor ganho por hora: ");
        double valorPorHora = scanner.nextDouble();

        System.out.print("Digite o número de horas trabalhadas no mês: ");
        double horasTrabalhadas = scanner.nextDouble();

        double salarioTotal = calcularSalarioTotal(valorPorHora, horasTrabalhadas);

        System.out.println("O total do seu salário no mês é: R$" + salarioTotal);

        scanner.close();
    }

    public static double calcularSalarioTotal(double valorPorHora, double horasTrabalhadas) {
        return valorPorHora * horasTrabalhadas;
    }
}