package atv4;

import java.util.Scanner;

public class ConversorFahrenheitCelsius {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a temperatura em Fahrenheit: ");
        double temperaturaFahrenheit = scanner.nextDouble();

        double temperaturaCelsius = converterParaCelsius(temperaturaFahrenheit);

        System.out.println("A temperatura em Celsius é: " + temperaturaCelsius + "°C");

        scanner.close();
    }

    public static double converterParaCelsius(double temperaturaFahrenheit) {
        return 5 * ((temperaturaFahrenheit - 32) / 9);
    }
}
