package atv5;

import java.util.Scanner;

public class ConversorCelsiusFahrenheit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a temperatura em Celsius: ");
        double temperaturaCelsius = scanner.nextDouble();

        double temperaturaFahrenheit = converterParaFahrenheit(temperaturaCelsius);

        System.out.println("A temperatura em Fahrenheit é: " + temperaturaFahrenheit + "°F");

        scanner.close();
    }

    public static double converterParaFahrenheit(double temperaturaCelsius) {
        return (9.0 / 5.0) * temperaturaCelsius + 32;
    }
}