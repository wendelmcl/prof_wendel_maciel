package atv8;

import java.util.Scanner;

public class ProdutoMaisBarato {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o preço do primeiro produto:");
        double preco1 = scanner.nextDouble();

        System.out.println("Digite o preço do segundo produto:");
        double preco2 = scanner.nextDouble();

        System.out.println("Digite o preço do terceiro produto:");
        double preco3 = scanner.nextDouble();

        String produtoMaisBarato = encontrarProdutoMaisBarato(preco1, preco2, preco3);

        System.out.println("Você deve comprar o produto de preço R$" + produtoMaisBarato);

        scanner.close();
    }

    public static String encontrarProdutoMaisBarato(double preco1, double preco2, double preco3) {
        if (preco1 <= preco2 && preco1 <= preco3) {
            return String.valueOf(preco1);
        } else if (preco2 <= preco1 && preco2 <= preco3) {
            return String.valueOf(preco2);
        } else {
            return String.valueOf(preco3);
        }
    }
}