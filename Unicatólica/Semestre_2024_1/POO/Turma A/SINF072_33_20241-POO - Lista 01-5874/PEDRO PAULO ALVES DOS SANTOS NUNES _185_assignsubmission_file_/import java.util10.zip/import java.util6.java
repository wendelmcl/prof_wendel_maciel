import java.util.Scanner;

public class Salario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite quanto você ganha por hora: ");
        double ganhoPorHora = scanner.nextDouble();
        System.out.print("Digite o número de horas trabalhadas no mês: ");
        double horasTrabalhadas = scanner.nextDouble();
        double salario = ganhoPorHora * horasTrabalhadas;
        System.out.printf("O salário no mês será de: %.2f", salario);
    }
}