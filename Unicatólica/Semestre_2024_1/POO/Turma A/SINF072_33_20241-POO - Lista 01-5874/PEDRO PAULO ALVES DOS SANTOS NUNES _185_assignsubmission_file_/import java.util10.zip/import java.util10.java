import java.util.Scanner;

public class TurnoEstudo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o turno em que você estuda (M-matutino, V-vespertino ou N-noturno): ");
        String turno = scanner.nextLine();
        switch (turno.toLowerCase()) {
            case "m":
                System.out.println("Bom Dia!");
                break;
            case "v":
                System.out.println("Boa Tarde!");
                break;
            case "n":
                System