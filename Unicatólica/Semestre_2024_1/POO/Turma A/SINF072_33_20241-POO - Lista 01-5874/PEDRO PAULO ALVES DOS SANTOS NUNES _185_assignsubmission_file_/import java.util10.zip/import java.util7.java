import java.util.Scanner;

public class Quadrado {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o lado de um quadrado: ");
        double lado = scanner.nextDouble();
        double area = lado * lado;
        System.out.printf("A área do quadrado de lado %.2f é: %.2f%n", lado, area);
        System.out.printf("O dobro da área do quadrado é: %.2f%n", area * 2);
    }
}