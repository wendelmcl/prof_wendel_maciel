import java.util.Scanner;

public class NumerosDecrescente {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o primeiro número: ");
        double num1 = scanner.nextDouble();
        System.out.print("Digite o segundo número: ");
        double num2 = scanner.nextDouble();
        System.out.print("Digite o terceiro número: ");
        double num3 = scanner.nextDouble();
        double[] numeros = {num1, num2, num3};
        Arrays.sort(numeros);
        System.out.printf("Os números em ordem decrescente são: %.2f, %.2f, %.2f%n", numeros[2], numeros[1], numeros[0]);
    }
}