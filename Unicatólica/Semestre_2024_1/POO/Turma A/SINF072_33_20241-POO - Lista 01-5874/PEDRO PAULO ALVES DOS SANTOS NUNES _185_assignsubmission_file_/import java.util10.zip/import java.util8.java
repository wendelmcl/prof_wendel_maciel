import java.util.Scanner;

public class Circulo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o raio de um círculo: ");
        double raio = scanner.nextDouble();
        double area = Math.PI * (raio * raio);
        System.out.printf("A área do círculo de raio %.2f é: %.2f%n", raio, area);
    }
}