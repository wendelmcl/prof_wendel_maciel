import java.util.Scanner;
public class q9 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário os três números
        System.out.print("Digite o primeiro número: ");
        double numero1 = entrada.nextDouble();
        System.out.print("Digite o segundo número: ");
        double numero2 = entrada.nextDouble();
        System.out.print("Digite o terceiro número: ");
        double numero3 = entrada.nextDouble();

        // Ordena os números em ordem decrescente usando um array temporário
        double[] numeros = {numero1, numero2, numero3};
        double auxiliar;
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros.length - i - 1; j++) {
                if (numeros[j] < numeros[j + 1]) {
                    auxiliar = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = auxiliar;
                }
            }
        }

        // Mostra os números em ordem decrescente
        System.out.println("Números em ordem decrescente:");
        for (double numero : numeros) {
            System.out.printf("%.2f ", numero);
        }
    }
}
