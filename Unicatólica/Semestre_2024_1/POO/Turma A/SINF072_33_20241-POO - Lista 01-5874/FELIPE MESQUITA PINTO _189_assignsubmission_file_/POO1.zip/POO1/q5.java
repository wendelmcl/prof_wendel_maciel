import java.util.Scanner;
public class q5 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário a temperatura em Celsius
        System.out.print("Digite a temperatura em Celsius: ");
        double celsius = entrada.nextDouble();

        // Converte Celsius para Fahrenheit usando a fórmula F = (C * 9/5) + 32
        double fahrenheit = celsius * 9 / 5 + 32;

        // Mostra a temperatura em Fahrenheit
        System.out.printf("A temperatura em Fahrenheit é: %.2f", fahrenheit);
    }
}
