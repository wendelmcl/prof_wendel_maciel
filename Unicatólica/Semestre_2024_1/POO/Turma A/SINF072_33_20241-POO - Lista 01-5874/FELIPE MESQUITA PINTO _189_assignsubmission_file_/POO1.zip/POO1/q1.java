
import java.util.Scanner;

public class q1 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário o valor do raio
        System.out.print("Digite o valor do raio do círculo: ");
        double raio = entrada.nextDouble();

        // Calcula a área do círculo usando pi * raio²
        double area = Math.PI * raio * raio;

        // Mostra o valor da área formatado com duas casas decimais
        System.out.printf("A área do círculo é: %.2f", area);
    }
}

