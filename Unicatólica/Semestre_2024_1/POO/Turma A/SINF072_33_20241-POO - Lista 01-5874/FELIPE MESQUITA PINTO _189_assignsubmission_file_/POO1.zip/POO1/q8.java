import java.util.Scanner;
public class q8 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário o preço dos três produtos
        System.out.print("Digite o preço do primeiro produto: ");
        double precoProduto1 = entrada.nextDouble();
        System.out.print("Digite o preço do segundo produto: ");
        double precoProduto2 = entrada.nextDouble();
        System.out.print("Digite o preço do terceiro produto: ");
        double precoProduto3 = entrada.nextDouble();

        // Encontra o produto mais barato usando comparações condicionais
        double precoProdutoMaisBarato = precoProduto1;
        String produtoMaisBarato = "Produto 1";
        if (precoProduto2 < precoProdutoMaisBarato) {
            precoProdutoMaisBarato = precoProduto2;
            produtoMaisBarato = "Produto 2";
        }
        if (precoProduto3 < precoProdutoMaisBarato) {
            precoProdutoMaisBarato = precoProduto3;
            produtoMaisBarato = "Produto 3";
        }

        // Indica qual produto é o mais barato
        System.out.printf("O %s é o mais barato, custando R$ %.2f", produtoMaisBarato, precoProdutoMaisBarato);
    }
}
