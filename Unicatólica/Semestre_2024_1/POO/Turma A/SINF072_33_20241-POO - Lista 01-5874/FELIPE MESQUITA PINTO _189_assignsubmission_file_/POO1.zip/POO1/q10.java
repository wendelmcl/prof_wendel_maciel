import java.util.Scanner;
public class q10 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário o turno de estudo
        System.out.print("Digite o turno de estudo (M-matutino, V-Vespertino ou N-Noturno): ");
        String turno = entrada.nextLine().toUpperCase();

        // Imprime a mensagem de acordo com o turno informado
        switch (turno) {
            case "M":
                System.out.println("Bom Dia!");
                break;
            case "V":
                System.out.println("Boa Tarde!");
                break;
            case "N":
                System.out.println("Boa Noite!");
                break;
            default:
                System.out.println("Valor Inválido!");
        }
    }

}
