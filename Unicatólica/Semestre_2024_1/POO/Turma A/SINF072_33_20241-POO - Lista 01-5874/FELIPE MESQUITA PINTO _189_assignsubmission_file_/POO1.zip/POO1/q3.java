import java.util.Scanner;
public class q3 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário o valor pago por hora e o número de horas trabalhadas
        System.out.print("Digite o valor que você recebe por hora: ");
        double valorHora = entrada.nextDouble();
        System.out.print("Digite o número de horas trabalhadas no mês: ");
        double horasTrabalhadas = entrada.nextDouble();

        // Calcula o salário mensal multiplicando o valor por hora pelas horas trabalhadas
        double salarioMensal = valorHora * horasTrabalhadas;

        // Mostra o valor do salário mensal
        System.out.printf("O seu salário mensal é de: R$ %.2f", salarioMensal);
    }   
}
