import java.util.Scanner;
public class q7 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário os três números
        System.out.print("Digite o primeiro número: ");
        double numero1 = entrada.nextDouble();
        System.out.print("Digite o segundo número: ");
        double numero2 = entrada.nextDouble();
        System.out.print("Digite o terceiro número: ");
        double numero3 = entrada.nextDouble();

        // Encontra o maior e o menor número usando comparações condicionais
        double maiorNumero = numero1;
        double menorNumero = numero1;
        if (numero2 > maiorNumero) {
            maiorNumero = numero2;
        } else if (numero2 < menorNumero) {
            menorNumero = numero2;
        }
        if (numero3 > maiorNumero) {
            maiorNumero = numero3;
        } else if (numero3 < menorNumero) {
            menorNumero = numero3;
        }

        // Mostra o maior e o menor número
        System.out.printf("O maior número é: %.2f", maiorNumero);
        System.out.printf("\nO menor número é: %.2f", menorNumero);
    }
}
