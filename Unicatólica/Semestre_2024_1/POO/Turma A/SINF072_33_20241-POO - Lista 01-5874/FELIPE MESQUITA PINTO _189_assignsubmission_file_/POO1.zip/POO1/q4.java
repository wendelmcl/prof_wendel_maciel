import java.util.Scanner;
public class q4
 {
    
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário a temperatura em Fahrenheit
        System.out.print("Digite a temperatura em Fahrenheit: ");
        double fahrenheit = entrada.nextDouble();

        // Converte Fahrenheit para Celsius usando a fórmula C = 5 * ((F-32) / 9)
        double celsius = (fahrenheit - 32) * 5 / 9;

        // Mostra a temperatura em Celsius
        System.out.printf("A temperatura em Celsius é: %.2f", celsius);
    }

}
