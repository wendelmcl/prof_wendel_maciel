
import java.util.Scanner;

public class q2 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário o valor do lado do quadrado
        System.out.print("Digite o valor do lado do quadrado: ");
        double lado = entrada.nextDouble();

        // Calcula a área do quadrado
        double areaQuadrado = lado * lado;

        // Calcula o dobro da área do quadrado
        double areaDobro = areaQuadrado * 2;

        // Mostra o valor da área do quadrado e o dobro da área
        System.out.printf("A área do quadrado é: %.2f", areaQuadrado);
        System.out.printf("\nO dobro da área do quadrado é: %.2f", areaDobro);
    }
}

