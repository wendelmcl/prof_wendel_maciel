import java.util.Scanner;
public class q6 {
    public static void main(String[] args) {
        // Cria um objeto Scanner para obter entrada do usuário
        Scanner entrada = new Scanner(System.in);

        // Solicita ao usuário os três números
        System.out.print("Digite o primeiro número: ");
        double numero1 = entrada.nextDouble();
        System.out.print("Digite o segundo número: ");
        double numero2 = entrada.nextDouble();
        System.out.print("Digite o terceiro número: ");
        double numero3 = entrada.nextDouble();

        // Encontra o maior número usando comparações condicionais
        double maiorNumero = numero1;
        if (numero2 > maiorNumero) {
            maiorNumero = numero2;
        }
        if (numero3 > maiorNumero) {
            maiorNumero = numero3;
        }

        // Mostra o maior número
        System.out.printf("O maior número é: %.2f", maiorNumero);
    }
}
