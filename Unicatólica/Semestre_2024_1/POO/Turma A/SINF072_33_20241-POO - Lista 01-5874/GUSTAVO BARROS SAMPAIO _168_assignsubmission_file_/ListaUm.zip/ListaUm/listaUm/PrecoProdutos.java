package listaUm;

import java.util.Scanner;

public class PrecoProdutos {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o valor do primeiro produto: ");
		double pProduto = Double.parseDouble(entrada.nextLine());
		
		System.out.println("Digite o valor do segundo produto : ");
		double sProduto = Double.parseDouble(entrada.nextLine());
		
		System.out.println("Digite o valor do terceiro produto: ");
		double tProduto = Double.parseDouble(entrada.nextLine());
		
		if (pProduto < sProduto && pProduto < tProduto) {
			System.out.println("Você deve comprar o primeiro produto, no valor de : R$" + pProduto);
		} else if (sProduto < pProduto && sProduto < tProduto) {
			System.out.println("Você deve comprar o segundo produto, no valor de : R$" + sProduto);
		} else {
			System.out.println("Você deve comprar o terceiro produto, no valor de : R$" + tProduto);
		}
		
		entrada.close();
	}

}
