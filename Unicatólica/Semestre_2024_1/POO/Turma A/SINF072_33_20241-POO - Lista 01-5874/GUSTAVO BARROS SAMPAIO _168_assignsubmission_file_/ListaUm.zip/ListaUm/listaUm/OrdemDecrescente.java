package listaUm;

import java.util.Scanner;

public class OrdemDecrescente {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite o primeiro número : ");
		int pNumero = entrada.nextInt();

		System.out.println("Digite o segundo número : ");
		int sNumero = entrada.nextInt();

		System.out.println("Digite o terceiro número : ");
		int tNumero = entrada.nextInt();

		if (pNumero < sNumero && pNumero < tNumero) {
			if (sNumero < tNumero) {
				System.out.println("A ordem decrescente é : " + tNumero + " " + sNumero + " " + pNumero);
			} else if (tNumero < sNumero) {
				System.out.println("A ordem decrescente é : " + sNumero + " " + tNumero + " " + pNumero);
			}
		}
		if (sNumero < pNumero && sNumero < tNumero) {
			if (pNumero < tNumero) {
				System.out.println("A ordem decrescente é : " + tNumero + " " + pNumero + " " + sNumero);
			} else if (tNumero < pNumero) {
				System.out.println("A ordem descrecente é : " + pNumero + " " + tNumero + " " + sNumero);
			}
		}
		if (tNumero < pNumero & tNumero < sNumero) {
			if (pNumero < sNumero) {
				System.out.println("A ordem decrescente é : " + sNumero + " " + pNumero + " " + tNumero);
			} else if (sNumero < pNumero) {
				System.out.println("A ordem decrescente é : " + pNumero + " " + sNumero + " " + tNumero);
			}

		}
	
		entrada.close();
	}
}
