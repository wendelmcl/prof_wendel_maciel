package listaUm;

import java.util.Scanner;

public class MaiorNumero {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite o primeiro número");
		double pNumero = Double.parseDouble(entrada.nextLine());

		System.out.println("Digite o segundo número");
		double sNumero = Double.parseDouble(entrada.nextLine());

		System.out.println("Digite o terceiro número");
		Double tNumero = Double.parseDouble(entrada.nextLine());

		if (pNumero > sNumero && pNumero > tNumero) {
			System.out.println("O maior número é : " + pNumero);

		} else if (sNumero > pNumero && sNumero > tNumero) {
			System.out.println("O maior número é : " + sNumero);

		} else {
			System.out.println("O maior número é : " + tNumero);

		}
		
		entrada.close();
	}

}
