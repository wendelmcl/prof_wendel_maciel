package listaUm;

import java.util.Scanner;

public class TurnoEstudo {
	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite em qual turno você estuda : (M - Matutino / V - Vespertino / N - Noturno");
		String turno = entrada.nextLine().toLowerCase();

		if (turno.equals("m")) {
			System.out.println("Bom dia!");
		} else if (turno.equals("v")) {
			System.out.println("Boa tarde!");
		} else if (turno.equals("n")) {
			System.out.println("Boa noite!");
		} else {
			System.out.println("Valor inválido, digite novamente!");
		}

		entrada.close();
	}

}
