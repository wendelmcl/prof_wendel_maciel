package listaUm;

import java.util.Scanner;

public class Trabalho {
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite quanto você ganha por hora : ");
		double salarioHora = Double.parseDouble(entrada.nextLine());
		System.out.println("Digite quantas horas você trabalho por mês : ");
		double horasTrabalhadas = Double.parseDouble(entrada.nextLine());
		
		double salario = salarioHora * horasTrabalhadas;
		
		System.out.println("Seu salário é de : " + "R$" + salario);
		
		entrada.close();
		
	}

}
