package listaUm;

import java.util.Scanner;

public class AreaCirculo {
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite o raio do circulo");
		double raio = Double.parseDouble(entrada.nextLine());
		
		double area = Math.PI * (raio * raio);
		System.out.println("A area do circulo equivale a : " + area);
		
		entrada.close();
	}

}
