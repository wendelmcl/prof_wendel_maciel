package listaUm;

import java.util.Scanner;

public class AreaDobro {
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite qual o valor do lado do quadrado: ");
		double lado = Double.parseDouble(entrada.nextLine());
		
		double area = lado * lado;
		
		System.out.println("O valor da area do quadrado é : " + area);
		double dobro = area * 2;
		
		System.out.println("O dobro da área desse quadrado é : " + dobro);
		
		entrada.close();
		
	}

}
