package listaUm;

import java.util.Scanner;

public class ConversãoTemperatura {
	public static void main(String[] args) {

		// (32 °F − 32) × 5/9 = °C

		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite a temperatura em Fahrenheit : ");
		double temperaturaF = Double.parseDouble(entrada.nextLine());

		double celsius = 5 * ((temperaturaF - 32) / 9);

		System.out.println("A temperatura em Celsius é : " + celsius);

		entrada.close();
	}

}
