package fahrenheit;

import java.util.Scanner;

public class Execução {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Fahrenheit far = new Fahrenheit();
		
		System.out.println("Digite o valor em Fahrenheit: ");
		far.setF(sc.nextDouble());
		double calculo = 5 * (far.getF() - 32) / 9;
		System.out.printf("O valor em Celsius é: %.2f C", calculo);
	}

}
