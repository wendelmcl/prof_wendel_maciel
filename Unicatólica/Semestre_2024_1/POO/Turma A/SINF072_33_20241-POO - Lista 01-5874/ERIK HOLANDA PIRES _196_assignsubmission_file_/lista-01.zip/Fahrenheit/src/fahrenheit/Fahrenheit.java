package fahrenheit;

public class Fahrenheit {
	
	private double f;
	
	public Fahrenheit() {
		this.f = 0.0;
	}
	
	public double setF(double f){
		this.f = f;
		return f;
	}
	
	public double getF(){
		return f;
	}
	
	
	
}
