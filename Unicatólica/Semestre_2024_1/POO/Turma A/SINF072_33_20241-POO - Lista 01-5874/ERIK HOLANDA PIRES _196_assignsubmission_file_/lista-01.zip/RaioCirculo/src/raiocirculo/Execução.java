package raiocirculo;
import java.util.Scanner;


public class Execução {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Raio raio = new Raio();
		System.out.println("Digite o Raio do Círculo: ");
		raio.setRaio(sc.nextDouble());
		double area = Math.PI * Math.pow(raio.getRaio(), 2);
		System.out.printf("A área do Círculo é: %.2f", area);
	}

}
