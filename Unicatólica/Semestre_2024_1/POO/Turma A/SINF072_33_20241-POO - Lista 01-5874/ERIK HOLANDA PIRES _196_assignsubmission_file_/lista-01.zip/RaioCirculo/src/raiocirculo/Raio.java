package raiocirculo;

public class Raio {
	
	private double raioArea;
	
	public Raio() {
		this.raioArea = 0.0;
	}
	
	public double getRaio() {
		return raioArea;
	}
	
	public double setRaio(double raioArea) {
		this.raioArea = raioArea;
		return raioArea;
	}
	
}
