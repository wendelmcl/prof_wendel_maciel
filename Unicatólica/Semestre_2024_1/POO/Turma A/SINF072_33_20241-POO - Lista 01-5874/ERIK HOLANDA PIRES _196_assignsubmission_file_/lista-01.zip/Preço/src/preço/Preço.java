package preço;

public class Preço {
	
	private double p1, p2, p3;
	
	
	public Preço() {
		this.p1 = 0;
		this.p2 = 0;
		this.p3 = 0;
	}
	
	public double setP1(double p1) {
		this.p1 = p1;
		return p1;
	}
	
	public double getP1() {
		return p1;
	}
	
	public double setP2(double p2) {
		this.p2 = p2;
		return p2;
	}
	
	public double getP2() {
		return p2;
	}
	
	public double setP3(double p3) {
		this.p3 = p3;
		return p3; 
	}
	
	public double getP3() {
		return p3;
	}
	
	public void qualProduto(double p1, double p2, double p3) {
		if(p1 < p2 && p1 < p3) {
			System.out.println("Você deve comprar o primeiro produto: " + p1);
		}else if(p2 < p1 && p2 < p3) {
			System.out.println("Você deve comprar o segundo produto: " + p2);
		}else {
			System.out.println("Você deve comprar o terceiro produto: " + p3);
		}
	}
}
