package preço;

import java.util.Scanner;

public class Execução {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Preço preço = new Preço();
		
		System.out.println("O preço do primeiro produto: ");
		double p1 = preço.setP1(sc.nextDouble());
		
		System.out.println("Qual o preço do segundo produto? ");
		double p2 = preço.setP2(sc.nextDouble());
		
		System.out.println("Qual o preço do terceiro produto? ");
		double p3 = preço.setP3(sc.nextDouble());
		
		preço.qualProduto(p1, p2, p3);
	}

}
