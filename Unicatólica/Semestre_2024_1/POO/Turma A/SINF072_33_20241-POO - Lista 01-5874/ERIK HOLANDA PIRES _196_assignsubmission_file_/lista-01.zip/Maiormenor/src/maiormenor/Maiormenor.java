package maiormenor;

public class Maiormenor{
	
	private int n1, n2, n3;
	
	public Maiormenor() {
		this.n1 = 0;
		this.n2 = 0;
		this.n3 = 0;
	}
	
	public int setN1(int n1){
		this.n1 = n1;
		return n1;
	}
	
	public int getN1(){
		return n1;
	}
	
	public int setN2(int n2){
		this.n2 = n2;
		return n2;
	}
	
	public int getN2(){
		return n2;
	}
	
	public int setN3(int n3){
		this.n3 = n3;
		return n3;
	}
	
	public int getN3(){
		return n3;
	}
	
	public void calculo(int n1, int n2, int n3) {
		if(n1 > n2  && n1 > n3) {
			System.out.println("O número Maior é: " + n1);
		}else if(n2 > n1 && n2 > n3) {
			System.out.println("O número Maior é: " + n2);
		}else {
			System.out.println("O número Maior é: " + n3);
		}
		
		if(n1 < n2 && n1 < n3) {
			System.out.println("O número menor é: " + n1);
		}else if(n2 < n1 && n2 < n3) {
			System.out.println("O número menor é: " + n2);
		}else {
			System.out.println("O número menor é: " + n3);
		}
		
	}
}