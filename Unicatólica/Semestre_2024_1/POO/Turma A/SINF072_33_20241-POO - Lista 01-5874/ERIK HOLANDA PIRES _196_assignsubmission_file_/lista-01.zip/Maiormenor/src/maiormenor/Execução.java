package maiormenor;

import java.util.Scanner;

public class Execução {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Maiormenor mm = new Maiormenor();
		
		System.out.println("Digite o primeiro número:");
		mm.setN1(sc.nextInt());
		
		System.out.println("Digite o segundo número: ");
		mm.setN2(sc.nextInt());
		
		System.out.println("Digite o terceiro número: ");
		mm.setN3(sc.nextInt());
		
		mm.calculo(mm.getN1(), mm.getN2(), mm.getN3());
	}
}
