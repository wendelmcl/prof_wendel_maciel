package descrescente;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Scanner;

public class Execuçao{
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int[] box = new int[3];
		
		for(int i = 0; i < 3; i++) {
			System.out.println("Digite os números: ");
			box[i] = sc.nextInt();
		}
		
		Arrays.sort(box);
        for (int i = 0; i < 3 / 2; i++) {
            int temp = box[i];
            box[i] = box[3 - 1 - i];
            box[3 - 1 - i] = temp;
        }
		
		for(int i = 0; i < 3; i++) {
			System.out.println(box[i] + "");
		}
	}
	
}
