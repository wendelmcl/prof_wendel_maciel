package dobroarea;

public class AreaD {
	private double b;
	private double h;
	
	public AreaD() {
		this.b = 0.0;
		this.h = 0.0;
	}
	
	public double getH() {
		return h;
	}
	
	public double setH(double h) {
		this.h = h;
		return h;
	}
	
	public double getB() {
		return b;
	}
	
	public double setB(double b) {
		this.b = b;
		return b;
	}
	
	
}
