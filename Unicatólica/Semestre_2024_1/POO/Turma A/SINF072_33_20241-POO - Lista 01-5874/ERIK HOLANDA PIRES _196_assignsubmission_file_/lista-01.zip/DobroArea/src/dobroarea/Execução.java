package dobroarea;
import java.util.Scanner;

public class Execução {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		AreaD aread = new AreaD();
		
		System.out.println("Qual a largura do quadrado? ");
		aread.setB(sc.nextDouble());
		System.out.println("Qual a altura do quadrado?");
		aread.setH(sc.nextDouble());
		double calculo = (aread.getB() * aread.getH());
		double calculoDobro = (aread.getB() * aread.getH()) * 2;
		System.out.printf("O dobro da área de %.2f m2 é: %.2f m2", calculo, calculoDobro);
		
	}

}
