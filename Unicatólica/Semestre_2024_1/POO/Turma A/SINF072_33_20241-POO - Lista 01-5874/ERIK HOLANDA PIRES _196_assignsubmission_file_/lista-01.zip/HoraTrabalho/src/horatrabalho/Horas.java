package horatrabalho;

public class Horas {
	private double horasTrabalho;
	private double salarioHora;
	
	public Horas() {
		this.horasTrabalho = 0.0;
		this.salarioHora = 0.0;
	}
	
	
	public double setHoraTrabalho (double horasTrabalho) {
		this.horasTrabalho = horasTrabalho;
		return horasTrabalho;
	}
	
	public double getHorasT(){
		return horasTrabalho;
	}
	
	public double getSalarioH() {
		return salarioHora;
	}
	
	public double setSalarioH(double salarioHora) {
		this.salarioHora = salarioHora;
		return salarioHora;
	}
}
