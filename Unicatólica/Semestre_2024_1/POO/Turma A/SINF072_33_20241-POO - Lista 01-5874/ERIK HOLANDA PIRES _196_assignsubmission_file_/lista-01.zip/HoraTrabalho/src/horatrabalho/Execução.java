package horatrabalho;
import java.util.Scanner;

public class Execução {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Horas horas = new Horas();
		
		System.out.println("Digite a quantidade de horas trabalhadas no mês: ");
		
		double hora = horas.setHoraTrabalho(sc.nextDouble());
		
		System.out.println("Digite o Salário por Hora: ");
		
		double salario = horas.setSalarioH(sc.nextDouble());
		double calculo = horas.getHorasT() * horas.getSalarioH();
		
		System.out.printf("O seu salário de acordo com as horas trabalhadas é: R$ %.2f ", calculo);
	}
}
