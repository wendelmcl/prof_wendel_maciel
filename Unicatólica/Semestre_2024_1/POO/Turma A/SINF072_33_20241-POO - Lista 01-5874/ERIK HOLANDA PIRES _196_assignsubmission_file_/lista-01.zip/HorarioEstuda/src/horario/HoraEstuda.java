package horario;

public class HoraEstuda {
	
	private char hora;
	
	public char getHora() {
		return hora;
	}

	public void setHora(char hora) {
		this.hora = hora;
	}

	public void qHora() {
		if(getHora() == 'M' || getHora() == 'm') {
			System.out.println("Bom dia!");
		}else if(getHora() == 'V' || getHora() == 'v'){
			System.out.println("Boa tarde!");
		}else if(getHora() == 'N' || getHora() == 'n'){
			System.out.println("Boa noite!");
		}else {
			System.out.println("Valor Inválido");
		}
	}
}
