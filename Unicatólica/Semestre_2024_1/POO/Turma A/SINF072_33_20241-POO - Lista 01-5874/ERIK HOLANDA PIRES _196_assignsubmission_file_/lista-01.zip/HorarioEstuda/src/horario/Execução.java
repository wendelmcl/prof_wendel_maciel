package horario;
import java.util.Scanner;
public class Execução {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HoraEstuda he = new HoraEstuda();
		
		System.out.println("Qual horário você estuda? \n (M) - Matutino \n (V) - Vespertino \n (N) - Noturno");
		he.setHora(sc.next().charAt(0));
		he.qHora();
	}
	
}
