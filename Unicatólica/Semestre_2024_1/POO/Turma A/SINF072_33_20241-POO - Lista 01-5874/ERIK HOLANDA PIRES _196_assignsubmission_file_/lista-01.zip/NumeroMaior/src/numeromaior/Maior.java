package numeromaior;

public class Maior {
	
	private int n1;
	private int n2;
	private int n3;
	
	public Maior() {
		this.n1 = 0;
		this.n2 = 0;
		this.n3 = 0;
	}
	
	public int setN1(int n1) {
		this.n1 = n1;	
		return n1;
	}
	
	public int getN1() {
		return n1;
	}
	
	public int setN2(int n2) {
		this.n2 = n2;
		return n2;
	}
	
	public int getN2() {
		return n2;
	}
	
	public int setN3(int n3) {
		this.n3 = n3;
		return n3;
	}
	
	public int getN3() {
		return n3;
	}
	
	public void calculo(int n1, int n2, int n3) {
		if(n1 > n2 && n1 > n3) {
			System.out.println("Número Maior: " + n1);
		}else if (n2 > n1 && n2 > n3) {
			System.out.println("Número Maior: " + n2);
		}else {
			System.out.println("Número Maior: " + n3);
		}
	}
}
