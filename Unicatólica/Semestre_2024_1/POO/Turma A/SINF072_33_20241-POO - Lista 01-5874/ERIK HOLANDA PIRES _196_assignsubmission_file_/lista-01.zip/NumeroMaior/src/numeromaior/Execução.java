package numeromaior;

import java.util.Scanner;

public class Execução {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Maior maior = new Maior();
		
		System.out.println("Digite o primeiro número: ");
		int n1 = maior.setN1(sc.nextInt());
		
		System.out.println("Digite o segundo número: ");
		int n2 = maior.setN2(sc.nextInt());
		
		System.out.println("Digite o terceiro número: ");
		int n3 = maior.setN3(sc.nextInt());
		
		maior.calculo(n1, n2, n3);
		
	}
}
