package celsius;

import java.util.Scanner;

public class Execução {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);	
		Celsius c = new Celsius();
		
		System.out.println("Digite o valor em Celsius: ");
		c.setF(sc.nextDouble());
		double calculo = (c.getF() * 1.8) + 32;
		System.out.printf("O valor em Fahrenheit: %.2f F.", calculo);
	}

}
