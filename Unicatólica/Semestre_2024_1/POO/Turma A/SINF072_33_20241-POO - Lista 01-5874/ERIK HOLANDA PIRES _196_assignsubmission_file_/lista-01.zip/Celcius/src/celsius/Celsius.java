package celsius;

public class Celsius {
	
	private double c;
	
	public Celsius() {
		this.c = 0.0;
	}
	
	public double setF(double c) {
		this.c = c;
		return c;
	}
	
	public double getF() {
		return c;
	}
}
