package listaTres;

import java.util.Scanner;

public class QuantidadeDigitos {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite um número: ");

		int n = entrada.nextInt();

		String n2 = Integer.toString(n);

		int tamanho = n2.length();

		System.out.println("O tanto de digitos que possui nesse número é: " + tamanho);

		entrada.close();
	}

}
