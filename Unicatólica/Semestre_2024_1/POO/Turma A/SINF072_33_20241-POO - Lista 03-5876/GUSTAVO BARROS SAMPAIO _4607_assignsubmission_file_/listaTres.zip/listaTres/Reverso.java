package listaTres;

import java.util.Scanner;

public class Reverso {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite um numero inteiro:");
		int number = entrada.nextInt();
		
		String numberStr = Integer.toString(number);
		for (int i = numberStr.length() - 1; i >= 0; i--) {
			System.out.print(numberStr.charAt(i));
		}
		entrada.close();
	}

}
