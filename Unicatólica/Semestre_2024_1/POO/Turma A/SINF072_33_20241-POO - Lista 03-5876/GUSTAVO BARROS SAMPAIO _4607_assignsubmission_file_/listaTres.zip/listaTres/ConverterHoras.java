package listaTres;

import java.util.Scanner;

public class ConverterHoras {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		char resposta;

		do {
			System.out.println("Digite as horas no formato de 24 horas (hh:mm):");
			String entrada = scanner.nextLine();

			String[] partes = entrada.split(":");
			int horas = Integer.parseInt(partes[0]);
			int minutos = Integer.parseInt(partes[1]);

			String resultado = converter(horas, minutos);

			System.out.println("Horário convertido: " + resultado);

			System.out.println("Deseja fazer outra conversão? (S/N)");
			resposta = scanner.nextLine().charAt(0);
		} while (Character.toUpperCase(resposta) == 'S');

		System.out.println("Programa encerrado.");
		scanner.close();
	}

	public static String converter(int horas, int minutos) {
		String periodo;

		if (horas >= 12) {
			periodo = "P.M.";
			if (horas > 12) {
				horas -= 12;
			}
		} else {
			periodo = "A.M.";
			if (horas == 0) {
				horas = 12;
			}
		}

		return String.format("%d:%02d %s", horas, minutos, periodo);
	}

}
