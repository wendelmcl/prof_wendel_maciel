package listaTres;

import java.util.Random;

public class Jogo {

	public static void main(String[] args) {

		Random rd = new Random();
		int jogada1 = rd.nextInt(11) + 2;

		System.out.println("Caiu no número " + jogada1);

		if (jogada1 == 7 || jogada1 == 11) {
			System.out.println("Você ganhou");
		} else if (jogada1 == 2 || jogada1 == 3 || jogada1 == 12) {
			System.out.println("Você perdeu");
		} else {
			int jogada;
			do {
				jogada = rd.nextInt(11) + 2;
				System.out.println("Nova rodada");
				System.out.println("Caiu no número " + jogada);
			} while (jogada != 7 && jogada != jogada1);

			if (jogada == jogada1) {
				System.out.println("Você ganhou");
			} else {
				System.out.println("Você perdeu");
			}
		}

		System.out.println("Fim de jogo");

	}
}
