package listaTres;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Pagamento {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite o valor total a ser pago:");
		double total = entrada.nextDouble();
		List<Double> relatorio = new ArrayList<>();

		while (total > 0) {
			System.out.print("Digite o valor da prestação: ");
			double valorPrestacao = entrada.nextDouble();
			System.out.print("Digite o total de dias em atraso: ");
			int diasDeAtraso = entrada.nextInt();

			double valorPago = valorPagamento(diasDeAtraso, valorPrestacao);
			System.out.println("Valor a ser pago: " + String.format("%.2f", valorPago));

			total -= valorPrestacao;
			System.out.println("Total restante: " + String.format("%.2f", total));
			relatorio.add(valorPago);
		}

		double totalPago = relatorio.stream().mapToDouble(Double::doubleValue).sum();
		relatorio.forEach(valor -> System.out.println("Prestação: " + String.format("%.2f", valor)));
		System.out.println("TOTAL PAGO NO DIA: " + String.format("%.2f", totalPago));
		entrada.close();
	}

	public static double valorPagamento(int diasAtraso, double valorPrestacao) {
		if (diasAtraso > 0) {
			return valorPrestacao + (valorPrestacao * 0.03) + ((valorPrestacao * 0.001) * diasAtraso);
		} else {
			return valorPrestacao;
		}
	}
}
