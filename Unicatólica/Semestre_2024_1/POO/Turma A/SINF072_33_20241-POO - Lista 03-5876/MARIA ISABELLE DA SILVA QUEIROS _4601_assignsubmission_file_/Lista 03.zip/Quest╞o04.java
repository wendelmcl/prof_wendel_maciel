package pessoas;
public class Main {
    
    public static void main(String[] args) {
        int numero = 127;
        int numeroInvertido = inverterNumero(numero);
        System.out.println("O número " + numero + " invertido é: " + numeroInvertido);
    }
    
    public static int inverterNumero(int numero) {
        int numeroInvertido = 0;
        
        // Enquanto o número não for zero, remova o último dígito e adicione-o ao número invertido
        while (numero != 0) {
            int digito = numero % 10; // Obtém o último dígito
            numeroInvertido = numeroInvertido * 10 + digito; // Adiciona o dígito ao número invertido
            numero /= 10; // Remove o último dígito do número original
        }
        
        return numeroInvertido;
    }
}
