package pessoas;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.print("Digite a hora (formato de 24 horas): ");
            int hora = scanner.nextInt();
            System.out.print("Digite os minutos: ");
            int minutos = scanner.nextInt();
            
            if (hora < 0 || hora > 23 || minutos < 0 || minutos > 59) {
                System.out.println("Por favor, digite um horário válido.");
                continue;
            }
            
            String[] resultado = converterPara12Horas(hora, minutos);
            System.out.println("A hora convertida é: " + resultado[0] + ":" + resultado[1] + " " + resultado[2]);
            
            System.out.print("Deseja converter outro horário? (s/n): ");
            String repetir = scanner.next();
            if (!repetir.equalsIgnoreCase("s")) {
                break;
            }
        }
        
        scanner.close();
    }

    private static String[] converterPara12Horas(int hora, int minutos) {
        String periodo;
        int hora12;
        
        if (hora == 0) {
            hora12 = 12;
            periodo = "A";
        } else if (hora < 12) {
            hora12 = hora;
            periodo = "A";
        } else if (hora == 12) {
            hora12 = 12;
            periodo = "P";
        } else {
            hora12 = hora - 12;
            periodo = "P";
        }
        
        String[] resultado = new String[3];
        resultado[0] = Integer.toString(hora12);
        resultado[1] = Integer.toString(minutos);
        resultado[2] = periodo;
        
        return resultado;
    }
}
