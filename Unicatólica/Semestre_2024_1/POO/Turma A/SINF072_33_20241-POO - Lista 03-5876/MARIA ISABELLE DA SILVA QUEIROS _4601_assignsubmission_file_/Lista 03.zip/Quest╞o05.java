package pessoas;
import java.util.Random;

public class Main {
    
    public static void main(String[] args) {
        jogarCraps();
    }
    
    public static void jogarCraps() {
        Random random = new Random();
        
        int primeiroJogada = lancarDados(random);
        
        if (primeiroJogada == 7 || primeiroJogada == 11) {
            System.out.println("Você tirou " + primeiroJogada + " na primeira jogada. Você ganhou!");
        } else if (primeiroJogada == 2 || primeiroJogada == 3 || primeiroJogada == 12) {
            System.out.println("Você tirou " + primeiroJogada + " na primeira jogada. Você perdeu!");
        } else {
            System.out.println("Seu ponto é " + primeiroJogada + ".");
            continuarJogar(random, primeiroJogada);
        }
    }
    
    public static void continuarJogar(Random random, int ponto) {
        while (true) {
            int resultado = lancarDados(random);
            if (resultado == ponto) {
                System.out.println("Você tirou " + resultado + ". Você ganhou!");
                break;
            } else if (resultado == 7) {
                System.out.println("Você tirou 7. Você perdeu!");
                break;
            }
        }
    }
    
    public static int lancarDados(Random random) {
        int dado1 = random.nextInt(6) + 1;
        int dado2 = random.nextInt(6) + 1;
        int resultado = dado1 + dado2;
        System.out.println("Você tirou " + dado1 + " e " + dado2 + " (total: " + resultado + ")");
        return resultado;
    }
}
