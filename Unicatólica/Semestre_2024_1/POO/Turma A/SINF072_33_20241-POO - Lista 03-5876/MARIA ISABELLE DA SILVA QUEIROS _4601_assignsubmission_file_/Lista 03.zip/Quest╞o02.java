package pessoas;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalPrestacoes = 0;
        double totalValorPago = 0;
        
        while (true) {
            System.out.print("Digite o valor da prestação (ou 0 para encerrar): ");
            double valorPrestacao = scanner.nextDouble();
            
            if (valorPrestacao == 0) {
                break;
            }
            
            System.out.print("Digite o número de dias em atraso: ");
            int diasAtraso = scanner.nextInt();
            
            double valorPago = valorPagamento(valorPrestacao, diasAtraso);
            totalPrestacoes++;
            totalValorPago += valorPago;
            
            System.out.println("Valor a ser pago: " + valorPago);
        }
        
        System.out.println("\nRelatório do dia:");
        System.out.println("Total de prestações pagas: " + totalPrestacoes);
        System.out.println("Valor total pago: " + totalValorPago);
        
        scanner.close();
    }
    
    public static double valorPagamento(double valorPrestacao, int diasAtraso) {
        double valorPago;
        
        if (diasAtraso == 0) {
            valorPago = valorPrestacao;
        } else {
            double multa = valorPrestacao * 0.03;
            double juros = valorPrestacao * 0.001 * diasAtraso;
            valorPago = valorPrestacao + multa + juros;
        }
        
        return valorPago;
    }
}
