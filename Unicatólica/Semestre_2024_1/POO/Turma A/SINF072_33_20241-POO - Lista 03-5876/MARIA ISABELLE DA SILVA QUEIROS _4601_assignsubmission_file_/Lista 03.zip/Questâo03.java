package pessoas;
public class Main {
    
    public static void main(String[] args) {
        int numero = 12345;
        int quantidadeDigitos = contarDigitos(numero);
        System.out.println("O número " + numero + " possui " + quantidadeDigitos + " dígitos.");
    }
    
    public static int contarDigitos(int numero) {
        // Se o número for zero, retorna 1, pois zero possui um dígito
        if (numero == 0) {
            return 1;
        }
        
        int quantidade = 0;
        
        // Loop enquanto o número for diferente de zero
        while (numero != 0) {
            quantidade++; // Incrementa a quantidade de dígitos
            numero /= 10; // Remove o último dígito dividindo o número por 10
        }
        
        return quantidade;
    }
}
