package atv2;

import java.util.Scanner;

public class PagamentoConta {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        double totalPrestacoes = 0;
        int quantidadePrestacoes = 0;
        
        double prestacao;
        do {
            System.out.print("Digite o valor da prestação (ou 0 para sair): ");
            prestacao = scanner.nextDouble();
            
            if (prestacao != 0) {
                System.out.print("Digite o número de dias em atraso: ");
                int diasAtraso = scanner.nextInt();
                
                double valorPago = valorPagamento(prestacao, diasAtraso);
                System.out.println("Valor a ser pago: " + valorPago);
                
                totalPrestacoes += valorPago;
                quantidadePrestacoes++;
            }
        } while (prestacao != 0);
        
        System.out.println("Relatório do dia:");
        System.out.println("Quantidade de prestações pagas: " + quantidadePrestacoes);
        System.out.println("Valor total de prestações pagas: " + totalPrestacoes);
        
        scanner.close();
    }
    
    public static double valorPagamento(double prestacao, int diasAtraso) {
        if (diasAtraso == 0) {
            return prestacao;
        } else {
            double multa = prestacao * 0.03;
            double juros = prestacao * (0.001 * diasAtraso);
            return prestacao + multa + juros;
        }
    }
}

