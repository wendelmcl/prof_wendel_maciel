package atv4;

public class ReversoNumero {
    public static void main(String[] args) {
        int numero = 345;
        int reverso = obterReverso(numero);
        System.out.println("O reverso de " + numero + " é: " + reverso);
    }
    
    public static int obterReverso(int numero) {
        int reverso = 0;
        while (numero != 0) {
            int digito = numero % 10;
            reverso = reverso * 10 + digito;
            numero /= 10;
        }
        return reverso;
    }
}

