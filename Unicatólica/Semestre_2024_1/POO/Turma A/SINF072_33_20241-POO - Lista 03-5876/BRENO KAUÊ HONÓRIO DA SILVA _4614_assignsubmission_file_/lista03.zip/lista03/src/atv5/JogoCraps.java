package atv5;

import java.util.Scanner;

public class JogoCraps {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bem-vindo ao jogo de Craps!");

        while (true) {
            System.out.println("Pressione Enter para lançar os dados...");
            scanner.nextLine();
            int firstRoll = rollDice();
            System.out.println("Você lançou: " + firstRoll);

            if (firstRoll == 7 || firstRoll == 11) {
                System.out.println("Natural! Você ganhou!");
                break;
            } else if (firstRoll == 2 || firstRoll == 3 || firstRoll == 12) {
                System.out.println("Craps! Você perdeu!");
                break;
            } else {
                int point = firstRoll;
                System.out.println("Ponto estabelecido: " + point);
                while (true) {
                    System.out.println("Pressione Enter para lançar os dados novamente...");
                    scanner.nextLine();
                    int roll = rollDice();
                    System.out.println("Você lançou: " + roll);

                    if (roll == point) {
                        System.out.println("Você fez o Ponto! Você ganhou!");
                        return;
                    } else if (roll == 7) {
                        System.out.println("Você lançou um 7. Você perdeu!");
                        return;
                    } else {
                        System.out.println("Continue tentando...");
                    }
                }
            }
        }

        scanner.close();
    }

    public static int rollDice() {
        return (int) (Math.random() * 6 + 1) + (int) (Math.random() * 6 + 1);
    }
}

