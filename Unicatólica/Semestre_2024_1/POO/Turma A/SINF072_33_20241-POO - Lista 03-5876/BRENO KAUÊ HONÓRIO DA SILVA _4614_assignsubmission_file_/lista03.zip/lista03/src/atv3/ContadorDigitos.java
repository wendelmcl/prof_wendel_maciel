package atv3;

public class ContadorDigitos {
    public static void main(String[] args) {
        int numero = 12345;
        int quantidadeDigitos = contarDigitos(numero);
        System.out.println("O número " + numero + " possui " + quantidadeDigitos + " dígitos.");
    }
    
    public static int contarDigitos(int numero) {
        int contador = 0;
        while (numero != 0) {
            numero /= 10;
            contador++;
        }
        return contador;
    }
}

