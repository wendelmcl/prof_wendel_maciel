package atv1;

import java.util.Scanner;

public class ConversorHora {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        char continuar;
        do {
            System.out.print("Digite a hora (formato 24 horas): ");
            int hora = scanner.nextInt();
            System.out.print("Digite os minutos: ");
            int minutos = scanner.nextInt();
            
            String horaConvertida = converterPara12Horas(hora, minutos);
            System.out.println("Hora convertida: " + horaConvertida);
            
            System.out.print("Deseja converter outra hora? (S/N): ");
            continuar = scanner.next().charAt(0);
        } while (continuar == 'S' || continuar == 's');
        
        scanner.close();
    }
    
    public static String converterPara12Horas(int hora, int minutos) {
        String periodo;
        if (hora >= 12) {
            periodo = "P.M.";
            if (hora > 12) {
                hora -= 12;
            }
        } else {
            periodo = "A.M.";
            if (hora == 0) {
                hora = 12;
            }
        }
        
        return hora + ":" + minutos + " " + periodo;
    }
}

