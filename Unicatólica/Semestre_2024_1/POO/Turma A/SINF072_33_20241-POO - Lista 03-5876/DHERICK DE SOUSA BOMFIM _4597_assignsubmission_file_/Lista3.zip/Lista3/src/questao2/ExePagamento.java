package questao2;

import java.util.Scanner;

public class ExePagamento {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		int TotParcelasPagas = 0;
		double ValorTotPago = 0;
		
		while (true) {
			System.out.print("Digite o valor da prestação (ou 0 para sair) : ");
			double valorPrest = sc.nextDouble();
			
			if (valorPrest == 0) {
				break;
			}
			System.out.println("Digite o número de dias em atraso : ");
			int dAtrasos = sc.nextInt();
			
			double valorAPagar = Prestacao.calcularValorPagamento(valorPrest, dAtrasos);
			
			System.out.printf("Valor a ser pago : R$%.2f\n", valorAPagar);
			TotParcelasPagas++;
			ValorTotPago += valorAPagar;
		}
		System.out.println("\nRelatório do Dia:");
        System.out.println("Total de prestações pagas: " + TotParcelasPagas);
        System.out.printf("Valor total pago: R$%.2f\n", ValorTotPago);
		
        sc.close();
       
		

	}

}
