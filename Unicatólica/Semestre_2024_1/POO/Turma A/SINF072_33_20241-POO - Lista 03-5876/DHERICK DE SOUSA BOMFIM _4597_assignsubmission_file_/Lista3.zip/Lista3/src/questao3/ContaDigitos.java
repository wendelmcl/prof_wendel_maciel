package questao3;

public class ContaDigitos {
	private int numero;
	
	public ContaDigitos(int numero) {
		this.numero = numero;
	}
	
	public int contaDig() {
		return String.valueOf(numero).length();
	}
}
