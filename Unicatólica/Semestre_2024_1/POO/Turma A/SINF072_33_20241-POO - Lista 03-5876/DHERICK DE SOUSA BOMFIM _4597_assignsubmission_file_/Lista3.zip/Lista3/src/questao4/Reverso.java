package questao4;

import java.util.Scanner;

public class Reverso {
	private Scanner sc = new Scanner(System.in);
	public void obterNumero() {
		System.out.print("Dígite o numero que deseja inverter : ");	
		int numero = sc.nextInt();
		
		inverso(numero);
	}
	
	private void inverso(int numero) {
		int invertido = 0;
		
		while (numero > 0) {
			invertido *= 10;
			invertido += (numero % 10);
			numero /= 10;
		}
	
		System.out.printf("O número invertido é: %d.\n", invertido);
	}
	
}
