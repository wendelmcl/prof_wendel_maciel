package questao2;

public class Prestacao {
	public static double calcularValorPagamento(double valorPrest, int dAtrasos) {
		if (dAtrasos == 0) {
			return valorPrest;
		}
		double multa = valorPrest * 0.03;
		double juros = valorPrest * dAtrasos * 0.001;
		return valorPrest + multa + juros;
	}
}
