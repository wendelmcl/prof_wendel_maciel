package questao5;

import java.util.Random;	
import java.util.Scanner;

public class JogoCraps {
	private Random random;
    private Scanner sc;
    
    public JogoCraps() {
    	random = new Random();
	    sc = new Scanner(System.in);
    }

    public void jogar() {
        int ponto = 0;

        int somaDados = lancarDados();

        if (somaDados == 7 || somaDados == 11) {
            System.out.println("Você tirou " + somaDados + " na primeira jogada. Você ganhou!");
            return;
        } else if (somaDados == 2 || somaDados == 3 || somaDados == 12) {
            System.out.println("Você tirou " + somaDados + " na primeira jogada. Você perdeu!");
            return;
        } else {
            ponto = somaDados;
            System.out.println("Seu ponto é " + ponto);
        }

        while (true) {
            somaDados = lancarDados();

            if (somaDados == ponto) {
                System.out.println("Você tirou seu ponto novamente. Você ganhou!");
                break;
            } else if (somaDados == 7) {
                System.out.println("Você tirou 7. Você perdeu!");
                break;
            }
        }
        sc.close();
    }

    private int lancarDados() {
        int dado1 = random.nextInt(6) + 1;
        int dado2 = random.nextInt(6) + 1;
        int soma = dado1 + dado2;
        System.out.println("Você lançou " + dado1 + " e " + dado2 + " - totalizando " + soma);
        return soma;
    }

    public static void main(String[] args) {
        JogoCraps jogo = new JogoCraps();
        jogo.jogar();	    
    }
}