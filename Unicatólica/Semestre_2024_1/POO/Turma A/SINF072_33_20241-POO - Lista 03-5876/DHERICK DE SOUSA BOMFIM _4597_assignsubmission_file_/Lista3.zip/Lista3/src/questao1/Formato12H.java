package questao1;

import java.util.Scanner;

public class Formato12H {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		while (true) {
			try {
				System.out.print("Digite a hora no formato de 24 Horas (HHmm)");
				int horas24 = sc.nextInt();
				
				if (horas24 < 0 || horas24 > 2359 ) {
					throw new IllegalArgumentException("Formato de hora inválido");
				}
				String meridiano = obterMeridiano(horas24);
				int horas12 = obterHoras12(horas24);
				int min = horas24 % 100;
				
				System.out.printf("Hora convertida : %02d:%02d  %s \n", horas12, min, meridiano);
				
				System.out.print("Deseja fazer outra conversão? (S/N) : ");
				String escolha = sc.next().toUpperCase();
				if (!escolha.equals("S")) {
					break;
				}
			}catch (IllegalArgumentException e) {
				System.err.println(e.getMessage());
			}
			sc.close();		}
		}
	private static String obterMeridiano(int horas24) {
		return (horas24 < 1200) ? "AM" : "PM";
	}
	
	private static int obterHoras12(int horas24) {
		return (horas24 % 1200) == 0 ? 12 : (horas24 % 1200) / 100;
	}
}
