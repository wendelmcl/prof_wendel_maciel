package questao4;


public class ExeReverso {

	public static void main(String[] args) {
		Reverso objeto = new Reverso();
		
		objeto.obterNumero();

	}

}
