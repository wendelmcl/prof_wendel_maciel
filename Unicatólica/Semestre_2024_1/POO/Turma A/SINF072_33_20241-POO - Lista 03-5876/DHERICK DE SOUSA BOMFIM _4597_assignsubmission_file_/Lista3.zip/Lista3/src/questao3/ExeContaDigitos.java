package questao3;

import java.util.Scanner;

public class ExeContaDigitos {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Digite um número : ");
		int numero = sc.nextInt();
		
		ContaDigitos contador = new ContaDigitos(numero);
		int QuantidadeDig = contador.contaDig();
		System.out.println("O número " + numero + " possui " + QuantidadeDig + " dígitos.");
		sc.close(); 
	}

}
