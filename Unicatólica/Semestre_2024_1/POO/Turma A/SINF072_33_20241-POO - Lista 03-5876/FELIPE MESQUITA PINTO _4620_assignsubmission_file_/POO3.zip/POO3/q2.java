import java.util.Scanner;
public class q2 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double valorTotalPagamentos = 0;
        int quantidadePagamentos = 0;

        while (true) {
            System.out.print("Digite o valor da prestação (ou 0 para sair): ");
            double valorPrestacao = scanner.nextDouble();

            if (valorPrestacao == 0) {
                break;
            }

            System.out.print("Digite o número de dias em atraso: ");
            int diasAtraso = scanner.nextInt();

            double valorPagamento = calcularValorPagamento(valorPrestacao, diasAtraso);
            valorTotalPagamentos += valorPagamento;
            quantidadePagamentos++;

            System.out.printf("Valor a ser pago: R$ %.2f\n", valorPagamento);
        }

        System.out.println("\nRelatório do Dia:");
        System.out.println("Quantidade de pagamentos: " + quantidadePagamentos);
        System.out.printf("Valor total de pagamentos: R$ %.2f\n", valorTotalPagamentos);
    }

    private static double calcularValorPagamento(double valorPrestacao, int diasAtraso) {
        double valorMulta = valorPrestacao * 0.03;
        double valorJuros = valorPrestacao * diasAtraso * 0.001;
        return valorPrestacao + valorMulta + valorJuros;
    }
}
