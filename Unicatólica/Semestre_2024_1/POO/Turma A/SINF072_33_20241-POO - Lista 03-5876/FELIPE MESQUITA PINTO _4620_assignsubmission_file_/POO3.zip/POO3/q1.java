import java.util.Scanner;

public class q1 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        boolean continuar = true;
        while (continuar) {
            System.out.print("Digite a hora em formato 24h (hh:mm): ");
            int hora24 = scanner.nextInt();
            int minuto24 = scanner.nextInt();

            String hora12 = converterPara12Horas(hora24, minuto24);
            String meridiano = definirMeridiano(hora24);

            System.out.println(hora12 + " " + meridiano);

            System.out.print("Deseja converter outra hora? (S/N): ");
            String resposta = scanner.next().toUpperCase();
            if (!resposta.equals("S")) {
                continuar = false;
            }
        }

        System.out.println("Programa finalizado.");
    }

    private static String converterPara12Horas(int hora24, int minuto24) {
        int hora12 = hora24 % 12;
        if (hora12 == 0) {
            hora12 = 12;
        }
        return String.format("%02d:%02d", hora12, minuto24);
    }

    private static String definirMeridiano(int hora24) {
        if (hora24 < 12) {
            return "A.M.";
        } else {
            return "P.M.";
        }
    }