import java.util.Scanner;

public class q4 {
    public static int reverterNumero(int numero) {
        int reverso = 0;
        while (numero > 0) {
          int digito = numero % 10;
          reverso = reverso * 10 + digito;
          numero /= 10;
        }
        return reverso;
      }
    
      public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite um número: ");
        int numero = scanner.nextInt();
        int numeroRevertido = reverterNumero(numero);
        System.out.println("O reverso de " + numero + " é " + numeroRevertido + ".");
      }
}
