import java.util.Scanner;

public class ValorPrestacao {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double prestação, multa, juros, valorPago;
        int diasAtraso;
        do {
            System.out.print("Informe o valor da prestação: R$ ");
            prestação = scanner.nextDouble();
            System.out.print("Informe o número de dias em atraso: ");
            diasAtraso = scanner.nextInt();
            valorPago = valorPagamento(prestação, diasAtraso);
            System.out.printf("O valor a ser pago é: R$ %.2f%n", valorPago);
        } while (prestação != 0);
    }

    public static double valorPagamento(double prestação, int diasAtraso) {
        double multa, juros, valorPago;
        if (diasAtraso > 0) {
            multa = prestação * 0.03;
            juros = prestação * 0.001 * diasAtraso;
            valorPago = prestação + multa + juros;
        } else {
            valorPago = prestação;
        }
        totalPrestacoes++;
        totalValorPrestacoes += valorPago;
        return valorPago;
    }
}