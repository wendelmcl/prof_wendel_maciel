import java.util.Scanner;

public class ConversorDeHoras {

    public static String converterHoras(int horas, int minutos, char periodo) {
        if (horas >= 1 && horas <= 11) {
            periodo = 'A';
        } else if (horas == 12) {
            periodo = 'P';
        } else if (horas > 12) {
            horas -= 12;
            periodo = 'P';
        }
        return horas + ":" + minutos + " " + periodo;
    }

    public static void exibirConversao() {
        Scanner scanner = new Scanner(System.in);
        int horas, minutos;
        char periodo;
        String continuar;

        do {
            System.out.print("Informe as horas (0-23) e minutos (0-59): ");
            horas = scanner.nextInt();
            minutos = scanner.nextInt();
            System.out.print("Informe o período (A/P): ");
            periodo = scanner.next().charAt(0);

            System.out.println("A hora convertida é: " + converterHoras(horas, minutos, periodo));

            System.out.print("Deseja continuar? (S/N): ");
            continuar = scanner.next().toUpperCase();

        } while (continuar.equals("S"));

        System.out.println("Fim do programa.");
    }
}