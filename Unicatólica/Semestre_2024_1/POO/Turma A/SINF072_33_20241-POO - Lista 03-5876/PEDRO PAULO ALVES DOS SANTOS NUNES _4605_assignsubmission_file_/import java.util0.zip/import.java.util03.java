public class QuantidadeDeDigitos {

    public static int quantidadeDeDigitos(int numero) {
        int contador = 0;

        do {
            numero /= 10;
            contador++;
        } while (numero != 0);

        return contador;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe um número inteiro: ");
        int numero = scanner.nextInt();

        System.out.printf("O número %d tem %d dígitos.%n", numero, quantidadeDeDigitos(numero));
    }
}