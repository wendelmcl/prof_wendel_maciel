public class JogoDeCraps {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int lancamento1, lancamento2, somaLancamentos;
        char continuar;

        do {
            lancamento1 = (int) (Math.random() * 6) + 1;
            lancamento2 = (int) (Math.random() * 6) + 1;
            somaLancamentos = lancamento1 + lancamento2;

            System.out.printf("Você tirou %d e %d, totalizando %d.%n", lancamento1, lancamento2, somaLancamentos);

            if (somaLancamentos == 7 || somaLancamentos == 11) {
                System.out.println("Você ganhou!");
            } else if (somaLancamentos == 2 || somaLancamentos == 3 || somaLancamentos == 12) {
                System.out.println("Você perdeu!");
            } else {
                System.out.println("Seu ponto é: " + somaLancamentos);

                do {
                    lancamento1 = (int) (Math.random() * 6) + 1;
                    lancamento2 = (int) (Math.random() * 6) + 1;
                    somaLancamentos = lancamento1 + lancamento2;

                    System.out.printf("Você tirou %d e %d, totalizando %d.%n", lancamento1, lancamento2, somaLancamentos);

                    if (somaLancamentos == 7) {
                        System.out.println("Você perdeu!");
                        break;
                    }

                } while (somaLancamentos != 7 && somaLancamentos != somaLancamentos);
            }

            System.out.print("Deseja continuar? (S/N): ");
            continuar = scanner.next().charAt(0);

        } while (continuar == 'S' || continuar == 's');

        System.out.println("Fim do programa.");
    }
}
