public class ReversoDeNumero {

    public static int reversoDeNumero(int numero) {
        int reverso = 0;

        while (numero != 0) {
            reverso = (reverso * 10) + (numero % 10);
            numero /= 10;
        }

        return reverso;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe um número inteiro: ");
        int numero = scanner.nextInt();

        System.out.printf("O reverso do número %d é %d.%n", numero, reversoDeNumero(numero));
    }
}