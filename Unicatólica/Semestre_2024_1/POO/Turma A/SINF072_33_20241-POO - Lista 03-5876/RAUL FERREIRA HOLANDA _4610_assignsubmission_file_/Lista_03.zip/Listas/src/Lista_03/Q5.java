package Lista_03;

import java.util.Random;



	import java.util.Scanner;

	public class Q5 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        boolean jogando = true;

	        while (jogando) {
	            System.out.println("Jogo de Craps!");
	            System.out.println("Pressione ENTER para jogar...");
	            scanner.nextLine();

	            int dado1 = (int) (Math.random() * 6) + 1;
	            int dado2 = (int) (Math.random() * 6) + 1;
	            int total = dado1 + dado2;

	            System.out.println("Você lançou " + dado1 + " e " + dado2 + ", totalizando " + total + ".");

	            if (total == 7 || total == 11) {
	                System.out.println("Você ganhou! É um natural.");
	            } else if (total == 2 || total == 3 || total == 12) {
	                System.out.println("Você perdeu! É um craps.");
	            } else {
	                int ponto = total;
	                System.out.println("Ponto é " + ponto + ". Continue jogando...");

	                while (true) {
	                    System.out.println("Pressione ENTER para jogar...");
	                    scanner.nextLine();

	                    dado1 = (int) (Math.random() * 6) + 1;
	                    dado2 = (int) (Math.random() * 6) + 1;
	                    total = dado1 + dado2;

	                    System.out.println("Você lançou " + dado1 + " e " + dado2 + ", totalizando " + total + ".");

	                    if (total == ponto) {
	                        System.out.println("Você ganhou! Acertou o ponto novamente.");
	                        break;
	                    } else if (total == 7) {
	                        System.out.println("Você perdeu! Tirou um 7 antes de acertar o ponto novamente.");
	                        break;
	                    }
	                }
	            }

	            System.out.println("Deseja jogar novamente? (S/N)");
	            String resposta = scanner.nextLine().toLowerCase();
	            if (!resposta.equals("s")) {
	                jogando = false;
	            }
	        }

	        System.out.println("Obrigado por jogar!");
	    }
	}

