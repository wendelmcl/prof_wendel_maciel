package Atividade05;

import java.util.Random;

public class Ati05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rd = new Random();
		
		int jogada = rd.nextInt(10) + 2;
		
		System.out.println("Caiu no numero: " + jogada);
		
		if (jogada == 7 || jogada == 11) {
			System.out.println("Natural - Você ganhou");
		}else if(jogada == 2 || jogada == 3 || jogada == 12) {
			System.out.println("Craps - Você perdeu");
		}else {
			while (jogada != 7) {
				int jogada2;
				System.out.println("Nova rodada: ");
				jogada2 = rd.nextInt(10) + 2;
				System.out.println("Caiu no numero: " + jogada2);
				if(jogada2 == jogada) {
					System.out.println("Você ganhou o jogo");
					break;
				}else if (jogada2 == 7) {
					System.out.println("Você perdeu");
					break;
					
				}
			}
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXX");
			System.out.println("Fim de jogo");
		}
		

	}

}
