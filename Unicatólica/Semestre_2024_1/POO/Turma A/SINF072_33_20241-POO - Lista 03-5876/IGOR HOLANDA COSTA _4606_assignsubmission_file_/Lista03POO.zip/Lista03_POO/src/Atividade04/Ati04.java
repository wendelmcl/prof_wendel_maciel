package Atividade04;

import java.util.Scanner;

public class Ati04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um numero inteiro: ");
		int n = sc.nextInt();
		
		String nString = "";
		
		String[] reverso = nString.valueOf(n).split("");
		
		for (int i = reverso.length; i > 0; i--) {
			System.out.print(reverso[i - 1]);
		}

	}

}
