package Atividade03;

import java.util.Scanner;

public class Ati03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite um numero inteiro: ");
		int n = sc.nextInt();
		
		String nInt = "";
		String[] Tamanho = nInt.valueOf(n).split("");
		System.out.println("Total de numeros digitados: " + Tamanho.length);

	}

}
