import java.util.Scanner;

public class Questao02{
    public static void main(String[] args) {
        int prestacao, dias;
        float multa;

        Scanner leitor = new Scanner(System.in);

        System.out.println("Insira o valor da prestação:");

        prestacao = leitor.nextInt();
        System.out.print("Dias em atraso:" );

        dias = leitor.nextInt();

        multa = valorPagamento(prestacao, dias);
        System.out.println("Valor total com multa: " + multa);

        while(prestacao != 0){
            System.out.println("Insira o valor da prestação:");

            prestacao = leitor.nextInt();
            if(prestacao == 0 ){
                System.out.println("O valor da prestação precisa ser diferente de zero");
                break;
            }
            System.out.print("Dias em atraso:" );

            dias = leitor.nextInt();

            multa = valorPagamento(prestacao, dias);
            System.out.println("Valor total com multa: " + multa);



        }


}
    public static float valorPagamento(int prestacao, int dias) {
        float multa;
        if (dias == 0) {
            return prestacao;
        } else {
            multa = (prestacao * 0.03f) + prestacao + (prestacao * (0.001f * dias));
            return multa;
        }
    }
}
