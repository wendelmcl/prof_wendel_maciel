import java.util.Scanner;

public class Questao01 {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        char periodo;
        String continuar;
        do {
            System.out.println("Insira a hora (formato 24 horas): ");
            int hora = leitor.nextInt();
            System.out.println("Insira os minutos: ");
            int minutos = leitor.nextInt();

            hora = Entrada(hora);
            if(hora <= 12){
                periodo = 'A';
            } else{
                periodo = 'P';
            }


            System.out.println("Hora convertida: " + Saida(hora, minutos) + " " + periodo + ".M.");


            System.out.println("Deseja converter outra hora? (S/N)");
            continuar = leitor.next();
        } while (continuar.equalsIgnoreCase("S"));

        leitor.close();
    }

    public static String Saida(int hora, int minutos) {
        return hora + ":" + minutos;
    }

    public static int Entrada(int hora){

        if (hora >= 12) {
            if (hora > 12) {
                hora -= 12;
            }
        }
        return hora;
    }
}
