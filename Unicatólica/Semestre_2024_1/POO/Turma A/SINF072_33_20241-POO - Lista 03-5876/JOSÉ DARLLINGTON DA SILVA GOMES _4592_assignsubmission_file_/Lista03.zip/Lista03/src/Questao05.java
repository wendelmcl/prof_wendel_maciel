import java.util.Random;
import java.util.Scanner;

public class Questao05 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantas partidas você deseja jogar? ");
        int numeroPartidas = scanner.nextInt();

        int vitorias = 0;
        int derrotas = 0;

        for (int i = 0; i < numeroPartidas; i++) {
            int primeiraJogada, ponto, lance;

            primeiraJogada = new Random().nextInt(2, 13);
            System.out.println("Primeira Jogada: " + primeiraJogada);

            if (primeiraJogada == 7 || primeiraJogada == 11) {
                System.out.println("Você ganhou!");
                vitorias++;
            } else if (primeiraJogada == 2 || primeiraJogada == 3 || primeiraJogada == 12) {
                System.out.println("Você perdeu!");
                derrotas++;
            } else {
                ponto = primeiraJogada;
                System.out.println("Seu Ponto: " + ponto);
                while (true) {
                    lance = new Random().nextInt(2, 13);
                    System.out.println("Lance: " + lance);

                    if (lance == ponto) {
                        System.out.println("Você ganhou!");
                        vitorias++;
                        break;
                    } else if (lance == 7) {
                        System.out.println("Você perdeu!");
                        derrotas++;
                        break;
                    }
                }
            }
        }


        System.out.println("Resultado final: ");
        System.out.println("Vitórias: " + vitorias);
        System.out.println("Derrotas: " + derrotas);
    }
}