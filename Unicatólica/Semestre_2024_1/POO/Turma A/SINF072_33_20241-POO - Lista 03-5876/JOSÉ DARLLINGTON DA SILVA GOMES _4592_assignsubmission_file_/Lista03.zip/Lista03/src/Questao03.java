import java.sql.SQLOutput;
import java.util.Locale;
import java.util.Scanner;

public class Questao03 {

    public static int QuantiaDigitos(int numero){
        int QtdDigitos = String.valueOf(numero).length();
        return QtdDigitos;
    }

    public static void main(String[] args) {
        int numero;
        String decisao;
        System.out.println("Insira um número");
        Scanner leitor = new Scanner(System.in);
        numero = leitor.nextInt();

        System.out.println(QuantiaDigitos(numero));
        System.out.println("Deseja continuar? S - Sim, N - Não");
        decisao = leitor.next();
        while(decisao.toUpperCase().equals("S")){
            System.out.println("Insira um número");
            numero = leitor.nextInt();
            leitor.nextLine();
            System.out.println(QuantiaDigitos(numero) + " Dígitos");
            System.out.println("Deseja continuar? S - Sim, N - Não");
            decisao = leitor.nextLine().toUpperCase();
            if(decisao.toUpperCase().equals("N")){
                System.out.println("Encerrada");
                break;
            }
        }




    }
}
