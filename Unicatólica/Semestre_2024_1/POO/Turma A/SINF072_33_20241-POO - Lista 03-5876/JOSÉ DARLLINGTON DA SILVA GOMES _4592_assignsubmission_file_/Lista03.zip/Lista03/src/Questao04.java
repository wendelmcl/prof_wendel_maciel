import java.util.Scanner;

public class Questao04 {

    public static int numeroInvertido(int numero) {
        String numeroString = Integer.toString(numero);
        int[] digitos = new int[numeroString.length()];
        int numeroInvertido = 0;

        for (int i = 0; i < digitos.length; i++) {
            digitos[i] = Character.getNumericValue(numeroString.charAt(i));
        }

        for (int i = digitos.length - 1; i >= 0; i--) {
            numeroInvertido = numeroInvertido * 10 + digitos[i];
        }

        return numeroInvertido;
    }

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite um número: ");
        int numero = leitor.nextInt();
        int numeroInvertido = numeroInvertido(numero);
        System.out.println("Número invertido: " + numeroInvertido);
    }

}