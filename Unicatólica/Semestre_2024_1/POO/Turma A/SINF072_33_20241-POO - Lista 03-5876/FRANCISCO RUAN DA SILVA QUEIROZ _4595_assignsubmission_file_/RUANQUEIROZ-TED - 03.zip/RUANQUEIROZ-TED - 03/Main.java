import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // QUESTAO 1
        System.out.println("1. Conversão de 24 horas para 12 horas:");
        char continuar;
        do {
            System.out.print("Digite a hora (0-23): ");
            int hora = scanner.nextInt();
            System.out.print("Digite os minutos (0-59): ");
            int minutos = scanner.nextInt();
            converterPara12Horas(hora, minutos);
            
            System.out.print("Deseja fazer outra conversão? (S/N): ");
            continuar = scanner.next().charAt(0);
        } while (continuar == 'S' || continuar == 's');

        // QUESTAO 2
        System.out.println("\n2. Cálculo do valor da prestação:");
        double totalPago = 0;
        int quantidadePrestacoes = 0;
        double valorPrestacao;
        do {
            System.out.print("Digite o valor da prestação (ou 0 para encerrar): ");
            valorPrestacao = scanner.nextDouble();
            if (valorPrestacao != 0) {
                System.out.print("Digite o número de dias em atraso: ");
                int diasAtraso = scanner.nextInt();
                double valorAPagar = valorPagamento(valorPrestacao, diasAtraso);
                System.out.println("Valor a ser pago: R$" + valorAPagar);
                totalPago += valorAPagar;
                quantidadePrestacoes++;
            }
        } while (valorPrestacao != 0);
        System.out.println("Relatório do dia:");
        System.out.println("Quantidade de prestações pagas: " + quantidadePrestacoes);
        System.out.println("Valor total pago: R$" + totalPago);

        // QUESTAO 3
        System.out.println("\n3. Informar a quantidade de dígitos de um número inteiro:");
        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt();
        int quantidadeDigitos = contarDigitos(numero);
        System.out.println("O número de dígitos de " + numero + " é: " + quantidadeDigitos);

        // QUESTAO 4
        System.out.println("\n4. Retornar o reverso de um número inteiro:");
        System.out.print("Digite um número inteiro: ");
        int numeroReverso = scanner.nextInt();
        int reverso = obterReverso(numeroReverso);
        System.out.println("O reverso de " + numeroReverso + " é: " + reverso);

        // QUESTAO 5
        System.out.println("\n5. Jogo de Craps:");
        jogarCraps();

        scanner.close();
    }

    // Conversor de horas
    public static void converterPara12Horas(int hora, int minutos) {
        String periodo;
        if (hora >= 0 && hora < 12) {
            periodo = "A.M.";
        } else {
            periodo = "P.M.";
            if (hora != 12) {
                hora -= 12;
            }
        }
        System.out.println("Hora convertida: " + hora + ":" + minutos + " " + periodo);
    }

    // Calculo valor da prestacao
    public static double valorPagamento(double valorPrestacao, int diasAtraso) {
        if (diasAtraso == 0) {
            return valorPrestacao;
        } else {
            double multa = valorPrestacao * 0.03;
            double juros = valorPrestacao * 0.001 * diasAtraso;
            return valorPrestacao + multa + juros;
        }
    }

    // Contar Digitos
    public static int contarDigitos(int numero) {
        int count = 0;
        while (numero != 0) {
            numero /= 10;
            count++;
        }
        return count;
    }

    // Reverso do numero inteiro
    public static int obterReverso(int numero) {
        int reverso = 0;
        while (numero != 0) {
            int digito = numero % 10;
            reverso = reverso * 10 + digito;
            numero /= 10;
        }
        return reverso;
    }

    // Jogo de Craps
    public static void jogarCraps() {
        Scanner scanner = new Scanner(System.in);
        char continuar;
        do {
            int dado1 = (int) (Math.random() * 6) + 1;
            int dado2 = (int) (Math.random() * 6) + 1;
            int somaDados = dado1 + dado2;
            System.out.println("Você lançou os dados e obteve um total de " + somaDados);
            if (somaDados == 7 || somaDados == 11) {
                System.out.println("Você ganhou! É um 'natural'!");
            } else if (somaDados == 2 || somaDados == 3 || somaDados == 12) {
                System.out.println("Você perdeu! É um 'craps'!");
            } else {
                int ponto = somaDados;
                System.out.println("Seu ponto é: " + ponto);
                boolean perdeu = false;
                do {
                    System.out.println("Lançando os dados novamente...");
                    int novoDado1 = (int) (Math.random() * 6) + 1;
                    int novoDado2 = (int) (Math.random() * 6) + 1;
                    int novoSomaDados = novoDado1 + novoDado2;
                    System.out.println("Você lançou os dados e obteve um total de " + novoSomaDados);
                    if (novoSomaDados == ponto) {
                        System.out.println("Você ganhou! Acertou o ponto novamente!");
                        break;
                    } else if (novoSomaDados == 7) {
                        System.out.println("Você perdeu! Tirou um 7 antes de acertar o ponto novamente!");
                        perdeu = true;
                    }
                } while (!perdeu);
            }
            System.out.print("Deseja jogar novamente? (S/N): ");
            continuar = scanner.next().charAt(0);
        } while (continuar == 'S' || continuar == 's');
        scanner.close();
    }
}