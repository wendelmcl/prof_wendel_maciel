package q1;

public interface Entregavel {

	public double CalcularFrete();
	
}
