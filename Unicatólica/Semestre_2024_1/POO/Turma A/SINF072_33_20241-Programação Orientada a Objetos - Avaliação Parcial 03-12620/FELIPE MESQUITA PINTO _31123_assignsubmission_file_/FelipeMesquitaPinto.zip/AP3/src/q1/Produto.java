package q1;

public abstract class Produto {
	
	abstract String Getcodigo();
	abstract String GetDescricao();
	



}
