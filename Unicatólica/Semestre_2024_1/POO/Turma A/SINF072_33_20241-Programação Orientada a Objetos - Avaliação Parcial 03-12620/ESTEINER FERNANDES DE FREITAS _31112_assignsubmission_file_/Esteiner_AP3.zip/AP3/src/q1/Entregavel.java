package q1;

public interface Entregavel {
	double calcularFrete();
	
}

