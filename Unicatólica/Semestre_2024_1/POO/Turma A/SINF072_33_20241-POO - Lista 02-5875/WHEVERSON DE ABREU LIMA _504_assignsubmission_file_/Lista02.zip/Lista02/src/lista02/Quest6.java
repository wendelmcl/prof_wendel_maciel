package lista02;
import java.util.Scanner;
public class Quest6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double[] medias = new double[10];
        int contAlunosAcimaMedia = 0;

        for (int i = 0; i < 10; i++) {
            double nota1, nota2, nota3, nota4;

            System.out.println("Digite as quatro notas do " + (i + 1) + "º aluno:");
            nota1 = sc.nextDouble();
            nota2 = sc.nextDouble();
            nota3 = sc.nextDouble();
            nota4 = sc.nextDouble();

            double media = (nota1 + nota2 + nota3 + nota4) / 4;
            medias[i] = media;

            if (media >= 7.0) {
                contAlunosAcimaMedia++;
            }
        }

        System.out.println(contAlunosAcimaMedia + " alunos tiveram média igual ou superior a 7.0.");
    }
		
		
}
