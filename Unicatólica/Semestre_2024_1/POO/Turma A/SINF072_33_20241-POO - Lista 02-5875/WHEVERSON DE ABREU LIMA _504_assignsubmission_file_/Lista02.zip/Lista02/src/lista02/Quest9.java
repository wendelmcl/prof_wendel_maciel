package lista02;
import java.util.Scanner;
public class Quest9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] vetorA = new int[10]; 
        int soma = 0; 
        
        System.out.println("Digite 10 números inteiros:");
        for (int i = 0; i < vetorA.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            vetorA[i] = sc.nextInt(); 
        }
        
        for (int numero : vetorA) {
            soma += numero; 
        }
        
        System.out.println("A soma dos quadrados dos elementos do vetor é: " + soma);
    }
}
