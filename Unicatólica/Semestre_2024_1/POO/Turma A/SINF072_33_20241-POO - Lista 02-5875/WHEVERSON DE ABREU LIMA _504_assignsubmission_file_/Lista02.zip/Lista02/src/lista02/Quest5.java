package lista02;
import java.util.Scanner;
public class Quest5 {
	/*Faça um programa que receba dois números inteiros e gere os números inteiros que
	estão no intervalo compreendido por eles.*/

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int inicio, fim;
		
		   System.out.print("Digite o primeiro número inteiro: ");
		   int n1 = sc.nextInt();

		   System.out.print("Digite o segundo número inteiro: ");
		   int n2 = sc.nextInt();
		   
		   if (n1 < n2) {
			   inicio = n1;
			   fim = n2;
		   } else {
			   inicio = n2;
			   fim = n1;
		   }
		   System.out.println("Números inteiros no intervalo entre " + inicio + " e " + fim + ":");
	        for (int i = inicio + 1; i < fim; i++) {
	            System.out.println(i);
	        }
		        
		    }
		


	}

