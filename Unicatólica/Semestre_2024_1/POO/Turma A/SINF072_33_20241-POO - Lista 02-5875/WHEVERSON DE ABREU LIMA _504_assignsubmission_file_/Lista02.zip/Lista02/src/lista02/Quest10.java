package lista02;
import java.util.Scanner;
public class Quest10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] vetorA = new int[10];
        int[] vetorB = new int[10];
        int[] vetorC = new int[20]; 
        
        
        System.out.println("Digite os elementos do vetor A:");
        for (int i = 0; i < vetorA.length; i++) {
            System.out.print("Elemento " + (i + 1) + " de A: ");
            vetorA[i] = sc.nextInt();
        }
        
       
        System.out.println("Digite os elementos do vetor B:");
        for (int i = 0; i < vetorB.length; i++) {
            System.out.print("Elemento " + (i + 1) + " de B: ");
            vetorB[i] = sc.nextInt();
        }
        
       
        for (int i = 0; i < vetorA.length; i++) {
            vetorC[2 * i] = vetorA[i]; 
            vetorC[2 * i + 1] = vetorB[i]; 
        }
        
       
        System.out.println("Vetor C, intercalado:");
        for (int i = 0; i < vetorC.length; i++) {
            System.out.print(vetorC[i] + " ");
        }
        System.out.println();
        }


	}


