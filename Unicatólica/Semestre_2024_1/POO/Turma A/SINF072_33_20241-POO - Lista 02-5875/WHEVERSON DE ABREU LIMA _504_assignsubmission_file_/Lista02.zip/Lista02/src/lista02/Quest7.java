package lista02;
import java.util.Scanner;
public class Quest7 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
        int[] num = new int[5];
        int soma = 0;
        long multiplicacao = 1;

        System.out.println("Digite 5 números inteiros:");

        for (int i = 0; i < 5; i++) {
            num[i] = sc.nextInt();
            soma += num[i];
            multiplicacao *= num[i];
        }

        System.out.println("Os números digitados foram: ");
        for (int i = 0; i < 5; i++) {
            System.out.print(num[i] + " ");
        }

        System.out.println("\nA soma dos números é: " + soma);
        System.out.println("A multiplicação dos números é: " + multiplicacao);
    }
}