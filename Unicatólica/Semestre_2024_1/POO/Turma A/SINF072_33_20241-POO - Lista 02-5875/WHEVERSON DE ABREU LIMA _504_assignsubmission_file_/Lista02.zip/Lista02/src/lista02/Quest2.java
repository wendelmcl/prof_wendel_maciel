package lista02;
import java.util.Scanner;
public class Quest2 {
	//Faça um programa que leia 5 números e informe o maior número.

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int maiorNumero = Integer.MIN_VALUE;
		int i = 0;
		
		System.out.println("Digite 5 números:");
		for(i = 1; i <= 5; i++) {
			System.out.println("Número " + (i) + ": ");
			int numero = sc.nextInt();
			
			if (numero > maiorNumero) {
				maiorNumero = numero;
			}
		}
		System.out.println("\nMaior número: " + maiorNumero);
	}
}

