package lista02;
import java.util.Scanner;
	//Faça um programa que leia 5 números e informe a soma e a média dos números
public class Quest3 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		double n1, n2, n3, n4, n5, soma, media;
		
		System.out.println("Digite o primeiro número: ");
		n1 = sc.nextDouble();
		
		System.out.println("Digite o segundo número: ");
		n2 = sc.nextDouble();
		
		System.out.println("Digite o terceiro número: ");
		n3 = sc.nextDouble();
		
		System.out.println("Digite o quarto número: ");
		n4 = sc.nextDouble();
		
		System.out.println("Digite o quinto número: ");
		n5 = sc.nextDouble();
		
		System.out.println("--------------------------");
		soma = n1 + n2 + n3 + n4 + n5; 
		System.out.println("Soma dos números: " + soma);
		
		System.out.println("--------------------------");
		media = soma / 5;
		System.out.println("Média dos números: " + media);
	}
}
