package lista02;
import java.util.Scanner;
public class Quest8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int[] idades = new int[5];
        double[] alturas = new double[5];

        System.out.println("Digite a idade e a altura de 5 pessoas: (digite a idade e aperte enter \nem seguida coloque a altura)");

        for (int i = 0; i < 5; i++) {
            idades[i] = sc.nextInt();
            alturas[i] = sc.nextDouble();
        }

        System.out.println("Idades e alturas na ordem inversa:");

        for (int i = 4; i >= 0; i--) {
            System.out.println("Idade: " + idades[i] + " Altura: " + alturas[i]);
        }
    }
}