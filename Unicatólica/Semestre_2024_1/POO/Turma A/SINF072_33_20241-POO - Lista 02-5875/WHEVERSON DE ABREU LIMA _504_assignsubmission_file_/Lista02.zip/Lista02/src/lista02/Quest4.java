package lista02;
	//Faça um programa que imprima na tela apenas os números ímpares entre 1 e 50.
public class Quest4 {

	public static void main(String[] args) {
		int i = 0;
		
		for(i = 1; i <= 50; i++) {
			if(i % 2 != 0 ) {System.out.println(i);
			}
			}
		}

	}


