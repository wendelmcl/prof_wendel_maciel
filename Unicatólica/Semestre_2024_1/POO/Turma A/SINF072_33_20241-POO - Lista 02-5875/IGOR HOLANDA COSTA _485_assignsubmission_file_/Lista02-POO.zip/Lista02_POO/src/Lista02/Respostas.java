package Lista02;
import java.util.Scanner;
public class Respostas {

	public static void main(String[] args) {
		//Questão 1
		for (int i = 1; i <= 20; i++) {
			System.out.println(i);
		}
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		
			
		//Questão 2
			Scanner sc = new Scanner(System.in);
			int maior = Integer.MIN_VALUE;
			System.out.println("Digite 5 numeros: ");
			for (int i = 0; i < 5; i++) {
				int numero = sc.nextInt();
				if (numero > maior) {
					maior = numero;
				}
			}
			System.out.println("O maior é " + maior);
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
			
		//Questão 3
			int soma = 0;
			double media;
			System.out.println("Digite 5 numeros: ");
			for (int i = 0; i < 5; i++) {
				int n = sc.nextInt();
				soma += n;
			}
			media = (double) soma / 5;
			System.out.println("A soma sera: " + soma);
			System.out.println("A media sera: " + media);
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
			
		//Questão 4
			
			for (int i = 1; i <= 50; i++) {
				if(i % 2 == 1) {
					System.out.println(i);
				}
			}
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		//Questão 5
			System.out.println("Digite um valor de X e um valor de Y: ");
			int X = sc.nextInt();
			int Y = sc.nextInt();
			for (int i = X; i <= Y; i++) {
				if(i != X && i != Y) {
					System.out.println(i);
					
				}
				
			}
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
			//Questão 6
			int MediaM7 = 0;
			for (int i = 1; i <= 10; i++) {
				System.out.println("Aluno: " + i);
				double Snota = 0;
				for (double n = 1; n <= 4; n++) {
					Double nota = sc.nextDouble();
					Snota += nota;
				}
				double Media = Snota / 4;
				System.out.println("A media do aluno " + i + ": " + Media);
				if (Media >= 7) {
					MediaM7++;
				}
			}
			System.out.println("A quantidade de alunos com nota maior ou igual a 7,0 é:" + MediaM7);
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
			//Questão 7
			 
			int[] numeros = new int[5];
	        System.out.println("Digite 5 números inteiros:");
	        for (int i = 0; i < 5; i++) {
	            numeros[i] = sc.nextInt();
	        }
	        
	        int somas = 0;
	        int multiplicacao = 1;
	        
	        System.out.print("Números digitados: ");
	        for (int i = 0; i < 5; i++) {
	            System.out.print(numeros[i] + " ");
	            somas += numeros[i];
	            multiplicacao *= numeros[i];
	        }
	        
	        System.out.println("\nSoma: " + somas);
	        System.out.println("Multiplicação: " + multiplicacao);
	        System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
	        //Questão 8
	        int[] idade = new int[5];
	        double[] altura = new double[5];
	        
	        for (int i = 0; i < 5; i++) {
	        	System.out.println("Digite a idade da pessoa " + (i + 1) + ":");
	        	idade[i] = sc.nextInt();
	        	System.out.println("Digite a altura da pessoa" + (i + 1) + ":");
	        	altura[i] = sc.nextDouble();
	        }
	        
	        System.out.println("A ordem das alturas e idades inversa: ");
	        for (int i = 4; i >= 0; i--) {
	        	System.out.println("Pessoa" + (i + 1) + ": idade = " + idade[i] + ", altura = " + altura[i]);
	        }
	        System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
	        //Questão 9
	        int[] A = new int[10];
	        System.out.println("Digite 10 numeros inteiros: ");
	        for (int i = 1; i < 10; i++) {
	        	A[i] = sc.nextInt(); 
	        }
	        int SomaQ = 1;
	        
	        for (int i = 1; i < 10; i++) {
	        	SomaQ += A[i] * A[i];
	        }
	        System.out.println("A soma dos quadrados dos elemntos é: " + SomaQ);
	        System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
	        //Questão 9
	        
	        int[] vetor1 = {1, 2, 3, 4, 5 ,6 ,7 ,8 ,9 ,10};
	        int[] vetor2 = {11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
	        
	        int[] vetor3 = new int[20];
	        for (int i = 0; i < 10; i ++) {
	        	vetor3[i * 2] = vetor1[i];
	        	vetor3[i * 2 + 1] = vetor2[i];
	        }
	        
	        System.out.println("O terceiro vetor: ");
	        for (int i = 0; i < 20; i++) {
	        	System.out.println(vetor3[i] + " ");
	        }
		
		
			
			
			
		}

	}


