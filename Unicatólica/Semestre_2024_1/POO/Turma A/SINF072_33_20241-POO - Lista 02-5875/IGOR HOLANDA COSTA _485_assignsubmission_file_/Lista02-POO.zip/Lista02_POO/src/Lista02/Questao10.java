package Lista02;

public class Questao10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] vetor1 = {1, 2, 3, 4, 5 ,6 ,7 ,8 ,9 ,10};
        int[] vetor2 = {11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
        
        int[] vetor3 = new int[20];
        for (int i = 0; i < 10; i ++) {
        	vetor3[i * 2] = vetor1[i];
        	vetor3[i * 2 + 1] = vetor2[i];
        }
        
        System.out.println("O terceiro vetor: ");
        for (int i = 0; i < 20; i++) {
        	System.out.println(vetor3[i] + " ");
        }

	}

}
