package atv9;

import java.util.Scanner;

public class SomaQuadrados {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final int TAMANHO_VETOR = 10;
        int[] vetorA = new int[TAMANHO_VETOR];

        System.out.println("Digite os " + TAMANHO_VETOR + " números inteiros:");
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            vetorA[i] = scanner.nextInt();
        }

        int somaQuadrados = 0;
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            somaQuadrados += vetorA[i] * vetorA[i];
        }

        System.out.println("A soma dos quadrados dos elementos do vetor é: " + somaQuadrados);

        scanner.close();
    }
}

