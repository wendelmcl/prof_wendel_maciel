package atv6;

import java.util.Scanner;

public class MediaAlunos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final int NUM_ALUNOS = 10;
        double[] medias = new double[NUM_ALUNOS];

        for (int i = 0; i < NUM_ALUNOS; i++) {
            System.out.println("Aluno " + (i + 1) + ":");
            double somaNotas = 0;

            for (int j = 1; j <= 4; j++) {
                System.out.print("Digite a nota " + j + ": ");
                double nota = scanner.nextDouble();
                somaNotas += nota;
            }

            medias[i] = somaNotas / 4;
        }

        int alunosAprovados = 0;
        for (double media : medias) {
            if (media >= 7.0) {
                alunosAprovados++;
            }
        }

        System.out.println("Número de alunos com média maior ou igual a 7.0: " + alunosAprovados);

        scanner.close();
    }
}
