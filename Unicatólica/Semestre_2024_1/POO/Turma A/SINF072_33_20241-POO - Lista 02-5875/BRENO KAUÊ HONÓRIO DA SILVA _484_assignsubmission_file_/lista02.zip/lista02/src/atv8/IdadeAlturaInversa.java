package atv8;

import java.util.Scanner;

public class IdadeAlturaInversa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final int NUM_PESSOAS = 5;
        int[] idades = new int[NUM_PESSOAS];
        double[] alturas = new double[NUM_PESSOAS];

        for (int i = 0; i < NUM_PESSOAS; i++) {
            System.out.println("Pessoa " + (i + 1) + ":");
            System.out.print("Idade: ");
            idades[i] = scanner.nextInt();
            System.out.print("Altura (em metros): ");
            alturas[i] = scanner.nextDouble();
        }

        System.out.println("\nIdades e Alturas (na ordem inversa):");
        for (int i = NUM_PESSOAS - 1; i >= 0; i--) {
            System.out.println("Pessoa " + (i + 1) + ": Idade: " + idades[i] + " anos, Altura: " + alturas[i] + " metros");
        }

        scanner.close();
    }
}

