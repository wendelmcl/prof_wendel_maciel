package atv10;

import java.util.Scanner;

public class IntercalacaoVetores {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final int TAMANHO_VETOR = 10;
        int[] vetorA = new int[TAMANHO_VETOR];
        int[] vetorB = new int[TAMANHO_VETOR];
        int[] vetorC = new int[TAMANHO_VETOR * 2];

        System.out.println("Digite os elementos do vetor A:");
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            vetorA[i] = scanner.nextInt();
        }

        System.out.println("Digite os elementos do vetor B:");
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            vetorB[i] = scanner.nextInt();
        }

        int indiceC = 0;
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            vetorC[indiceC++] = vetorA[i];
            vetorC[indiceC++] = vetorB[i];
        }

        System.out.println("Vetor C intercalado:");
        for (int i = 0; i < TAMANHO_VETOR * 2; i++) {
            System.out.println("Elemento " + (i + 1) + ": " + vetorC[i]);
        }

        scanner.close();
    }
}

