package atv7;

import java.util.Scanner;

public class OperacoesVetor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final int TAMANHO_VETOR = 5;
        int[] numeros = new int[TAMANHO_VETOR];

        System.out.println("Digite os " + TAMANHO_VETOR + " números inteiros:");
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        int soma = 0;
        int multiplicacao = 1;
        for (int numero : numeros) {
            soma += numero;
            multiplicacao *= numero;
        }

        System.out.print("Números do vetor: ");
        for (int i = 0; i < TAMANHO_VETOR; i++) {
            System.out.print(numeros[i]);
            if (i < TAMANHO_VETOR - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();

        System.out.println("Soma: " + soma);
        System.out.println("Multiplicação: " + multiplicacao);

        scanner.close();
    }
}
