package Lista_02;

import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] idades = new int[5];
        double[] alturas = new double[5];

        System.out.println("Digite as idades e alturas das 5 pessoas:");

        for (int i = 0; i < 5; i++) {
            System.out.print("Idade da pessoa " + (i + 1) + ": ");
            idades[i] = scanner.nextInt();

            System.out.print("Altura da pessoa " + (i + 1) + ": ");
            alturas[i] = scanner.nextDouble();
        }

        System.out.println("Idades e alturas na ordem inversa:");

        for (int i = 4; i >= 0; i--) {
            System.out.println("Pessoa " + (i + 1) + " - Idade: " + idades[i] + ", Altura: " + alturas[i]);
        }
    }
}
