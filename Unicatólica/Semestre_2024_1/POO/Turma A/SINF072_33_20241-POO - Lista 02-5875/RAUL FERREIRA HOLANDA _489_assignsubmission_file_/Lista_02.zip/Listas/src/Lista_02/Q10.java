package Lista_02;

import java.util.Scanner;

public class Q10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] vetor1 = new int[10];
        int[] vetor2 = new int[10];
        int[] vetor3 = new int[20];

        System.out.println("Digite os elementos do primeiro vetor:");

        for (int i = 0; i < 10; i++) {
            vetor1[i] = scanner.nextInt();
        }

        System.out.println("Digite os elementos do segundo vetor:");

        for (int i = 0; i < 10; i++) {
            vetor2[i] = scanner.nextInt();
        }

        int indiceVetor1 = 0;
        int indiceVetor2 = 0;
        for (int i = 0; i < 20; i++) {
            if (i % 2 == 0) {
                vetor3[i] = vetor1[indiceVetor1];
                indiceVetor1++;
            } else {
                vetor3[i] = vetor2[indiceVetor2];
                indiceVetor2++;
            }
        }

        System.out.println("Terceiro vetor intercalado:");

        for (int i = 0; i < 20; i++) {
            System.out.print(vetor3[i] + " ");
        }
    }
}
