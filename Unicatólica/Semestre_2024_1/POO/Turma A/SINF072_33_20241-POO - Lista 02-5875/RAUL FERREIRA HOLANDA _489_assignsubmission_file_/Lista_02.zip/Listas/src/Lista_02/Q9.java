package Lista_02;

import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] vetor = new int[10];
        int somaQuadrados = 0;

        System.out.println("Digite 10 números inteiros:");

        for (int i = 0; i < 10; i++) {
            vetor[i] = scanner.nextInt();
            somaQuadrados += vetor[i] * vetor[i];
        }

        System.out.println("A soma dos quadrados dos elementos do vetor é: " + somaQuadrados);
    }
}
