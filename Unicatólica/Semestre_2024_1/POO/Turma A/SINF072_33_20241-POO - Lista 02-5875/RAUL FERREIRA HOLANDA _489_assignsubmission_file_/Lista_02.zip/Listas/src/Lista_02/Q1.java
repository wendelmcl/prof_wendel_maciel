package Lista_02;



	public class Q1 {
	    public static void main(String[] args) {
	        for (int i = 1; i <= 20; i++) {
	            System.out.println(i);
	        }
	    }
	}
	
	/*public class Main {
    public static void main(String[] args) {
        // Imprime os números de 1 a 20 um ao lado do outro
        for (int i = 1; i <= 20; i++) {
            System.out.print(i + " ");
        }
    }
	*/