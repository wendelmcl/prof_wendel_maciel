package Questao02;

import java.util.Scanner;

public class LargestNumber {
  public static void main(String[] args) {
    try (Scanner scanner = new Scanner(System.in)) {
		int largestNumber = Integer.MIN_VALUE;

		for (int i = 1; i <= 5; i++) {
		  System.out.print("informe o número " + i + ": ");
		  int num = scanner.nextInt();
		  if (num > largestNumber) {
		    largestNumber = num;
		  }
		}

		System.out.println("O maior número é : " + largestNumber);
	}
  }
}