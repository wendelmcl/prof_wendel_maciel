package Questao06;

import java.util.Scanner;
import java.util.Vector;

public class Average {
  public static void main(String[] args) {
    try (Scanner scanner = new Scanner(System.in)) {
		Vector<Double> averages = new Vector<Double>();
		int count = 0;

		for (int i = 0; i < 10; i++) {
		  double sum = 0;

		  System.out.println("Insira a nota dos alunos " + (i + 1) + ":");
		  for (int j = 0; j < 4; j++) {
		    System.out.print("Nota " + (j + 1) + ": ");
		    sum += scanner.nextDouble();
		  }

		  double average = sum / 4;
		  averages.add(average);

		  if (average >= 7.0) {
		    count++;
		  }
		}

		System.out.println("Número de estudantes que tiveram notas maiores ou superiores a 7: " + count);
	}
  }
}