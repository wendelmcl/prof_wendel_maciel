package Questao10;

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    // Inicialize os vetores A e B
    int[] A = new int[10];
    int[] B = new int[10];

    try (
	Scanner scanner = new Scanner(System.in)) {
		for(int i = 0; i < 10; i++) {
		  System.out.print("Digite os elementos do vetor " + (i+1) + ": ");
		  A[i] = scanner.nextInt();
		  System.out.print("digite para saber a posição do vetor b " + (i+1) + ": ");
		  B[i] = scanner.nextInt();
		}
	}
    
    int[] C = new int[20];
    for(int i = 0; i < 10; i++) {
      C[2*i] = A[i];
      C[2*i+1] = B[i];
    }

    // Print vetor C
    System.out.print("Vetor C is: ");
    for(int i = 0; i < 20; i++) {
      System.out.print(C[i] + " ");
    }
    System.out.println();
  }
}