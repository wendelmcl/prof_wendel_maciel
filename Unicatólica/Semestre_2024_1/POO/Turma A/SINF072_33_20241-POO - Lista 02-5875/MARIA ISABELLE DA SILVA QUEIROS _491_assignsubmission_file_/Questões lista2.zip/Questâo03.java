package Questao03;

import java.util.Scanner;

public class SumAndAverage {
  public static void main(String[] args) {
    try (Scanner scanner = new Scanner(System.in)) {
		int sum = 0;
		int count = 0;

		while (count < 5) {
		  System.out.print("Informe o  número" + (count + 1) + ": ");
		  int number = scanner.nextInt();
		  sum += number;
		  count++;
		}

		double average = (double) sum / 5;

		System.out.println("A soma dos números informados são: " + sum);
		System.out.println("A média dos números informados é: " + average);
	}
  }
}