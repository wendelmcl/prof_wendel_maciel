package Questao08;

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    
    int[] age = new int[5];
    double[] height = new double[5];

    try (
	Scanner scanner = new Scanner(System.in)) {
		for(int i = 0; i < 5; i++) {
		  System.out.print("Digite a idade e altura " + (i+1) + ": ");
		  age[i] = scanner.nextInt();
		  height[i] = scanner.nextDouble();
		}
	}
    
    for(int i = 4; i >= 0; i--) {
      System.out.println("Informe a idade" + (i+1) + " is: " + age[i]);
      System.out.println("Informe a altura " + (i+1) + " is: " + height[i]);
    }
  }
}