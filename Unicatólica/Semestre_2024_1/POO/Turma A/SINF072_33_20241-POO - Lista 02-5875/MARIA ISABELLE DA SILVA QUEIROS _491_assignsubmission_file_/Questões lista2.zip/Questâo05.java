package Questao05;

import java.util.Scanner;

public class Range {
  public static void main(String[] args) {
    try (Scanner scanner = new Scanner(System.in)) {
		System.out.print("Digite o primeiro número inteiro: ");
		int start = scanner.nextInt();

		System.out.print("Digite  o segundo número inteiro: ");
		int end = scanner.nextInt();

		if (start < end) {
		  for (int i = start + 1; i < end; i++) {
		    System.out.print(i + " ");
		  }
		} else if (start > end) {
		  for (int i = end + 1; i < start; i++) {
		    System.out.print(i + " ");
		  }
		} else {
		  System.out.println("Não há números inteiros entre " + start + " and " + end + ".");
		}
	}
  }
}