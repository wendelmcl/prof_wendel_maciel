package Questao09;

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    // Inicialize o vetor A
    int[] A = new int[10];

    try (
	Scanner scanner = new Scanner(System.in)) {
		for(int i = 0; i < 10; i++) {
		  System.out.print("Digite os Elementos " + (i+1) + ": ");
		  A[i] = scanner.nextInt();
		}
	}
    
    double sumOfSquares = 0;
    for(int i = 0; i < 10; i++) {
      sumOfSquares += Math.pow(A[i], 2);
    }

   
    System.out.println("A soma dos Elementos do Vetor A: " + sumOfSquares);
  }
}