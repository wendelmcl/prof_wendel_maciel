package Questao07;

import java.util.Scanner;

public class VectorProgram {
  public static void main(String[] args) {
    try (Scanner scanner = new Scanner(System.in)) {
		int[] numbers = new int[5];
		int sum = 0;
		int product = 1;

		// Read the 5 numbers from the user
		for (int i = 0; i < 5; i++) {
		  System.out.print("Digite " + (i + 1) + ": ");
		  numbers[i] = scanner.nextInt();
		  sum += numbers[i];
		  product *= numbers[i];
		}

		// Print the sum, product, and numbers
		System.out.println("Soma: " + sum);
		System.out.println("Produto: " + product);
		System.out.print("Números:");
		for (int i = 0; i < 5; i++) {
		  System.out.print(" " + numbers[i]);
		}
	}
    System.out.println();
  }
}