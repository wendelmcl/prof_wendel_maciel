for (int i = 1; i <= 20; i++) {
    System.out.println(i);
}