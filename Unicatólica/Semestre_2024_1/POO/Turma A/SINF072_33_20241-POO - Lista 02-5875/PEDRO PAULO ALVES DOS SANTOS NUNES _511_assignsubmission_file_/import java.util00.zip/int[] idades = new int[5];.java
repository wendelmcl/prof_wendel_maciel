int[] idades = new int[5];
double[] alturas = new double[5];
for (int i = 0; i < 5; i++) {
    System.out.print("Informe a idade da pessoa " + (i + 1) + ": ");
    idades[i] = scanner.nextInt();
    System.out.print("Informe a altura da pessoa " + (i + 1) + ": ");
    alturas[i] = scanner.nextDouble();
}
for (int i = 4; i >= 0; i--) {
    System.out.println("A idade da pessoa " + (i + 1) + " é: " + idades[i]);
    System.out.println("A altura da pessoa " + (i + 1) + " é: " + alturas[i]);
}