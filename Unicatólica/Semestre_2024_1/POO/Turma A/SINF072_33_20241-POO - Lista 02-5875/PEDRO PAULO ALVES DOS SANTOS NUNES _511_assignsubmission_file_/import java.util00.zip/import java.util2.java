int maior = Integer.MIN_VALUE;
for (int i = 0; i < 5; i++) {
    System.out.print("Informe um número: ");
    int numero = scanner.nextInt();
    if (numero > maior) {
        maior = numero;
    }
}
System.out.println("O maior número é: " + maior);