int soma = 0;
for (int i = 0; i < 5; i++) {
    System.out.print("Informe um número: ");
    int numero = scanner.nextInt();
    soma += numero;
}
double media = (double) soma / 5;
System.out.println("A soma é: " + soma);
System.out.println("A média é: " + media);