int[] vetorA = new int[10];
int soma = 0;
for (int i = 0; i < 10; i++) {
    System.out.print("Informe um número: ");
    int numero = scanner.nextInt();
    vetorA[i] = numero;
    soma += numero * numero;
}
System.out.println("A soma dos quadrados dos elementos do vetor é: " + soma);