int[] numeros = new int[5];
int soma = 0;
int multiplicacao = 1;
for (int i = 0; i < 5; i++) {
    System.out.print("Informe um número: ");
    int numero = scanner.nextInt();
    numeros[i] = numero;
    soma += numero;
    multiplicacao *= numero;
}
System.out.println("A soma é: " + soma);
System.out.println("A multiplicação é: " + multiplicacao);
System.out.println("Os números são: " + Arrays.toString(numeros));