int[] vetorA = new int[10];
int[] vetorB = new int[10];
int[] vetorC = new int[20];
for (int i = 0; i < 10; i++) {
    System.out.print("Informe um número para o vetor A: ");
    vetorA[i] = scanner.nextInt();
    System.out.print("Informe um número para o vetor B: ");
    vetorB[i] = scanner.nextInt();
    vetorC[2 * i] = vetorA[i];
    vetorC[2 * i + 1] = vetorB[i];
}
System.out.println("O vetor C é: " + Arrays.toString(vetorC));
