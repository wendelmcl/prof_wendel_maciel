import java.util.Scanner;

public class q6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Declara e inicializa o vetor de médias
        double[] medias = new double[10];

        // Armazena as notas de cada aluno
        for (int i = 0; i < medias.length; i++) {
            System.out.print("Digite as 4 notas do aluno " + (i + 1) + ": ");
            for (int j = 0; j < 4; j++) {
                double nota = scanner.nextDouble();
                medias[i] += nota;
            }
            medias[i] /= 4; // Calcula a média do aluno
        }

        // Conta a quantidade de alunos com média >= 7.0
        int aprovados = 0;
        for (double media : medias) {
            if (media >= 7.0) {
                aprovados++;
            }
        }

        System.out.println("Número de alunos com média maior ou igual a 7.0: " + aprovados);
    }
}
