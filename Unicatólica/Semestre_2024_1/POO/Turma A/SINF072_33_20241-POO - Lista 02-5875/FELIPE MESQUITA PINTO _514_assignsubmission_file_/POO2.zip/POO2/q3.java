import java.util.Scanner;

public class q3 {  public static void main(String[] args) {
    int soma = 0;
    for (int i = 1; i <= 5; i++) {
        int numero = leNumero();
        soma += numero;
    }
    double media = (double) soma / 5;
    System.out.println("A soma dos números é: " + soma);
    System.out.println("A média dos números é: " + media);
}

private static int leNumero() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Digite um número: ");
    return scanner.nextInt();
}
}
