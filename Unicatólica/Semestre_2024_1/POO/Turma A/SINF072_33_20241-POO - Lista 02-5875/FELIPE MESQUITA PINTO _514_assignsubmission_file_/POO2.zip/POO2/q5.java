import java.util.Scanner;

public class q5 {
    public static void main(String[] args) {
        int inicio = leNumero("Digite o número inicial: ");
        int fim = leNumero("Digite o número final: ");

        for (int i = inicio; i <= fim; i++) {
            System.out.println(i);
        }
    }

    private static int leNumero(String mensagem) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(mensagem);
        return scanner.nextInt();
    }
}
