import java.util.Scanner;
public class q2 {
    
    public static void main(String[] args) {
        int maior = Integer.MIN_VALUE;
        for (int i = 1; i <= 5; i++) {
            int numero = leNumero();
            if (numero > maior) {
                maior = numero;
            }
        }
        System.out.println("O maior número é: " + maior);
    }

    private static int leNumero() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite um número: ");
        return scanner.nextInt();
    }
}
