import java.util.Scanner;

public class q8 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Declara e inicializa os vetores
        int[] idades = new int[5];
        double[] alturas = new double[5];

        // Armazena idade e altura de cada pessoa
        for (int i = 0; i < idades.length; i++) {
            System.out.print("Digite a idade da pessoa " + (i + 1) + ": ");
            idades[i] = scanner.nextInt();
            System.out.print("Digite a altura da pessoa " + (i + 1) + ": ");
            alturas[i] = scanner.nextDouble();
        }

        // Imprime idade e altura na ordem inversa
        System.out.println("\nIdade e altura na ordem inversa:");
        for (int i = idades.length - 1; i >= 0; i--) {
            System.out.println("Idade: " + idades[i] + ", Altura: " + alturas[i]);
        }
    }
}
