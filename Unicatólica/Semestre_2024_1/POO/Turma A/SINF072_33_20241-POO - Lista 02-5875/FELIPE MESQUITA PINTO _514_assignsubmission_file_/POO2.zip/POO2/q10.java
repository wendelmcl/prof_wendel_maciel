
import java.util.Scanner;

public class q10 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Declara e inicializa os vetores
        int[] vetorA = new int[10];
        int[] vetorB = new int[10];
        int[] vetorC = new int[20];

        // Lê os elementos do vetor A
        for (int i = 0; i < vetorA.length; i++) {
            System.out.print("Digite o elemento " + (i + 1) + " do vetor A: ");
            vetorA[i] = scanner.nextInt();
        }

        // Lê os elementos do vetor B
        for (int i = 0; i < vetorB.length; i++) {
            System.out.print("Digite o elemento " + (i + 1) + " do vetor B: ");
            vetorB[i] = scanner.nextInt();
        }

        // Intercala os elementos dos vetores A e B no vetor C
        int posicaoC = 0;
        for (int i = 0; i < vetorA.length; i++) {
            vetorC[posicaoC] = vetorA[i];
            posicaoC++;
            vetorC[posicaoC] = vetorB[i];
            posicaoC++;
        }

        // Mostra o vetor C
        System.out.println("\nVetor C:");
        for (int elemento : vetorC) {
            System.out.print(elemento + " ");
        }
    }
    
}
