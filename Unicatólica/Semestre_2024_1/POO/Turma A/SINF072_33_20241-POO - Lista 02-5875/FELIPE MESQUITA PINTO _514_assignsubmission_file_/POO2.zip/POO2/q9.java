import java.util.Scanner;

public class q9 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Declara e inicializa o vetor
        int[] numeros = new int[10];

        // Lê os números do vetor
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }
    }
