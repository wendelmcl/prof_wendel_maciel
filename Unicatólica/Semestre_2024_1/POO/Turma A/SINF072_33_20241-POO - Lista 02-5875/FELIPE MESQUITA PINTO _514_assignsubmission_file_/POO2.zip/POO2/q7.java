import java.util.Scanner;


public class q7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    
        // Declara e inicializa o vetor
        int[] numeros = new int[5];
    
        // Lê os números do vetor
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }
    
        // Calcula a soma
        int soma = 0;
        for (int numero : numeros) {
            soma += numero;
        }
    
        // Calcula a multiplicação
        int produto = 1;
        for (int numero : numeros) {
            produto *= numero;
        }
    
        // Mostra os números, a soma e a multiplicação
        System.out.println("Números:");
        for (int numero : numeros) {
            System.out.print(numero + " ");
        }
        System.out.println("\nSoma: " + soma);
        System.out.println("Multiplicação: " + produto);
    }
}
