import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
      // QUESTAO 1
        System.out.println("1. Imprimir números de 1 a 20 abaixo um do outro:");
        for (int i = 1; i <= 20; i++) {
            System.out.println(i);
        }
        
        System.out.println("\n1. Imprimir números de 1 a 20 ao lado um do outro:");
        for (int i = 1; i <= 20; i++) {
            System.out.print(i + " ");
        }
        
      // QUESTAO 2
        System.out.println("\n\n2. Encontrar o maior número dentre 5 números:");
        int maior = Integer.MIN_VALUE;
        for (int i = 1; i <= 5; i++) {
            System.out.print("Digite o número " + i + ": ");
            int num = scanner.nextInt();
            if (num > maior) {
                maior = num;
            }
        }
        System.out.println("O maior número é: " + maior);
        
        // QUESTAO 3
        System.out.println("\n3. Calcular soma e média de 5 números:");
        int soma = 0;
        for (int i = 1; i <= 5; i++) {
            System.out.print("Digite o número " + i + ": ");
            int num = scanner.nextInt();
            soma += num;
        }
        double media = (double) soma / 5;
        System.out.println("A soma dos números é: " + soma);
        System.out.println("A média dos números é: " + media);
        
        // QUESTAO 4
        System.out.println("\n4. Números ímpares entre 1 e 50:");
        for (int i = 1; i <= 50; i++) {
            if (i % 2 != 0) {
                System.out.print(i + " ");
            }
        }
        
        // QUESTAO 5
        System.out.println("\n\n5. Gerar números no intervalo entre dois números:");
        System.out.print("Digite o primeiro número: ");
        int num1 = scanner.nextInt();
        System.out.print("Digite o segundo número: ");
        int num2 = scanner.nextInt();
        System.out.println("Números no intervalo [" + num1 + ", " + num2 + "]:");
        for (int i = num1; i <= num2; i++) {
            System.out.print(i + " ");
        }
        
        // QUESTAO 6
        System.out.println("\n\n6. Calcular média e contar alunos com média maior ou igual a 7:");
        int count = 0;
        double[] medias = new double[10];
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite as quatro notas do aluno " + (i + 1) + ": ");
            double mediaAluno = (scanner.nextDouble() + scanner.nextDouble() + scanner.nextDouble() + scanner.nextDouble()) / 4;
            medias[i] = mediaAluno;
            if (mediaAluno >= 7.0) {
                count++;
            }
        }
        System.out.println("Número de alunos com média maior ou igual a 7.0: " + count);
        
        // QUESTAO 7
        System.out.println("\n7. Soma, multiplicação e números de um vetor de 5 números inteiros:");
        int[] vetor = new int[5];
        int somaVetor = 0;
        int multiplicacao = 1;
        System.out.print("Digite os 5 números inteiros separados por espaços: ");
        for (int i = 0; i < 5; i++) {
            vetor[i] = scanner.nextInt();
            somaVetor += vetor[i];
            multiplicacao *= vetor[i];
        }
        System.out.println("Soma dos números: " + somaVetor);
        System.out.println("Multiplicação dos números: " + multiplicacao);
        System.out.print("Números do vetor: ");
        for (int i = 0; i < 5; i++) {
            System.out.print(vetor[i] + " ");
        }
        
        // QUESTAO 8
        System.out.println("\n\n8. Imprimir idade e altura na ordem inversa:");
        int[] idades = new int[5];
        double[] alturas = new double[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Digite a idade da pessoa " + (i + 1) + ": ");
            idades[i] = scanner.nextInt();
            System.out.print("Digite a altura da pessoa " + (i + 1) + " em metros: ");
            alturas[i] = scanner.nextDouble();
        }
        System.out.println("Idades e alturas na ordem inversa:");
        for (int i = 4; i >= 0; i--) {
            System.out.println("Idade: " + idades[i] + ", Altura: " + alturas[i]);
        }
        
        // QUESTAO 9
        System.out.println("\n9. Calcular soma dos quadrados dos elementos de um vetor:");
        int[] vetorA = new int[10];
        int somaQuadrados = 0;
        System.out.print("Digite os 10 números inteiros separados por espaços: ");
        for (int i = 0; i < 10; i++) {
            vetorA[i] = scanner.nextInt();
            somaQuadrados += vetorA[i] * vetorA[i];
        }
        System.out.println("A soma dos quadrados dos elementos do vetor é: " + somaQuadrados);
        
        // QUESTAO 10
        System.out.println("\n10. Gerar terceiro vetor intercalando elementos de dois vetores:");
        int[] vetorB = new int[10];
        int[] vetorC = new int[20];
        System.out.print("Digite os 10 elementos do primeiro vetor: ");
        for (int i = 0; i < 10; i++) {
            vetorA[i] = scanner.nextInt();
        }
        System.out.print("Digite os 10 elementos do segundo vetor: ");
        for (int i = 0; i < 10; i++) {
            vetorB[i] = scanner.nextInt();
        }
        for (int i = 0, j = 0, k = 0; i < 20; i++) {
            if (i % 2 == 0) {
                vetorC[i] = vetorA[j++];
            } else {
                vetorC[i] = vetorB[k++];
            }
        }
        System.out.print("O terceiro vetor intercalado é: ");
        for (int i = 0; i < 20; i++) {
            System.out.print(vetorC[i] + " ");
        }
        
        scanner.close();
    }
}