package exerc;
import java.util.Scanner;

public class VetorInteiro {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] vetor = new int[5];
		
		System.out.println("Digite os 5 numeros inteitos: ");
		for (int i = 0; i <5; i++) {
			System.out.println("Numero " + (i + 1) + ":" );
			vetor[i] = sc.nextInt();
		}
		int soma = 0;
		int multiplicacao = 1;
		
		System.out.println("Numeros digitados: ");
		for (int i = 0; i < 5; i++) {
			System.out.println(vetor[i] + " ");
			soma += vetor[i];
			multiplicacao *= vetor[i];
		}
		System.out.println("\nSoma dos numeros: " + soma);
		System.out.println("Multiplicacao dos numeros: " + multiplicacao);
		
		sc.close();
	}

}
