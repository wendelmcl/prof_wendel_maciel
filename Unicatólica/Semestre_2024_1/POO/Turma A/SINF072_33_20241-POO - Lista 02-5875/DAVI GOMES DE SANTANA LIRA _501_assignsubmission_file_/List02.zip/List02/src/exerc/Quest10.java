package exerc;
import java.util.Scanner;

public class Quest10 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int[] vetor1 = new int[10];
        int[] vetor2 = new int[10];
        int[] vetor3 = new int[20];
        
        System.out.println("Digite os elementos do primeiro vetor:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            vetor1[i] = sc.nextInt();
        }
        System.out.println("Digite os elementos do segundo vetor:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            vetor2[i] = sc.nextInt();
        }
        
        int j = 0;
        for (int i = 0; i < 10; i++) {
            vetor3[j++] = vetor1[i];
            vetor3[j++] = vetor2[i];
        }
        
        System.out.println("Vetor intercalado:");
        for (int i = 0; i < 20; i++) {
            System.out.print(vetor3[i] + " ");
        }
        
        sc.close();
	}
}
