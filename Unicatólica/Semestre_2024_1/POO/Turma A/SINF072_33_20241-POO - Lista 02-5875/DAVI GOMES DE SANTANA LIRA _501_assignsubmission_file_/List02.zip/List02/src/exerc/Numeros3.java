package exerc;
import java.util.Scanner;

public class Numeros3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite 5 numeros: ");
		double n1 = sc.nextDouble();
		double n2 = sc.nextDouble();
		double n3 = sc.nextDouble();
		double n4 = sc.nextDouble();
		double n5 = sc.nextDouble();
		
		double soma = n1 + n2 + n3 + n4 + n5;
		double media = soma / 5;
		
		System.out.println("A soma dos numeros: " + soma);
		System.out.println("A media dos numeros: " + media);
		
		sc.close();
	}
}
