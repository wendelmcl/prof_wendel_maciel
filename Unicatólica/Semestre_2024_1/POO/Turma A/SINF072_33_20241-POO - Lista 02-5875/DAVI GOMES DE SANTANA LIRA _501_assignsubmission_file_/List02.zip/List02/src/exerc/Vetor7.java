package exerc;
import java.util.Scanner;

public class Vetor7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int vetor[] = new int [5];
		int numeros = 0; int soma = 0; int multi = 0;
		
		
		System.out.println("Digite 5 numeros: ");
		for (int i = 0; i <= 4; i++) {
			numeros = sc.nextInt();
			vetor[i] = numeros;
		}
		for (int numero : vetor ) {
			soma += numero;
			multi *= numero;
		}
		
		System.out.println("Soma: " + soma);
		System.out.println("Multiplicacao: " + multi);
		
		
		
		sc.close();

	}

}
