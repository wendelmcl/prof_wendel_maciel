package exerc;
import java.util.Scanner;

public class Quest09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int vetor[] = new int[10];
		
		System.out.println("Digite 10 numeros inteiros: ");
		
		for (int i = 0; i < 10; i++) {
			System.out.println("Numero " + (i+1) + ":");
			vetor[i] = sc.nextInt();
		}
		int somaQ = 0;
		
		for (int i = 0; i < 10; i++) {
			somaQ += vetor[i] * vetor[i];
		}
		
		System.out.println("A soma dos quadrados dos elementos do vetor é: " + somaQ);
		sc.close();
	}
}
