package exerc;
import java.util.Scanner;

public class Numero2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite 5 numeros: ");
		double n1 = sc.nextDouble();
		double n2 = sc.nextDouble();
		double n3 = sc.nextDouble();
		double n4 = sc.nextDouble();
		double n5 = sc.nextDouble();
		
		double max = Math.max(n1, Math.max(n2, Math.max(n3, Math.max(n4, n5))));
		
		System.out.println("Maior numero: " + max);
		sc.close();
	}

}
