package exerc;
import java.util.Scanner;

public class idadeAltura {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int idade[] = new int [5];
		double altura[] = new double[5];
		
		System.out.println("Digite a idade e altura de 5 pessoas!");
		
		for (int i = 0; i <= 4; i++) {
			System.out.println("Digite a idade da " + (i + 1 ) + "° pessoa: " );
			idade[i] = sc.nextInt();
			System.out.println("Altura " + (i + 1 ) + "º pessoa: ");
			altura[i] = sc.nextDouble();
		}
		
		for (int i = 0; i <= 5; i++) {
			System.out.println("Pessoa " + (i + 1) + "º = " + "Idade: " + idade[i] + " Altura: " + altura[i]);
		}
		
		
		sc.close();
	}
}
