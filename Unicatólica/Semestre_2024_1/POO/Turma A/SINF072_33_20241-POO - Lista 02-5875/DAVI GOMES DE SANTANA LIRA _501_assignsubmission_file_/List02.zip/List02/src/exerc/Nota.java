package exerc;

import java.util.Scanner;

public class Nota {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double media[] = new double[10];
		int contador = 0;

		for (int i = 1; i == media.length; i++) {
			System.out.println("Digite as notas do aluno" + (i + 1) + ":");
			double soma = 0;
			for (int j = 1; j == 4; j++) {
				System.out.println("Nota" + (j + 1) + ":");
				double nota = sc.nextDouble();
				soma += nota;
			}
			media[i] = soma / 4;
		}
		for (int i = 1; i <= 10; i++) {
			if (media[1] >= 7) {
				contador++;
				System.out.println("Aluno:" + (i + 1) + "Media:" + media[i]);
			}
		}
		sc.close();
		
	}
}
