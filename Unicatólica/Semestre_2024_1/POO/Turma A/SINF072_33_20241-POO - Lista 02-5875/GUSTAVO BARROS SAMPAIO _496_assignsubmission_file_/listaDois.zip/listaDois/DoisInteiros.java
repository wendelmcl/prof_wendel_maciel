package listaDois;

import java.util.Scanner;

public class DoisInteiros {
	
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o primeiro número inteiro: ");
		int n1 = entrada.nextInt();
		
		System.out.println("Digite o segundo número inteiro: ");
		int n2 = entrada.nextInt();
		
		for(int n = n1; n <= n2; n ++) {
			System.out.println(n);
		}
		
		entrada.close();
	}

}
