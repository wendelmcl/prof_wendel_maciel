package listaDois;

import java.util.Scanner;

public class VetorIntercalado {

	public static void main(String[] args) {

		// Faça um Programa que leia dois vetores com 10 elementos cada. Gere um
		// terceiro
		// vetor de 20 elementos, cujos valores deverão ser compostos pelos elementos
		// intercalados dos dois outros vetores

		Scanner entrada = new Scanner(System.in);

		double[] a = new double[10];
		double[] b = new double[10];
		double[] c = new double[20];

		for (int i = 0; i < 10; i++) {
			System.out.println("Digite os números do vetor A: ");
			a[i] = entrada.nextDouble();
			System.out.println("Digite os valores do vetor B: ");
			b[i] = entrada.nextDouble();
		}
		for (int i = 0, j = 0; i < 10; i++) {
			c[j++] = a[i]; // Atribui um elemento de a
			c[j++] = b[i]; // Atribui um elemento de b
		}

		System.out.println("Vetor intercalado:");
		for (double elemento : c) {
			System.out.print(elemento + " ");
		}

		entrada.close();
	}

}
