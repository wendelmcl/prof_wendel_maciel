package listaDois;

public class SequenciaNumeros {

	public static void main(String[] args) {
		
		
		//Programa com quebra de linha
		System.out.println("-----------------------------"
				+ "\nPrograma com quebra de linha!");
		for(int contador =1; contador <= 20; contador ++) {
			System.out.println(contador);
		}
		
		
		//Programa sem quebra de linha
		System.out.println("-----------------------------"
				+ "\nPrograma sem quebra de linha!\n");
		for(int contador = 1; contador <= 20; contador ++) {
			System.out.print(contador + " ");
		
		}
		System.out.println("\n-----------------------------");

	}

}
