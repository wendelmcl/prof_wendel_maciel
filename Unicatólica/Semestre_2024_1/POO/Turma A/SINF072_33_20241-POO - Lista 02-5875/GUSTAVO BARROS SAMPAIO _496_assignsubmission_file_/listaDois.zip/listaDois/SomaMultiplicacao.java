package listaDois;

import java.util.Arrays;
import java.util.Scanner;

public class SomaMultiplicacao {

	public static void main(String[] args) {

		// Faça um Programa que leia um vetor de 5 números inteiros, mostre a soma, a
		// multiplicação e os números.

		Scanner entrada = new Scanner(System.in);

		int[] vetor = new int[5];

		for (int i = 0; i < 5; i++) {
			System.out.println("Digite um número inteiro: ");
			vetor[i] = entrada.nextInt();
		}

		System.out.println(Arrays.toString(vetor));

		entrada.close();
	}

}
