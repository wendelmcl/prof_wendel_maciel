package listaDois;

import java.util.Scanner;

public class SomaVetor {

	public static void main(String[] args) {

		// Faça um Programa que leia um vetor A com 10 números inteiros, calcule e
		// mostre a
		// soma dos quadrados dos elementos do vetor

		Scanner entrada = new Scanner(System.in);
		
	    double quadrado = 0;
		int soma = 0;

		int[] a = new int[10];

		for (int i = 0; i < 10; i++) {
			System.out.println("Digite um número: ");
			a[i] = entrada.nextInt();
			quadrado = Math.pow(a[i], 2);
			soma += quadrado;

		}
		
		System.out.println("A soma dos vetores ao quadrado é: " + soma);
		
		entrada.close();

	}

}
