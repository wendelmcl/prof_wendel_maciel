package listaDois;

import java.util.Scanner;

public class SomaEMedia {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		
		double soma = 0;
		
	
		for (int n = 1; n <= 5; n++) {
			System.out.println("Digite um número: ");
			int numero = entrada.nextInt();
			soma += numero;
		}
		
		
		double media = soma / 5;
		System.out.println("A soma dos números é: " + soma);
		System.out.println("A média dos números é : " + media);
		
		entrada.close();
	}

}
