package listaDois;

import java.util.Scanner;

public class MaiorNumero {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		int maiorN = 0;

		for (int teste = 1; teste <= 5; teste++) {
			System.out.println("Digite um número");
			int numero = entrada.nextInt();

			if (numero > maiorN) {
				maiorN = numero;
			}
		}

		System.out.println("O maior número é: " + maiorN);
		entrada.close();
	}

}
