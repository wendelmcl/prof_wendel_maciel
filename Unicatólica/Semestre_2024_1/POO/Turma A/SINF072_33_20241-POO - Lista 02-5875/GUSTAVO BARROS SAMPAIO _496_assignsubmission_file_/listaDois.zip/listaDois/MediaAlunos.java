package listaDois;

import java.util.Scanner;

public class MediaAlunos {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		double[] aprovados = new double[10];

		double soma = 0;
		double media = 0;

		for (int n = 0; n < 10; n++) {
			for (double i = 0; i < 4; i++) {
				System.out.println("Digite as notas do aluno: " + (n + 1));
				double nota = entrada.nextDouble();

				soma += nota;
				media = soma / 4;

			}

			if (media >= 7) {
				aprovados[n] = media;
			}
			System.out.println("A soma das notas do aluno " + (n + 1) + " foi " + soma);
			System.out.println("A media foi: " + media);
			soma = 0;
			media = 0;
		}

		int contadorAprovados = 0;
		for (int i = 0; i < aprovados.length; i++) {
			if (aprovados[i] != 0) {
				contadorAprovados += 1;
			}

		}

		System.out.println("O número de alunos aprovados foi: " + contadorAprovados);

		entrada.close();
	}

}
