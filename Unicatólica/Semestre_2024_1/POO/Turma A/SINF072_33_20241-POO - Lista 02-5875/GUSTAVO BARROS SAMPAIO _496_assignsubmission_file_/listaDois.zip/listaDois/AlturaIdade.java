package listaDois;

import java.util.Scanner;

public class AlturaIdade {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		// Faça um Programa que peça a idade e a altura de 5 pessoas, armazene cada
		// informação no seu respectivo vetor. Imprima a idade e a altura na ordem
		// inversa a
		// ordem lida.

		int[] idade = new int[5];
		double[] altura = new double[5];

		for (int i = 0; i < 5; i++) {

			System.out.println("Digite a idade da pessoa " + (i + 1));
			idade[i] = entrada.nextInt();
			System.out.println("Digite a altura da pessoa" + (i + 1));
			altura[i] = entrada.nextDouble();

		}

		System.out.println("As idades na ordem inversa ficam: ");
		for (int i = idade.length - 1; i >= 0; i--) {

			System.out.print(idade[i] + " ");
		}
		System.out.println("");
		System.out.println("As alturas na ordem inversa ficam: ");

		for (int i = altura.length - 1; i >= 0; i--) {
			System.out.print(altura[i] + " ");
		}

		entrada.close();

	}

}
