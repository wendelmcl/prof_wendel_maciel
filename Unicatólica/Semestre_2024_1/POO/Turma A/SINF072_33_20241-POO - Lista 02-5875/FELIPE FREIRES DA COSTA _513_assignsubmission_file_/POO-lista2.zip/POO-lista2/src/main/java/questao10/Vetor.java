
package questao10;

import java.util.Scanner;

public class Vetor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        int[] vetorA = new int[10];
        int[] vetorB = new int[10];


        System.out.println("Digite os elementos do vetor A (10 elementos):");
        for (int i = 0; i < 10; i++) {
            vetorA[i] = scanner.nextInt();
        }

        System.out.println("Digite os elementos do vetor B (10 elementos):");
        for (int i = 0; i < 10; i++) {
            vetorB[i] = scanner.nextInt();
        }

 
        int[] vetorC = new int[20];

        for (int i = 0, j = 0; i < 20; i += 2, j++) {
            vetorC[i] = vetorA[j];
            vetorC[i + 1] = vetorB[j];
        }

        System.out.println("Vetor C intercalado:");
        for (int i = 0; i < 20; i++) {
            System.out.print(vetorC[i] + " ");
        }
    }
}
