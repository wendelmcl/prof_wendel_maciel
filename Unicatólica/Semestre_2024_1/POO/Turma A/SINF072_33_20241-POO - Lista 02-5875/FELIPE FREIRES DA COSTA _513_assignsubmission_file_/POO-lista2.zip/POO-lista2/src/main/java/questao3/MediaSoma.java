
package questao3;

import java.util.Scanner;


public class MediaSoma {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
    int num1, num2, num3, num4, num5;
    
    System.out.println("Digite 5 numeros: ");
    num1 = sc.nextInt();
    num2 = sc.nextInt();
    num3 = sc.nextInt();
    num4 = sc.nextInt();
    num5 = sc.nextInt();
    
    int soma = num1 + num2 + num3 + num4 + num5;
    
    double media = soma / 5;
    
        System.out.println("A soma dos numeros foi: " + soma + " e a media foi : " + media);
    }
    
            
}
