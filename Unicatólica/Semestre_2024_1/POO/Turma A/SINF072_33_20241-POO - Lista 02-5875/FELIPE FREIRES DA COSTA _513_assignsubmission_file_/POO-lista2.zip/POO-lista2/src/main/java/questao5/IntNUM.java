
package questao5;

import java.util.Scanner;

public class IntNUM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Digite o primeiro número:");
        int numero1 = scanner.nextInt();

        System.out.println("Digite o segundo número:");
        int numero2 = scanner.nextInt();

        
        if (numero1 > numero2) {
            int temp = numero1;
            numero1 = numero2;
            numero2 = temp;
        }

        
        System.out.println("Números no intervalo [" + numero1 + ", " + numero2 + "]:");
        for (int i = numero1; i <= numero2; i++) {
            System.out.println(i);
        }
    }
}
