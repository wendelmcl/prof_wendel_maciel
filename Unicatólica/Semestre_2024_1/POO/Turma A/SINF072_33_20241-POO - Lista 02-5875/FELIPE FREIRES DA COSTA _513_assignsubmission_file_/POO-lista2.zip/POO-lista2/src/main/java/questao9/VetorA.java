
package questao9;

import java.util.Scanner;

public class VetorA {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] vetorA = new int[10];

        System.out.println("Digite 10 números inteiros:");

        for (int i = 0; i < 10; i++) {
            vetorA[i] = scanner.nextInt();
        }

        int somaQuadrados = 0;
        for (int i = 0; i < 10; i++) {
            somaQuadrados += vetorA[i] * vetorA[i];
        }

        System.out.println("A soma dos quadrados dos elementos do vetor é: " + somaQuadrados);
    }
    

}
