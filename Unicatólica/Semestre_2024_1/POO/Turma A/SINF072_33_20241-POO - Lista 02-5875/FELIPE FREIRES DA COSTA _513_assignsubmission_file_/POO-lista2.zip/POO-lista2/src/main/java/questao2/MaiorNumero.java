
package questao2;

import java.util.Scanner;


public class MaiorNumero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        
        
        System.out.println("Digite 5 numeros: ");
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        int num3 = sc.nextInt();
        int num4 = sc.nextInt();
        int num5 = sc.nextInt();
        
        if(num1 > num2 && num1 > num3 && num1 > num4 && num1 > num5){
            System.out.println("o maior numero é: " + num1);
        }else if(num2 > num1 && num2 > num3 && num2 > num4 && num2 > num5){
            System.out.println("O maior numero é: "+ num2);
        }else if(num3 > num2 && num3 > num1 && num3 > num4 && num3 > num5){
            System.out.println("O maior numero é: " + num3);
        }else if (num4 > num2 && num4 > num3 && num4 > num1 && num4 > num5){
            System.out.println("O maior numero é: " + num4); 
        }else if (num5 > num2 && num5 > num3 && num5 > num4 && num5 > num1){
            System.out.println("O maior numero é: " + num5);
        }else{
            
        }
    }
}
