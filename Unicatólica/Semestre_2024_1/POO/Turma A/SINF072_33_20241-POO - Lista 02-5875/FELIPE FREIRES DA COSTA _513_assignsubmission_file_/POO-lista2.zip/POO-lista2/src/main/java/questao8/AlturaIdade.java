
package questao8;

import java.util.Scanner;


public class AlturaIdade {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        int[] idades = new int[5];
        double[] alturas = new double[5];

       
        for (int i = 0; i < 5; i++) {
            System.out.println("Digite a idade da pessoa " + (i + 1) + ":");
            idades[i] = scanner.nextInt();
            System.out.println("Digite a altura da pessoa " + (i + 1) + ":");
            alturas[i] = scanner.nextDouble();
        }

        System.out.println("Idades e alturas na ordem inversa:");
        for (int i = 4; i >= 0; i--) {
            System.out.println("Pessoa " + (5 - i) + ": Idade = " + idades[i] + ", Altura = " + alturas[i]);
        }

    }
}
