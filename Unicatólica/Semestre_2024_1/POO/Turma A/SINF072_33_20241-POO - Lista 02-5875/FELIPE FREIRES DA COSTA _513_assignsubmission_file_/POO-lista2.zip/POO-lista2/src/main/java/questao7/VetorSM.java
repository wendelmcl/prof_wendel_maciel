
package questao7;

import java.util.Scanner;

/**
 *
 * @author Felipe
 */
public class VetorSM {
    public static void main(String[] args) {
        int[] numeros = new int[5];
        Scanner sc = new Scanner(System.in);


        System.out.println("Digite 5 números inteiros:");

        for (int i = 0; i < 5; i++) {
            numeros[i] = sc.nextInt();
        }

        int soma = 0;
        int multiplicacao = 1;

        for (int i = 0; i < 5; i++) {
            soma += numeros[i];
            multiplicacao *= numeros[i];
        }

        System.out.println("Números inseridos:");
        for (int i = 0; i < 5; i++) {
            System.out.println(numeros[i]);
        }

        System.out.println("Soma: " + soma);
        System.out.println("Multiplicação: " + multiplicacao);
    }
}
