
package questao4;


public class Impares {
    public static void main(String[] args) {
            for(int i = 1; i <= 50; i += 2){
                System.out.println( i + " ");
        } 
    }
    
}
