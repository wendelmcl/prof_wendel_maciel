package pt06;

import java.util.Scanner;

public class pt06 {

	public static void main(String[] args) {
		double n1, n2, n3, n4, media;
		Scanner sc = new Scanner(System.in);
		double[] Nota = new double [10];
		for (int i=1; i<=3; i++) {
			System.out.println("Aluno "+ i);
			System.out.print("Nota N1 : ");
			n1 = sc.nextDouble();
			
			System.out.print("Nota N2 : ");
			n2 = sc.nextDouble();
			
			System.out.print("Nota N3 : ");
			n3 = sc.nextDouble();
			
			System.out.print("Nota N4 : ");
			n4 = sc.nextDouble();
			
			media = (n1 + n2 + n3 + n4) / 4;
			Nota[i] = media;
		}
		
		for (int i = 1; i<=3; i++) {
			System.out.println("\nMedia do aluno " + i);
			System.out.println("[ "+ Nota[i] + " ]");
		}
		
		sc.close();
		

	}

}
