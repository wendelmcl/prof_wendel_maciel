package pt02;

import java.util.Scanner;

public class pt02 {

	public static void main(String[] args) {
		int n1, n2, n3, n4, n5;
		int maior = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Primeiro Número : ");
		n1 = sc.nextInt();
		if (n1 >= maior) {
			maior = n1;
		}
		
	    System.out.println("Segundo Número : ");
	    n2 = sc.nextInt();
	    if (n2 >= maior) {
			maior = n2;
		}
	    
	    System.out.println("Terceiro Número : ");
	    n3 = sc.nextInt();
	    if (n3 >= maior) {
			maior = n3;
		}
	    
	    System.out.println("Quarto Número : ");
	    n4 = sc.nextInt();
	    if (n4 >= maior) {
			maior = n4;
		}
	    
	    System.out.println("Quinto Número : ");
	    n5 = sc.nextInt();
	    if (n5 >= maior) {
			maior = n5;
		}
	    
	    System.out.println("Maior número : " + maior);
	    
	    sc.close();
	}

}

