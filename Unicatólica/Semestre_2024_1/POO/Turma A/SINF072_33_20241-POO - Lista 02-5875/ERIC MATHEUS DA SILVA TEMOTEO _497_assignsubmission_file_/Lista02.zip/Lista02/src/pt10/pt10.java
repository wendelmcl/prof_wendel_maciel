package pt10;

import java.util.Scanner;

public class pt10 {

	public static void main(String[] args) {
		int A [] = new int [10];
		int B [] = new int [10];
		int C [] = new int [20];
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite os números do vetor A:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Vetor A[" + i + "]: ");
            A[i] = sc.nextInt();
        }
        System.out.println("Digite os números do vetor B:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Vetor B[" + i + "]: ");
            B[i] = sc.nextInt();
        }
        int posC = 0;
        for (int i=0; i<10; i++) {
        	C[posC] = A[i];
        	posC++;
        	C[posC] = B[i];
        	posC++;
        }
        
        for (int i=0; i<20; i++) {
        	System.out.print(C[i]+" ");
        }
		sc.close();
	}

}
