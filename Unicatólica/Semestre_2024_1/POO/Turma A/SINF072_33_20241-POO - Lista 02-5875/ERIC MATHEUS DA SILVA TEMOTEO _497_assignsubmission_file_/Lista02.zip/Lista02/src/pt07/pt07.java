package pt07;

import java.util.Scanner;

public class pt07 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int[] vetor = new int[5];
		int soma = 0;
		int mult = 1;
		
		for(int i = 0; i <5; i++) {
			System.out.println("Insira um número ("+ (i+1)+"/5) : ");
			vetor[i] = sc.nextInt();
			soma += vetor[i];
			mult *= vetor[i];
		}
		
		for (int i = 0; i < 5; i++) {
			System.out.print(vetor[i]+", ");
		}
		System.out.println("Soma : " + soma + "\nMultiplicação : " + mult);
		
		sc.close();
	
	}

}

