package questao_5;

import java.util.Scanner;

public class N1entreN2 {

	public static void main(String[] args) {
		int n1, n2;
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o primeiro número : ");
		n1 = sc.nextInt();
		System.out.println("Digite o segundo número : ");
		n2 = sc.nextInt();
		System.out.println("Números entre "+ n1 + " e " + n2+ ": ");
		for (int i = n1+1; i <= n2 -1; i++) {
			System.out.println(i);
		}
		sc.close();
	}

}
