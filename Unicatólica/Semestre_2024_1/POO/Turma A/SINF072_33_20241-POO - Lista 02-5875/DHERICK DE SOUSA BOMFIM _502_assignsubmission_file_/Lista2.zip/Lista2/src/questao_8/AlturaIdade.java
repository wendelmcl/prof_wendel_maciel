package questao_8;

import java.util.Scanner;

public class AlturaIdade {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int[] idade = new int [n];
		float[] altura = new float [n];
		
		for (int i = 0; i < n; i++) {
			System.out.println((i+1) + "º Pessoa");
			System.out.print("Idade : ");
			idade[i] = sc.nextInt();
			System.out.print("Altura : ");
			altura[i] = sc.nextFloat();
		}
		
		System.out.print("\n");
		for (int i = idade.length - 1; i>=0; i--) {
			System.out.println("\n" + (i+1) + "º Pessoa :");
			System.out.printf("[ Idade: %d | Altura: %.2f ]%n", idade[i], altura[i]);
			}
		
		sc.close();
	}
}
