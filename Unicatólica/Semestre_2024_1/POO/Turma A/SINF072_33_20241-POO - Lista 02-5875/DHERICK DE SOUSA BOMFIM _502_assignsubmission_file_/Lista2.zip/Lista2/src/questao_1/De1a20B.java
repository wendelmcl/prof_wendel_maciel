package questao_1;

public class De1a20B {

	public static void main(String[] args) {
		for (int i = 1; i <= 20; i++) {
			System.out.print(i + ", ");
		}
	}
}
