package questao_9;

import java.util.Scanner;

public class VetorAoQuadrado {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] vetor = new int [10];
		int somaQuad = 0;
		
		for (int i = 0; i<vetor.length; i++) {
			System.out.print((i+1) +"º Número : ");
			vetor[i] = sc.nextInt();
		}

		for (int i=0; i<vetor.length; i++) {
			somaQuad += vetor[i] * vetor[i];
		}
		System.out.println("\nSoma dos quadrados : " + somaQuad);
		sc.close();
	}

}
