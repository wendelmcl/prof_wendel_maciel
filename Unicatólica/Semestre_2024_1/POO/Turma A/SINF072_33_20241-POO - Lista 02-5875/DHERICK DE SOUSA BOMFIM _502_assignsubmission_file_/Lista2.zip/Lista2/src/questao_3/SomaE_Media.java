package questao_3;

import java.util.Scanner;

public class SomaE_Media {

	public static void main(String[] args) {
		int n1, n2, n3, n4, n5;
		int soma = 0;
		float media = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Primeiro Número : ");
		n1 = sc.nextInt();
		
	    System.out.println("Segundo Número : ");
	    n2 = sc.nextInt();
	    
	    System.out.println("Terceiro Número : ");
	    n3 = sc.nextInt();
	    
	    System.out.println("Quarto Número : ");
	    n4 = sc.nextInt();
	    
	    System.out.println("Quinto Número : ");
	    n5 = sc.nextInt();

	    soma = n1 + n2 + n3 + n4 + n5;
	    media =(n1 + n2 + n3 + n4 + n5) / 5;
	    
	    System.out.println("Soma dos números : " + soma);
	    System.out.println("\nMedia : " + media);
	    
	    sc.close();
	}

}
