package quest�o2;

public class Carro implements Veiculo {
	public void acelerar() {
        System.out.println("Carro acelerando...");
    }
    public void frear() {
        System.out.println("Carro freando...");
    }
    public void fazerBarulho() {
        System.out.println("Vrummm! (barulho do carro)");
}}

