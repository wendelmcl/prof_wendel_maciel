package primeiraquest�o;

public class dinheiro extends FormaPagamento1 {
	private int quantia;
	private int numeroserie;
	private int numero;
	public int getQuantia() {
		return quantia;
	}
	public void setQuantia(int quantia) {
		this.quantia = quantia;
	}
	public int getNumeroserie() {
		return numeroserie;
	}
	public void setNumeroserie(int numeroserie) {
		this.numeroserie = numeroserie;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	

}
