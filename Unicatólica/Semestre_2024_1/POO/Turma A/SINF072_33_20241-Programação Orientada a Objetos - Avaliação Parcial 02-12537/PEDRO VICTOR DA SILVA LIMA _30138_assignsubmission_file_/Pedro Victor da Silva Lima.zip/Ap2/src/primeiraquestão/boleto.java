package primeiraquest�o;

public class boleto extends FormaPagamento1 {
	private int total;
	private int quantia;
	private int datadevencimento;
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getQuantia() {
		return quantia;
	}
	public void setQuantia(int quantia) {
		this.quantia = quantia;
	}
	public int getDatadevencimento() {
		return datadevencimento;
	}
	public void setDatadevencimento(int datadevencimento) {
		this.datadevencimento = datadevencimento;
	}
	
	

}
