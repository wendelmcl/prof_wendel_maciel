package Item02;

public interface Veiculo {
    void acelerar();
    void frear();
    void fazerBarulho();
}
