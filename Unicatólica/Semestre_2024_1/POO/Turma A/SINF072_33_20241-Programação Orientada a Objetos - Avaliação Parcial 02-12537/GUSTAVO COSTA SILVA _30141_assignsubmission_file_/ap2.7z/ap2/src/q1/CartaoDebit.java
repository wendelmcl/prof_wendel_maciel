package q1;

public class CartaoDebit extends FormaPagamento {
    String numCart = "098742312";
    int CVV = 970;
    String dataDeVencimento = "25/06/2065";
    int saldo = 1000;


}
