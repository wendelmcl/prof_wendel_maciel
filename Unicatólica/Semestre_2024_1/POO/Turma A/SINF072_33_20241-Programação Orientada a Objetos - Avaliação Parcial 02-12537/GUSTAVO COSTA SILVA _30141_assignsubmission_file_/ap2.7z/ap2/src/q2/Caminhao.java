package q2;

public class Caminhao implements Veiculo {
    @Override
    public String acelerar() {
        return " brum brummm";
    }

    @Override
    public String frear() {
        return " tchuuuu";
    }

    @Override
    public String fazerBbarulho() {
        return " bruuuu bruuu";
    }

}
