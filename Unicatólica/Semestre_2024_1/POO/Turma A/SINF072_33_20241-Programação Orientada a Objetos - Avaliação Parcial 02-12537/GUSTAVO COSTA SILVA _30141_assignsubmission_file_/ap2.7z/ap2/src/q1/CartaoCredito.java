package q1;

public class CartaoCredito extends FormaPagamento {
    String numCart = "0981234";
    int CVV = 8701;
    String dataDeVencimento = "12/04/2050";




}
