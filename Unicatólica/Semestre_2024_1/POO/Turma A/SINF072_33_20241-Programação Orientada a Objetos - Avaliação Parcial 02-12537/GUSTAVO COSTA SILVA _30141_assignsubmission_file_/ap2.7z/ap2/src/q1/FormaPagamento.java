package q1;

public abstract class FormaPagamento {
    String CartaCredito;
    String CartaoDebito;
    String Boleto;
    String Dinheiro;
    int valor = 100;
    int saldo = 1000;

}
