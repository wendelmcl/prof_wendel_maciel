package q1;

public class Boleto extends FormaPagamento {
    String diasParaCompensar = "Seu boleto ira compensar em 4 dias uteis";
}
