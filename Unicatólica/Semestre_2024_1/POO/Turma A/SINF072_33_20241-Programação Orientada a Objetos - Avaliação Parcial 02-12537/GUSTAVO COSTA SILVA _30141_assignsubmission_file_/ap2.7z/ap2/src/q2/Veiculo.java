package q2;

public interface Veiculo {
    String acelerar ();
    String frear ();
    String fazerBbarulho();



}
