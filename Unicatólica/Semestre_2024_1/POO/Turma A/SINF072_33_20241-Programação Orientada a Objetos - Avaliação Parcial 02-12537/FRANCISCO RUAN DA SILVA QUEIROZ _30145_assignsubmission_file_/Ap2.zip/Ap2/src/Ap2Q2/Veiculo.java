package Ap2Q2;

interface Veiculo {
    void acelerar();
    void frear();
    void fazerBarulho();
}








