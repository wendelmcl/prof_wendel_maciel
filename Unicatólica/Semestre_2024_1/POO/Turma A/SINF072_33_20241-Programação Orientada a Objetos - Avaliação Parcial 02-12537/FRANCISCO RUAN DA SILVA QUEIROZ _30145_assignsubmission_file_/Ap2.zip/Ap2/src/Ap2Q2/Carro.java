package Ap2Q2;


class Carro implements Veiculo {
    
    public void acelerar() {
        System.out.println("Carro acelerando!");
    }

    
    public void frear() {
        System.out.println("Carro freando!");
    }

    
    public void fazerBarulho() {
        System.out.println("Barulho do carro: Pom Pom!");
    }
}

