package Ap2Q2;

class Caminhao implements Veiculo {
    
    public void acelerar() {
        System.out.println("Caminh�o acelerando!");
    }

    
    public void frear() {
        System.out.println("Caminh�o freando!");
    }

    
    public void fazerBarulho() {
        System.out.println("Barulho do caminh�o: FROM FROM!");
    }
}