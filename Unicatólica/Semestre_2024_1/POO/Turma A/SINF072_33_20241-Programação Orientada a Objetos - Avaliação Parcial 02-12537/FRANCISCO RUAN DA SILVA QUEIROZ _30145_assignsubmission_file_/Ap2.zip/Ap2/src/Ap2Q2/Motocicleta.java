package Ap2Q2;

class Motocicleta implements Veiculo {
    
    public void acelerar() {
        System.out.println("Motocicleta acelerando!");
    }

    
    public void frear() {
        System.out.println("Motocicleta freando!");
    }

    
    public void fazerBarulho() {
        System.out.println("Barulho da motocicleta: Pibiti!!!");
    }
}