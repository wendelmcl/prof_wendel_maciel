package Questao02;

public interface Veiculo {
    String modelo = "";

    public void Acelerar();

    public void Frear();

    public void FazerBarulho();

}
