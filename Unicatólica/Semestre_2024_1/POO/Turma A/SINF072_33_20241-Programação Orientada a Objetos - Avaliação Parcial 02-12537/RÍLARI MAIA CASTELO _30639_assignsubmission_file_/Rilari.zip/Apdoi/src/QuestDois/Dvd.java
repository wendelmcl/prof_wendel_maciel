package QuestDois;

public class Dvd extends Itembiblioteca {
	String emprestar;
	String devolver;
	boolean gravar;
	
	public void gravarDvd(){
		
	}
}

