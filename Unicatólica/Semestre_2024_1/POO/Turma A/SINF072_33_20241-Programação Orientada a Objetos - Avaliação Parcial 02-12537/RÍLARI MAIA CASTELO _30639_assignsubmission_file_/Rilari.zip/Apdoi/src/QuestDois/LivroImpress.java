package QuestDois;

public class LivroImpress {
public void emprestarintem(){
	System.out.println("Livro emprestado");
}
}
