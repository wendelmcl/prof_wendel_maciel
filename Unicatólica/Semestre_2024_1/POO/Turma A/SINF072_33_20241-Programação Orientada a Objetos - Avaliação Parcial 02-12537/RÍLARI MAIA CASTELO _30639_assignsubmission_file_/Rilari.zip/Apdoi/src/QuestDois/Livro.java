package QuestDois;

public class Livro extends Itembiblioteca {
String emprestar;
String devolver;
boolean verifica;

public void Consultardisponibilidade(){
	System.out.println("");

}

}
