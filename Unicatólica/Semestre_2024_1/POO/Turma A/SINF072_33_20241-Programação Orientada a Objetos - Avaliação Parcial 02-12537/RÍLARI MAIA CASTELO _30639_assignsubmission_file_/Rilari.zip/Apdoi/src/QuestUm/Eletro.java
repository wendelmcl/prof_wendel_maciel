package QuestUm;

import javax.net.ssl.SSLEngineResult.Status;

public class Eletro {
public static void main(String args[]){
Geladeira Geladeira = new Geladeira();
Geladeira.marca = ("Ally");
Geladeira.modelo = ("Sc247");
Geladeira.preco = (1.924);
Geladeira.garantia("2  anos");
Geladeira.status();
 
Tv Tv = new Tv();
Tv.marca = ("Electro");
Tv.modelo = ("SmV1");
Tv.preco = (2.247);
Tv.garantia("2  anos");
Tv.Status();

    } 
  }

