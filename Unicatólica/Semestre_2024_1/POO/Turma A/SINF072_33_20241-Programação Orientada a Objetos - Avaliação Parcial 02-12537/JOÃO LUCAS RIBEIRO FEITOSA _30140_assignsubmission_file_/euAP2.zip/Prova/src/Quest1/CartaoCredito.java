package Quest1;

public class CartaoCredito {
	private int numeroDoCartao;
	private int codigo;
	private int data;
	

	public int getNumeroDoCartao() {
		return numeroDoCartao;
	}
	public void setNumeroDoCartao(int numeroDoCartao) {
		this.numeroDoCartao = numeroDoCartao;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	
	@Override
	

}
