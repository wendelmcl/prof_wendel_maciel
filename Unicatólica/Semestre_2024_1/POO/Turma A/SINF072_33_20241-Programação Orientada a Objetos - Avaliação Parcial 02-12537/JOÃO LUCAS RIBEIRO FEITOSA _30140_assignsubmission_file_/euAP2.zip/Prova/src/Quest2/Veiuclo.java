package Quest2;

public interface Veiuclo {
	public void acelerar();
	
	
	
	
	public void frear();
	

}
