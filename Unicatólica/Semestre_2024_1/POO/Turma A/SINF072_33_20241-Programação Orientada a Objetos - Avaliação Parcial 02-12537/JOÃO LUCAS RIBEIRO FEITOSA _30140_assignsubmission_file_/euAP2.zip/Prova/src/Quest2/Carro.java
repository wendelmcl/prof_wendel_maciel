package Quest2;

public class Carro {

}
