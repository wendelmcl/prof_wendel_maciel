package Quest2;

public class motoCicleta {

}
