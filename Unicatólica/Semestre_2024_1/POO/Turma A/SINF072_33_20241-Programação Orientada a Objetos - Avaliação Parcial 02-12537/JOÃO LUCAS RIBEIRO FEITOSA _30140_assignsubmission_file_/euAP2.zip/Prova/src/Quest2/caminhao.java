package Quest2;

public class caminhao {

}
