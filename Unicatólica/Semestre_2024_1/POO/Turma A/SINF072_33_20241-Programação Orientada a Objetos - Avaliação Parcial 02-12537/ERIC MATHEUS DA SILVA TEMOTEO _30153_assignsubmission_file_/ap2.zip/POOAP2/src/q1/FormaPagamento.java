package q1;

public  class FormaPagamento {
	private String cartaoCredito;
	private String cartaoDebito;
	private String boleto;
	private String dinheiro;
	
	
	public void cartaoCredito() {
		
	}
	public void cartaoDebito() {
		
	}
	public void boleto() {
	
}
	public void dinheiro() {
	
}
	public void valor() {
		
	}
	public String getCartaoCredito() {
		return cartaoCredito;
	}
	public void setCartaoCredito(String cartaoCredito) {
		this.cartaoCredito = cartaoCredito;
	}
	public String getCartaoDebito() {
		return cartaoDebito;
	}
	public void setCartaoDebito(String cartaoDebito) {
		this.cartaoDebito = cartaoDebito;
	}
	public String getBoleto() {
		return boleto;
	}
	public void setBoleto(String boleto) {
		this.boleto = boleto;
	}
	public String getDinheiro() {
		return dinheiro;
	}
	public void setDinheiro(String dinheiro) {
		this.dinheiro = dinheiro;
	}
}
