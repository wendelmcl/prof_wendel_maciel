package q2;

public interface Veiculos {
	public void acelerar();
	public void frear();
	public void fazerbarulho();
	
}
