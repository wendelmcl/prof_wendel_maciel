package q2;

import java.util.ArrayList;

public abstract class Carro implements Veiculos {
	ArrayList<String> Veiculo = new ArrayList<>();
}
