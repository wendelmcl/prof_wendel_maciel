package q2;

public class Caminh�o {

}
