package q2;
import java.util.ArrayList;
public class Exe {
	ArrayList<Integer> Nomes = new ArrayList<>();
}
