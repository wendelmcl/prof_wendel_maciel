package q1;
import java.util.ArrayList;

public class Dinheiro extends FormaPagamento {
	ArrayList<String> Nomes = new ArrayList<>();
	int numCartao;
	int numSeguranca;
	String vencimento;

}
