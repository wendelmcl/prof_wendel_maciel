package questao;

abstract public class FormaPagamento {
	
	
	abstract String CartaoCredito();
	abstract String CartaoDebito();
	abstract String Boleto();
	abstract String Dinheiro();
	
	


}
