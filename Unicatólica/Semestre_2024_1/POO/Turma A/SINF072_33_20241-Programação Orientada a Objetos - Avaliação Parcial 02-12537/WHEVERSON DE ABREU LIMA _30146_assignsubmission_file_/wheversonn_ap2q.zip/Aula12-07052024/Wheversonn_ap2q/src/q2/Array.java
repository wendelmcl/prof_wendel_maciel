package q2;

import java.util.ArrayList;

public class Array {

	private ArrayList<Veiculo> veiculos;
	public Array() {
	    this.veiculos = new ArrayList<>();
	}
	
	
	
}
