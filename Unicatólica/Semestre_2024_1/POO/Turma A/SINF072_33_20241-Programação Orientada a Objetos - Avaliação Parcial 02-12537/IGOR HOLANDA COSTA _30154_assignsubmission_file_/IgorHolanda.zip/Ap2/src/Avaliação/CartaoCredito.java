package Avalia��o;

public class CartaoCredito extends FormaPagamento {
	private int numeroC;

	public int getNumeroC() {
		return numeroC;
	}

	public void setNumeroC(int numeroC) {
		this.numeroC = numeroC;
	}
	

}
