package Avalia��o;

public class Boleto extends FormaPagamento{
	private boolean dataVencimento;

	public boolean isDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(boolean dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
	

}
