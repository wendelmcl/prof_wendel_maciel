package Avalia��o;

public class CartaoDebito extends FormaPagamento {
	private String codigoS;

	public String getCodigoS() {
		return codigoS;
	}

	public void setCodigoS(String codigoS) {
		this.codigoS = codigoS;
	}
	

}
