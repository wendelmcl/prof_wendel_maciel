package Avalia��o;

public class Dinheiro extends FormaPagamento {
	private String rasgada;

	public String getRasgada() {
		return rasgada;
	}

	public void setRasgada(String rasgada) {
		this.rasgada = rasgada;
	}
	
	

}
