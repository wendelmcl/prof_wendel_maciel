package Avalia��o2;

public interface Veiculo {
	public void acelerar();
	public void frear();
	public void fazerBarulho();

}
