package Automoveis;

public interface Veiculos {
	public static void main(String[] args) {
		String acelerar;
		String Frear;
		Double FazerBarulho;
		
	}
}
