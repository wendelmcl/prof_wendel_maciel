package Quest�es;

public class Dinheiro {
public static void main(String[] args) {
System.out.println("Digite o Quanto deseja pagar ");
}
}
