package Automoveis;

public class  Motocicleta  {
	String acelerar;
	String Frear;
	Double FazerBarulho;
	public String getAcelerar() {
		return acelerar;
	}
	public void setAcelerar(String acelerar) {
		this.acelerar = acelerar;
	}
	public String getFrear() {
		return Frear;
	}
	public void setFrear(String frear) {
		Frear = frear;
	}
	public Double getFazerBarulho() {
		return FazerBarulho;
	}
	public void setFazerBarulho(Double fazerBarulho) {
		FazerBarulho = fazerBarulho;
	}
	
}
