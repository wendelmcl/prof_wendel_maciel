package Automoveis;

public class Carro {
	String motor;
	String vidro;
	Double porta;
	public String getMotor() {
		return motor;
	}
	public void setMotor(String motor) {
		this.motor = motor;
	}
	public String getVidro() {
		return vidro;
	}
	public void setVidro(String vidro) {
		this.vidro = vidro;
	}
	public Double getPorta() {
		return porta;
	}
	public void setPorta(Double porta) {
		this.porta = porta;
	}
	

}
