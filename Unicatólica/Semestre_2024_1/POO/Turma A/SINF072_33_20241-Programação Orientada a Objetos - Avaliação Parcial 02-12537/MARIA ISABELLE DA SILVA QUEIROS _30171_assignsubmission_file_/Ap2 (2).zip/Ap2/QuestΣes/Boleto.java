package Quest�es;

public class Boleto {
	public static void main(String[] args) {
		System.out.println("Digite o n�mero do boleto");
		System.out.println("Digite o c�digo do boleto");
	}

}
