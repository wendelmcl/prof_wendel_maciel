package Quest�es;

public class  CartaoCredito {
public static void main(String[] args) {
	System.out.println("Digite o n�mero do cart�o");
	System.out.println("Digite o c�digo de seguran�a");
	System.out.println("data de vencimento");
}
	

}
