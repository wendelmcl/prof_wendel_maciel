package Automoveis;

public class Caminh�o {
	public static void main(String[] args) {
		String Marca;
		String Pneu;
		Double Carga;
		
	}

}
