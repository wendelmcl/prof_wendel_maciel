package q1;

public abstract class FormadePagamento {
	
	public abstract void CartaoCredito();
	public abstract void CartaoDebito();
	public abstract void Boleto();
	public abstract void Dinheiro();
}
