package questao1;

public class CartaoCredito  extends FormaPagamento{
	
	private int numeroCartao;
	private int codigoseguranca;
	private String dataVencimento;
	
	public void detalhes(){
		
		
	}

	public int getNumeroCartao() {
		return numeroCartao;
	}

	public void setNumeroCartao(int numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	public int getCodigoseguranca() {
		return codigoseguranca;
	}

	public void setCodigoseguranca(int codigoseguranca) {
		this.codigoseguranca = codigoseguranca;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
	
	
	
		
	}


