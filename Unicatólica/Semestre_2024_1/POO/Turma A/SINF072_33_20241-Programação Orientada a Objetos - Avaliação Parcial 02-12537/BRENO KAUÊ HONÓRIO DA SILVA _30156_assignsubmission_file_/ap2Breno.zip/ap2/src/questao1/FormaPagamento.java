package questao1;

public abstract class FormaPagamento {
	
	private String pagamento;

	public String getPagamento() {
		return pagamento;
	}

	public void setPagamento(String pagamento) {
		this.pagamento = pagamento;
	}


	

}
