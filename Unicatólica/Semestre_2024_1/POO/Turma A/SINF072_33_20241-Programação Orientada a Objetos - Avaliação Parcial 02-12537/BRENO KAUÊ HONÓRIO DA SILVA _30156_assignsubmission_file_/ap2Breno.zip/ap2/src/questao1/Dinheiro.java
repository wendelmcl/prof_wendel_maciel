package questao1;

public class Dinheiro extends FormaPagamento {

	private String nota;

	public String getNota() {
		return nota;
	}

	public void setNota(String nota) {
		this.nota = nota;
	}
	
}
