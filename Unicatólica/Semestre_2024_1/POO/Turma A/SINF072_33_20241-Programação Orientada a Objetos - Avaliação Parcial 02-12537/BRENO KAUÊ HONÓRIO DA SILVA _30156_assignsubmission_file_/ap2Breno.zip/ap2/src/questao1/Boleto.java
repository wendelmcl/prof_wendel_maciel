package questao1;

public class Boleto  extends FormaPagamento{
	
	private int codigoBoleto;

	public int getCodigoBoleto() {
		return codigoBoleto;
	}

	public void setCodigoBoleto(int codigoBoleto) {
		this.codigoBoleto = codigoBoleto;
	}
	
	

}
