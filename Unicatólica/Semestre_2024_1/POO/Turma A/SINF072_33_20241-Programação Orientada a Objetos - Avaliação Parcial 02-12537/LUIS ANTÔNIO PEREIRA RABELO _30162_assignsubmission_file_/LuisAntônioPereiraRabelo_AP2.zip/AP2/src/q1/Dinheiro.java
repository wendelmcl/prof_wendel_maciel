package q1;

public class Dinheiro extends FormaPagamento{
	
}
