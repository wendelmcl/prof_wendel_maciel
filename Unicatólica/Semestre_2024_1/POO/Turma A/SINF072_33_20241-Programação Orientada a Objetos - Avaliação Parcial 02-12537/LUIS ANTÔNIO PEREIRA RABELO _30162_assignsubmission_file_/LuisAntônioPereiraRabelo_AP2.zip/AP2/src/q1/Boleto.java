package q1;

public class Boleto extends FormaPagamento {
	private String numbol;

	public String getNumbol() {
		return numbol;
	}

	public void setNumbol(String numbol) {
		this.numbol = numbol;
	}
	
}
