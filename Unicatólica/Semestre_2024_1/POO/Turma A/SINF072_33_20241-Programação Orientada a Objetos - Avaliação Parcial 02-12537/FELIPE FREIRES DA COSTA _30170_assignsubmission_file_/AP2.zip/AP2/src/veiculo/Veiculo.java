package veiculo;

public interface Veiculo {
	public void acelerar();
	public void frear();
	public void fazerBarulho();
	
	
	
}