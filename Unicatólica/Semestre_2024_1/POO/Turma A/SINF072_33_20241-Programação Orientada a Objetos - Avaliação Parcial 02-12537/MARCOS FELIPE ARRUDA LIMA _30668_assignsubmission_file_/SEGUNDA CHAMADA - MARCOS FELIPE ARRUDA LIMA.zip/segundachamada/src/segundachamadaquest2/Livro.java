package segundachamadaquest2;

interface Livro extends ItemBiblioteca {
	void consultarDisponibilidade();
	}

