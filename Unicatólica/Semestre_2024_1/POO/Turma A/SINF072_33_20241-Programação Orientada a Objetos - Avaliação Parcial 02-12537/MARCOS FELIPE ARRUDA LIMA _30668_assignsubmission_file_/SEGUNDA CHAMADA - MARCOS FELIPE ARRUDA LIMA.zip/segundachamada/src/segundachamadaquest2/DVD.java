package segundachamadaquest2;

public interface DVD {
	void gravarDVD();

	void emprestarItem();

	void devolverItem();
}
