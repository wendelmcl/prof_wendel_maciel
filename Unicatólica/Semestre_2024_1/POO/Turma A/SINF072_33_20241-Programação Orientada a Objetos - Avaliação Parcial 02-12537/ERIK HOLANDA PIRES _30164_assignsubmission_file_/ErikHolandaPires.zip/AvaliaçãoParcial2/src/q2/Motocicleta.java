package q2;

public class Motocicleta implements Veiculo{
	
	public void acelerar() {
		// TODO Auto-generated method stub
		System.out.println("A motocicleta est� acelerando!");
	}

	public void frear() {
		System.out.println("A motocicleta est� freando!");
		
	}

	public void fazerBarulho() {
		System.out.println("A motocicleta est� fazendo barulho!");
		
	}
}
