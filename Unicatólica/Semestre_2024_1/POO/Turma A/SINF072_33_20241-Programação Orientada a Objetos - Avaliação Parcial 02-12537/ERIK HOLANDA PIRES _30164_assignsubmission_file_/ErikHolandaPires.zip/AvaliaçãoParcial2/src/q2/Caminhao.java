package q2;

public class Caminhao implements Veiculo{
	
	public void acelerar() {
		// TODO Auto-generated method stub
		System.out.println("O Caminh�o est� acelerando!");
	}

	public void frear() {
		System.out.println("O Caminh�o est� freando!");
		
	}

	public void fazerBarulho() {
		System.out.println("O Caminh�o est� fazendo barulho!");
		
	}
}
