package Q2;

public interface Veiculo {
	void frear();
	void acelerar();
	void fazerBarulho();
	

}
