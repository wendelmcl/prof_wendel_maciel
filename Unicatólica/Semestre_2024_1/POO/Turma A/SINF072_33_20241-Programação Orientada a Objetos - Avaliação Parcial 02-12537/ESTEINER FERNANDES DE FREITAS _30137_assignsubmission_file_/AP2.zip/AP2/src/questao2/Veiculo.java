package questao2;

import java.util.ArrayList;

interface Veiculo {
    void acelerar();
    void frear();
    void fazerBarulho();
}
