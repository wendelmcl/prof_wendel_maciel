package q2;

public class Dinheiro extends FormaPagamento {

}
