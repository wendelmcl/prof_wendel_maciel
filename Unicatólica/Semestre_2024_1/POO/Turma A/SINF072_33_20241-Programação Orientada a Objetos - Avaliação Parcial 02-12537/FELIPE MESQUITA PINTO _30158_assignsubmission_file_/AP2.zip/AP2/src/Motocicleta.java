
public class Motocicleta implements Veiculo {

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub
		System.out.println("motocicleta acelerando");
	}

	@Override
	public void frear() {
		// TODO Auto-generated method stub
		System.out.println("motocicleta freando");

	}

	@Override
	public void fazerBaraulho() {
		// TODO Auto-generated method stub
		System.out.println("motocicleta fazendo barulho");

	}

}
