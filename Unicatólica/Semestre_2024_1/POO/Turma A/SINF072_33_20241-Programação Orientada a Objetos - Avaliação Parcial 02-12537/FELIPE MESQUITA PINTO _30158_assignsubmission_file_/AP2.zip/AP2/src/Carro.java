
public class Carro implements Veiculo {

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub
		System.out.println("carro acelerando");
	}

	@Override
	public void frear() {
		// TODO Auto-generated method stub
		System.out.println("carro freando");

	}

	@Override
	public void fazerBaraulho() {
		// TODO Auto-generated method stub
		System.out.println("carro fazendo barulho");

	}
	

}
