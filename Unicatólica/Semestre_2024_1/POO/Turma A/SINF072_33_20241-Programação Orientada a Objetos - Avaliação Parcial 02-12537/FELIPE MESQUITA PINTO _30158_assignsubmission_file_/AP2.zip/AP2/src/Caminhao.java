
public class Caminhao implements Veiculo {

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub
		System.out.println("Caminhao acelerando");
	}

	@Override
	public void frear() {
		// TODO Auto-generated method stub
		System.out.println("Caminhao freando");

	}

	@Override
	public void fazerBaraulho() {
		// TODO Auto-generated method stub
		System.out.println("Caminhao fazendo barulho");

	}

}
