package q2;

import java.util.ArrayList;
import java.util.List;

public class ArrayListPagamentos {
	
	public List<FormaPagamento> ListaDePagamento;

	public ArrayListPagamentos() {
		
		ListaDePagamento = new ArrayList<>();
	}
	
	
	

}
