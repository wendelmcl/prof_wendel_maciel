package q2;

public abstract class FormaPagamento {
 private String cartaoDeCredito;
 private String cartaoDedebito;
 private String boleto;
 private String Dinheiro;
	
	
}
