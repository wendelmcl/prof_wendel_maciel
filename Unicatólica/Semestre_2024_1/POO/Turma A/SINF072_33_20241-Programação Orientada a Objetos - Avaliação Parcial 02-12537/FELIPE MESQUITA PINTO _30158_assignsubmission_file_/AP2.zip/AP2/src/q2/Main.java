package q2;



import java.util.ArrayList;

public class Main {
public static void main(String [] args){
CartaoCredito cartaoDeCredito = new CartaoCredito();
CartaoDebito cartaoDeDebito = new CartaoDebito();
Boleto boleto = new Boleto();
Dinheiro dinheiro = new Dinheiro();
	ArrayList<FormaPagamento> Formaspagamento = new ArrayList<>();
	Formaspagamento.add(cartaoDeCredito);
	
}
	

	
}
