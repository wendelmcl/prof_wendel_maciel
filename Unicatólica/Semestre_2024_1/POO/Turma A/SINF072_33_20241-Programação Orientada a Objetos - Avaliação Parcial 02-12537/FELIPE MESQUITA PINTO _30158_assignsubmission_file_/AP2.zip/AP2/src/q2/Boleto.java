package q2;

public class Boleto extends FormaPagamento {
int CodigoBoleto;




public Boleto(int codigoBoleto) {
	super();
	CodigoBoleto = codigoBoleto;
}




public int getCodigoBoleto() {
	return CodigoBoleto;
}
	


}
