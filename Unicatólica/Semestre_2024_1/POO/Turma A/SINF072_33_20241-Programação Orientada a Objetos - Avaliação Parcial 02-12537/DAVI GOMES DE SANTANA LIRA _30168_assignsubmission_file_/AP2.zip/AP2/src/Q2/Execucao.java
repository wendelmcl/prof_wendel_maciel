package Q2;

public class Execucao {

	public static void main(String[] args) {
		Exe exe = new Exe();
		
		exe.metodoCaminhao();
		exe.metodoCarro();
		exe.metodoMotocicleta();
	}

}
