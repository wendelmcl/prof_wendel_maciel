package Q2;

public interface Veiculo {
	
	void acelerar();
	void frear();
	void fazerBarulho();
	
}
