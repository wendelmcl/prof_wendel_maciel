package Q1;

import java.util.Scanner;

public class Questao3 {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Digite 10 n�mero para armazenar no vetor: ");

		int n1 = (int) sc.nextInt();	
		int n2 = (int) sc.nextInt();
		int n3 = (int) sc.nextInt();
		int n4 = (int) sc.nextInt();
		int n5 = (int) sc.nextInt();
		int n6 = (int) sc.nextInt();
		int n7 = (int) sc.nextInt();
		int n8 = (int) sc.nextInt();
		int n9 = (int) sc.nextInt();
		int n10 = (int) sc.nextInt();
		
		
	}

}
