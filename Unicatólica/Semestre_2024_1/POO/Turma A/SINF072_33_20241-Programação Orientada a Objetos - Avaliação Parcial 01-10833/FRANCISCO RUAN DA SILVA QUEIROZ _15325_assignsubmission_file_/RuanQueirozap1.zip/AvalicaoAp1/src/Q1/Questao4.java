package Q1;

public class Questao4 {

	private Int numero, saldo;
	private String metodo; 
	

}
