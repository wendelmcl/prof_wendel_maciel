//Sistema bancário.
package Prova;
public class QuestaoQuatro {

}
