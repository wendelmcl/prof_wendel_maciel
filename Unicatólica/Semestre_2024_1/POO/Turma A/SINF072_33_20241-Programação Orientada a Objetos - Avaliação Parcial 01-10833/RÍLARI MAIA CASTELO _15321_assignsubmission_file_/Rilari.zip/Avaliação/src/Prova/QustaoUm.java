//Números positivos e negativos.
package Prova;
import java.util.Scanner;
public class QustaoUm {
public static void main(String[]args) {
	Scanner input = new Scanner(System.in);
	System.out.println("Digite um número inteiro positivo: ");
	Scanner num = input;
	int i = 1;
	if (num/i && num)  {
		System.out.println("É um número primo! ");	
	}
	else {
		System.out.println("Não é um número primo! ");	
	}
}
}
