package vetPeI;

import java.util.Scanner;

public class VetParImpar {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int[] vetor = new int[10];
		for(int i = 0; i < vetor.length; i++ ){
			System.out.println("Digite um numero: ");
			vetor[i] = sc.nextInt();
			if(vetor == 2 *){
				
			}
		}
	}

}
