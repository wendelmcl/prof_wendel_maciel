package Q2;

public class Q2 {

	public static void main(String[] args) {
		
		int[] vetor1 = {10};
		int[] vetor2 = {5};
		int[] vetor3 = {30};
		int[] vetor4 = {20};
		int[] vetor5 = {5};
		
		int  soma = vetor1[10] + vetor2[5] + vetor3[30] + vetor4[20] + vetor5[5];
		
		System.out.println("a soma dos vetores: " + soma);
	}

}
