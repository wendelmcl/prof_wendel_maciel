package Q3;
import java.util.Scanner;
public class Q3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int vetor[] = {10,10,10,10,10,10,10,10,10,10};
		
		int  soma = ;
		
		System.out.println("a soma dos numeros �: " + soma);
	}
}
