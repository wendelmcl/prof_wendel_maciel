package Q1;
import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("digite um numero: ");
		int numero = sc.nextInt();
	
		if(){
			System.out.println("O numero digitado e primo ");
			
		}else{
			System.out.println("O numero digitado nao e primo ");
			
		}

	}

}
