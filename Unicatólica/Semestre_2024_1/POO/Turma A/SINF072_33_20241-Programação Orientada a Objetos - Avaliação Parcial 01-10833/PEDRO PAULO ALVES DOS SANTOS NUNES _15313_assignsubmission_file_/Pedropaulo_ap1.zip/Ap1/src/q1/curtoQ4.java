package q1;

public class curtoQ4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Conta c1 = new Conta();
		
		System.out.printin("Digite o n�mero ")

	}
}
