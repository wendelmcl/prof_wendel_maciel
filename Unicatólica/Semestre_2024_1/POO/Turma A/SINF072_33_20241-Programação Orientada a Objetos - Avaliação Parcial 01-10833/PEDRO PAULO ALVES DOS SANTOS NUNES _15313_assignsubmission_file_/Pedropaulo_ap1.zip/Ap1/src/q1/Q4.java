package q1;

public class conta {
	private int cod;
	private int saldo;
	
	public double depositar(double valor);
	setSaldo(getSaldo() + Valor);
	System.out.printin9("Qual o valor desse deposito? ");
	saldo = getSaldo() + valor;
	this.saldo = saldo;
	return getSaldo();
	}

public static void main(String[] args){
	
}
    Public double consultar(){
    	return getSaldo();
    }
    
    
    public int getCod() {
    	return cod;
    }
    
    public void setCod(int cod) {
    	this.cod = cod;
    }
    
    Public double getSaldo() {
    	return saldo;
    	
    }
    
    public static 