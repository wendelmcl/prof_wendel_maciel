package q1;

import java.util.Scanner;

public class NumeroPrimo {

	public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
 
 
 System.out.println("Digite um n�mero inteiro POSITIVO");
 int numero = sc.nextInt();
  
 if ( numero / numero == 1 && numero /1 == numero){
	 
	 System.out.println(" O N�MERO � PRIMO! ");
 }
 
 else {System.out.println(" O N�MERO N�O � PRIMO!");}
		
		
		
		
		
		
		
		
		
	}

}
