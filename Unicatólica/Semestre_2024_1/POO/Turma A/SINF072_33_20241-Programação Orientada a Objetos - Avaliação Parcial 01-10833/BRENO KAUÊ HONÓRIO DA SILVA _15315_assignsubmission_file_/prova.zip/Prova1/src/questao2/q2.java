package questao2;

import java.util.Scanner;

public class q2 {
	
	public static void main(String[]args){
				
		Scanner sc = new Scanner(System.in);
		
		String[] vetor = {"a", "e", "i", "o", "u"};
		for(int i = 0;i < vetor.length; i++){					
		System.out.println("Digite uma palavra: ");		
		String palavra = sc.next();
		
		}{
			
		}
		
			
		
	}
				
	}

