package questao1;

import java.util.Scanner;

public class q1 {
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Digite um n�mero: ");
		
		int num = sc.nextInt();
		
		
	}
		
		
	

}
