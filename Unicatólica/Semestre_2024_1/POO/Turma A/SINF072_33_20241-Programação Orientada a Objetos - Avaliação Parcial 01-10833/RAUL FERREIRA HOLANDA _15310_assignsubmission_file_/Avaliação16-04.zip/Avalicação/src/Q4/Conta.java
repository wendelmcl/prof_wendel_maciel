package Q4;

public class Conta {
	
	private String id;
	private int saldo;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getSaldo() {
		return saldo;
	}
	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}
	
	public int depositar(){
		return.saldo
				
	}
	
}
