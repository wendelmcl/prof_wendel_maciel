package Q4;

public class Q4exc {

	public static void main(String[] args) {

	}

}
