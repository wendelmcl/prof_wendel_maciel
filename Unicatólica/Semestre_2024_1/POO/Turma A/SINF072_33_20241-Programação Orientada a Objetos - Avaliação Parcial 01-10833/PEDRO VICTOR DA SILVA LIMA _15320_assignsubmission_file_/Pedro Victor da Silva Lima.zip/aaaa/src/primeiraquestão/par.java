package primeiraquestão;

import java.util.Scanner;

public class par {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Digite um numero");
		int numero = 7;
		if(numero / 7 == 1 ) {
			System.out.println(" o numero digitado e primo");	
		}else {
			System.out.println("Esse numero não e primo");
		}
	}
}
	
    
    	
	