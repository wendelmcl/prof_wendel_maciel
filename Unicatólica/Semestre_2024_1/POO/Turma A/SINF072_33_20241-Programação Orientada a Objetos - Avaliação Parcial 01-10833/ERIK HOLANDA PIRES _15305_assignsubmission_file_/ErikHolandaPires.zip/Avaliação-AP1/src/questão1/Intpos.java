package quest�o1;

public class Intpos {
	private int n1;

	public int getN1() {
		return n1;
	}

	public void setN1(int n1) {
		this.n1 = n1;
	}
	
}
